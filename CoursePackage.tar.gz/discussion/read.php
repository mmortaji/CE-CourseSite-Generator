<?php
	if (!isset($indexFile) || trim(basename($_SERVER['PHP_SELF'])) != trim($indexFile))
	{
		die('You can not access this page directly.');
	}
	require 'parseMsgs.php';
	require 'includes/shamsi.php';
	$messages = parseMessages();
?>
	<TABLE cellSpacing=0 cellPadding=0 width="97%" border=0>
		<tr>
			<td>
				<?php createSectionTitle('Read Message'); ?>
			</td>
		</tr>				
		<TR>
			<td>
				<table align=center width=90% cellspacing=4 cellpadding=2 class=blockcontent2>
					<tr>
						<TD>
							<B>&nbsp;Subject:</B> <?php echo htmlspecialchars($messages[$_GET['id']]["Subject"]); ?>
						</td>
					</tr>
					<tr>
						<td>						
							<B>&nbsp;Author:</B> <?php echo $messages[$_GET['id']]["Author"]; ?>
						</td>
					</tr>
					<tr>
						<td>
							<B>&nbsp;Posted at:</B> <?php echo faDate($messages[$_GET['id']]['Date'])." [".date("F d, Y h:i A",$messages[$_GET['id']]["Date"])."]"; ?>
						</TD>
					</tr>
				</table>
			</td>
		</TR>
		<TR>
			<td>
				<br/>
				<TABLE width="90%" align=center class=table2 cellspacing=4 cellpadding=2>
					<TR>
						<TD>
							<br/>
								<table width="97%" align=center>
									<tr>
										<td>											
											<?php echo str_replace("  "," &nbsp;",nl2br(htmlspecialchars($messages[$_GET['id']]["Content"]))); ?>
										</td>
									</tr>
								</table>
							<br/>
						</TD>
					</TR>
				</TABLE>
			</TD>
		</TR>
		<tr>
			<td>
				<table width=90% align=center>
					<tr>
						<td>
							<br/>
							<?php 
							if ($_GET['id']>0) 
							{
							?>
								<input type=button value="Previous" onclick="document.location='<?php echo getInternallink("discussion","read","id=".($_GET['id']-1)); ?>';">
							<?php
							}
							if ($_GET['id']+1<count($messages))
							{
							?>
								<input type=button value="Next" onclick="document.location='<?php echo getInternallink("discussion","read","id=".($_GET['id']+1)); ?>';">
							<?php
							}
							?>
						</td>
						<td align=right>
							<br/>
							<input type=button value=" Reply " onclick="document.location='<?php echo getInternallink("discussion","reply","id=$_GET[id]"); ?>';">
							<input type=button value="Back to Messages" onclick="document.location='<?php echo getInternallink("discussion","discussion"); ?>';">
						</td>
					</tr>
				</table>
			</td>
		</tr>
	</TABLE>     	       					
