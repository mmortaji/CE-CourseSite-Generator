<?php
if (!isset($indexFile) || trim(basename($_SERVER['PHP_SELF'])) != trim($indexFile))
{
	die('You can not access this page directly.');
}


$adminsFile = 'admin/admins.inf';
if (!file_exists($adminsFile))
{
		show_error("Couln't find administrators' file.");
}
$admins = file($adminsFile);
if (isset($_GET['email']))
{
	if ($_GET['email'])
	{
		for ($i=0 ; $i<count($admins) ; $i++)
		{
			list($admin,$pass,$semat,$email,$verify) = explode("|",$admins[$i]);
            $emailmd5=md5($email.'!@#$5678');;
			// if (trim($emailmd5) != trim($_GET['email']))
			// {
			// 	show_error("Danger ;( ");
			// }
		}
		$admins = file($adminsFile);
		for ($i=0 ; $i<count($admins) ; $i++)
		{
			list($admin,$pass,$semat,$email,$verify) = explode("|",$admins[$i]);
			$emailmd5=md5($email.'!@#$5678');;
			if (trim($emailmd5) == trim($_GET['email']))
			{
				$admins[$i] = trim($admin)."|".trim($pass)."|".trim($semat)."|".trim($email)."|".trim(date("Y/m/d"));
                $verifyok="ok";
			}
		}
		if (!($file = fopen($adminsFile,"w")))
		{
			die("Coudn't open $adminsFile for writing.");
		}
		for ($i=0 ; $i<count($admins) ; $i++)
		{
			$admins[$i] = trim($admins[$i]);
			if ($admins[$i] != "")
			{
				fputs($file,"$admins[$i]\n");
			}
		}
		fclose($file);
        if($verifyok)
        {
		url_redirect(getIndex(),"1","Verify OK.");
        }
        else {
            url_redirect(getIndex(),"1","Mistake Verify.");
        }
	}
}
?>


Verify ?!