<?php
if (!isset($indexFile) || trim(basename($_SERVER['PHP_SELF'])) != trim($indexFile))
{
	die('You can not access this page directly.');
}
if (!$_SESSION["isAdmin"])
{
	die("ACCESS DENIED");
}


$themeFile = 'admin/theme.inf';
if (!($handle = fopen($themeFile,"w+")))
{
	show_error("Couldn't open $themeFile for writing.");
}
fputs($handle,$_POST['themeName']);
fclose($handle);
url_redirect();
