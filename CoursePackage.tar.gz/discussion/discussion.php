<?php
	if (!isset($indexFile) || trim(basename($_SERVER['PHP_SELF'])) != trim($indexFile))
	{
		die('You can not access this page directly.');
	}
	require 'parseMsgs.php';
	require 'includes/shamsi.php';
?>
<TABLE cellSpacing=0 cellPadding=0  border=0 width="97%" align=center>
	<TR>
		<TD>
			<?php createSectionTitle('Discussion Area'); ?>
		</TD>
	</TR>
<?php
if ($_SESSION['Logged_in'])
{
?>
	<tr>
		<td align=right>
			<form method=post action="<?php echo getInternallink("discussion","compose"); ?>">
				<input type=submit value="Compose New Message">
			</form>
		</td>
	</tr>
<?php
}
if ($_SESSION['isAdmin'])
{
	if (isset($_GET['cmd']) && $_GET['cmd'] == "del")
	{
		$messages = parseMessages();
		$msgFile = "discussion/discussion.xml";
		if (! ($fout = fopen($msgFile,"w")) )
		{
			die("Couldn't open $msgFile for writing.");
		}
		fputs($fout,"<?xml version='1.0' encoding='UTF-8' ?>\n");
		fputs($fout,"<Messages>\n");
		for ($i=0 ; $i<count($messages); $i++)
		{
			if ($i == $_GET['id'])
			{
				continue;
			}
			fputs($fout,"\t<Message>\n");
			fputs($fout,"\t\t<Subject><![CDATA[".trim($messages[$i]["Subject"])."]]></Subject>\n");
			fputs($fout,"\t\t<Date>".trim($messages[$i]["Date"])."</Date>\n");
			fputs($fout,"\t\t<Author><![CDATA[".trim($messages[$i]["Author"])."]]></Author>\n");
			fputs($fout,"\t\t<Content><![CDATA[".trim($messages[$i]["Content"])."]]></Content>\n");
			fputs($fout,"\t</Message>\n");
		}
		fputs($fout,"</Messages>\n");
		fclose($fout);
		url_redirect(getInternallink("discussion","discussion"));
	}
}

$messages = parseMessages();
?>
	<tr>
		<td>
			<table width="90%" align=center class=table2 cellspacing=1 cellpadding=2>
				<tr>
					<th>
						Subject
					</th>
					<th>
						&nbsp;Author&nbsp;
					</th>
					<th>
						Posted
					</th>
					<?php
					if (($_SESSION['isAdmin'] or $_SESSION['isTa']) && (!$_SESSION['isStudent']) )
					{
					?>
					<th>
						Delete
					</th>
					<?php
					}
					?>
				</tr>
<?php
$class=1;
for ($i=0 ; $i<count($messages) ; $i++)
{
	$class = ($class==1 ? 2 : 1);
?>
				<tr>
					<td class=row<?php echo $class; ?>>
						<b>&nbsp;
						<a href="<?php echo getInternallink("discussion","read","id=$i"); ?>">
							<?php
								$messages[$i]['Subject'] = trim($messages[$i]['Subject']);
								if (strlen($messages[$i]['Subject']) > 40)
								{
									$messages[$i]['Subject'] = substr($messages[$i]['Subject'],0,40)."...";
								}
								echo $messages[$i]['Subject'];
							?>
						</a>
						</b>
					</td>
					<td class=row<?php echo $class; ?>>
						&nbsp;&nbsp;<?php echo trim($messages[$i]['Author']); ?>
					</td>
					<td class=row<?php echo $class; ?>>
						<table cellspacing=0 width=100%>
							<tr>
								<td nowrap>
									&nbsp;&nbsp;<?php echo faDate($messages[$i]['Date']); ?>
								</td>
								<td align=right>
									<?php echo "[ ".date("F d, Y h:i A",$messages[$i]['Date'])." ]"; ?>
								</td>
							</tr>
						</table>
					</td>
					<?php
					if (($_SESSION['isAdmin'] or $_SESSION['isTa']) && (!$_SESSION['isStudent']) )
					{
					?>
					<td align=center class=row<?php echo $class; ?>>
						<a href="<?php echo getInternallink("discussion","discussion","cmd=del&amp;id=$i"); ?>"
							onclick="return confirm('Are you sure to delete this message?');">
							<img src="images/delete.gif" border=0>
						</a>
					</td>
					<?php
					}
					?>
				</tr>
<?php
}
if (count($messages) == 0)
{
?>
				<tr>
					<td align=center colspan=4>
						<b>No message yet.</b>
					</td>
				</tr>
<?php
}
?>
			</table>
		</td>
	</tr>
</TABLE>
