<?php
	if (!isset($indexFile) || trim(basename($_SERVER['PHP_SELF'])) != trim($indexFile))
	{
		die('You can not access this page directly.');
	}
	$Linksfile = "links/linksItems.xml";
    require 'parseLinks.php';
    $links = parseLinks();
?>
<TABLE width="97%" align=center cellspacing=0 cellpadding=0>
	<TR>
		<TD>
			<TABLE border=0 width="100%" cellspacing=0 cellpadding=0>
				   <TR>
					   <td>
						   <?php createSectionTitle('Related Links'); ?>
						</td>
					<tr>
				<?php if (($_SESSION['isAdmin'] or $_SESSION['isTa']) && (!$_SESSION['isStudent']) ) { ?>
					<tr>
					   <TD align=right>
						   <form method=post action="<?php echo getInternallink("links","changeLinks","cmd=AddFrm"); ?>">
						   <input type=submit value='Add New Category' class=button>&nbsp;&nbsp;
						   </form>
					   </TD>
					 </tr>
				<?php
   			    }
   			 echo '</table>';
reset($links);
while ( list($key,$value) = each($links) )
{
?>
				<TABLE cellSpacing=0 cellPadding=0 width="95%" border=0 align=center>
				   <TR>
					   <TD class=tableOutline2>
						  <TABLE cellSpacing=0 cellPadding=0 width="100%" border=0>
							  <TR class=tableHead2>
								  <TD>
									  <TABLE width="100%" border=0 cellpadding=0 cellspacing=0 class=titlebar>
										  <TR>
											 <TD>
												 &nbsp;<?php echo $key; ?>
											 </TD>
											 <?php if (($_SESSION['isAdmin'] or $_SESSION['isTa']) && (!$_SESSION['isStudent']) ) { ?>
											 <TD width=10>
												 <A href="<?php echo getInternallink("links","changeLinks","cmd=edit&amp;id=".rawurlencode($key)); ?>"><IMG SRC="images/edit.gif" border=0 alt="Edit Category"></A>&nbsp;&nbsp;
											 </TD>
											 <TD width=10>
												 <A href="<?php echo getInternallink("links","changeLinks","cmd=delete&amp;id=".rawurlencode($key)); ?>" onclick="return confirmation('');"><IMG SRC="images/delete.gif" border=0 alt="Delete Category"></A>&nbsp;
											 </TD>
											 <?php  } ?>
										  </TR>
									  </TABLE>
								  </TD>
							  </TR>
						   </TABLE>
						</TD>
					</TR>
					<tr>
						<td>
							<table class=table1 border=0>
								<tr>
									<td>
										<?php
											if (count($links[$key]) == 0)
											{
												if ($_SESSION['isAdmin'])
												{
													echo "<br/> &nbsp; Use edit button to add new links to this category.";
												}
												else
												{
													echo "<br/> &nbsp; No links for this category yet.";
												}

											}
											 reset($links[$key]);
											 //echo "<UL>";
											 while ( list($linkkey,$linkvalue) = each($links[$key]) )
											   {
												   echo "<LI><A href=".$links[$key][$linkkey]["Value"].">".$links[$key][$linkkey]["Title"]."</A></LI>";
											   }
											 //echo "</UL>";
										?>
									</td>
								 </tr>
							</table>
						</td>
					</tr>
				</TABLE>
				<br/>
	<?php
		  }
	?>
			</TD>
		</TR>
   </TABLE>
<?php
if (count($links) == 0 && !$_SESSION['isAdmin'])
{
	show_msg('No link yet :(');
}
?>
<SCRIPT>
function confirmation (name)
{
         if (confirm(" Are you sure to delete this category and all of its links?"))
             {return true;}
         else
             {return false;}
}
</SCRIPT>
