<?php
if (!$_SESSION['isAdmin'])
{
	die("ACCESS DENIED");
}
require_once 'parseGrades.php';
$studentsFile = "grades/students.lst";
if (!file_exists($studentsFile))
{
	if (!($file = fopen($studentsFile,"w+")))
	{
		show_error("Couldn't create students file.");
	}
	fclose($file);
}
$students = file($studentsFile);
if (isset($_GET['cmd']) && $_GET['cmd']=="add")
{
	for ($i=0 ; $i<20 ; $i++)
	{
		if (trim($_POST["std$i"]) != "")
		{
			$students[] = $_POST["std$i"];
		}
	}
	if (!($file = fopen($studentsFile,"w+")))
	{
		show_error("Couldn't open students file.");
	}
	for ($i=0 ; $i<count($students) ; $i++)
	{
		fputs($file,trim($students[$i])."\n");
	}
	fclose($file);
	url_redirect(getInternallink("grades","list"));
}
elseif (isset($_GET['cmd']) && $_GET['cmd']=="edit")
{
	$newStudents = array();
	for ($i=0 ; $i<count($students) ; $i++)
	{
		if (trim($_POST["curstd$i"]) != "" and !isset($_POST["check$i"]))
		{
			$newStudents[] = trim($_POST["curstd$i"]);
		}
	}
	if (!($file = fopen($studentsFile,"w+")))
	{
		show_error("Couldn't open students file.");
	}
	for ($i=0 ; $i<count($newStudents) ; $i++)
	{
		fputs($file,trim($newStudents[$i])."\n");
	}
	fclose($file);
	url_redirect(getInternallink("grades","grades"));
}
else
{
?>
<table width=97% align=center cellspacing=0 cellpadding=0>
	<tr>
		<td>
			<?php createSectionTitle("Add New Students"); ?>
		</td>
	</tr>
	<tr>
		<td>
			<form method=post action="<?php echo getInternallink("grades","list","cmd=add"); ?>">
				<table class=blockcontent2 align=center width=90%>
					<tr>
						<td align=center>
							<br/>
							Enter students names or numbers:
							<br/><br/>
						</td>
					</tr>
			<?php
				for ($i=0 ; $i<20 ; $i++)
				{
			?>
					<tr>
						<td align=center>
							#<?php if ($i<9) echo "0"; echo $i+1; ?> &nbsp; <input name=std<?php echo $i; ?>>
						</td>
					</tr>
			<?php
				}
			?>
					<tr>
						<td align=center>
							<br/>
							<input type=submit value=" Add ">
							<input type=button value="Cancel" onclick="document.location='<?php echo getInternallink("grades","grades"); ?>';">
							<br/><br/>
						</td>
					</tr>
				</table>
			</form>
		</td>
	</tr>
<?php
	if (count($students)>0)
	{
?>
	<tr>
		<td>
			<?php createSectionTitle("Edit Current Students List"); ?>
		</td>
	</tr>
	<tr>
		<td>
			<form method=post action="<?php echo getInternallink("grades","list","cmd=edit"); ?>">
				<table class=blockcontent2 align=center width=90%>
					<tr>
						<td width="60%">
							<br/>
						</td>
						<td>
							<br/>
							&nbsp;&nbsp;Delete
						</td>
					</tr>
					<?php
						for ($i=0 ; $i<count($students) ; $i++)
						{
					?>
							<tr>
								<td align=right>
									#<?php if ($i<9) echo "0"; echo $i+1; ?> 
									&nbsp; <input name="curstd<?php echo $i; ?>" value="<?php echo trim($students[$i]); ?>">
								</td>
								<td align=left>
									&nbsp; &nbsp; <input type=checkbox name="check<?php echo $i; ?>">
								</td>
							</tr>
					<?php
						}
					?>
					<tr>
						<td align=center colspan=2>
							<br/>
							<input type=submit value="  Edit  ">
							<input type=button value="Cancel" onclick="document.location='<?php echo getInternallink("grades","grades"); ?>';">
							<br/><br/>
						</td>
					</tr>
				</table>
			</form>
		</td>
	</tr>
<?php
}
?>
</table>
<?php
}
?>
