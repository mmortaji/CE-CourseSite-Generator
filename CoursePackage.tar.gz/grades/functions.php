<?php
require_once 'includes/shamsi.php';

function hasObjection($grades)
{
		if (trim($grades['ObjectionStart']) == "")
		{
				return false;
		}
		if (trim($grades['ObjectionEnd']) == "")
		{
				return false;
		}
		return true;
}

function ObjectionPeriod($grades)
{
		if (!hasObjection($grades))
		{
				return "NEVER";
		}
		list($curY,$curM,$curD) = explode("-",faDate(time()));
		list($startY,$startM,$startD) = explode("/",$grades['ObjectionStart']);
		list($endY,$endM,$endD) = explode("/",$grades['ObjectionEnd']);
		if ($curY<$startY)
		{
				return "AFTER";
		}
		elseif ($curY == $startY)
		{
				if ($curM < $startM)
				{
						return "AFTER";
				}
				elseif ($curM == $startM)
				{
						if ($curD < $startD)
						{
								return "AFTER";
						}
				}
		}
		if ($curY > $endY)
		{
				return "PASSED";
		}
		elseif ($curY == $endY)
		{
				if ($curM > $endM)
				{
						return "PASSED";
				}
				elseif ($curM == $endM)
				{
						if ($curD > $endD)
						{
								return "PASSED";
						}
				}
		}
		return "NOW";
}
?>
