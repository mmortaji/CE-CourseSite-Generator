<?php
if (!$_SESSION['Logged_in'])
{
	die("ACCESS DENIED");
}
$gradesFile = "grades/grades.xml";
if (! ($fout = fopen($gradesFile,"w")) )
{
	die("Couldn't open $gradesFile for writing.");
}
fputs($fout,"<?xml version='1.0' encoding='UTF-8' ?>\n");
fputs($fout,"<Grades>\n");
for ($i=0 ; $i<count($grades) ; $i++)
{
	  $isFirst = true;
	  fputs($fout,"\t<Grade type=\"".$grades[$i]['Type']."\">\n");
	  fputs($fout,"\t\t<Title><![CDATA[".trim($grades[$i]['Title'])."]]></Title>\n");
	  if ($grades[$i]['Type'] == "File")
	  {
		  fputs($fout,"\t\t<File><![CDATA[".trim($grades[$i]["File"])."]]></File>\n");
	  }
	  else
	  {
		  fputs($fout,"\t\t<Table>\n");
		  for ($j=0 ; $j<count($grades[$i]['Table']) ; $j++)
		  {
			  fputs($fout,"\t\t\t<Row>\n");
			  reset($grades[$i]['Table'][$j]);
			  while(list($key,$value) = each($grades[$i]['Table'][$j]))
			  {
				  $key = trim($key);
				  if ($isFirst)
				  {
					  fputs($fout,"\t\t\t\t<Col name=\"".$key.'"'.
						  ' max="'.$grades[$i]['Columns'][$key]['max'].'"'.
						  ' min="'.$grades[$i]['Columns'][$key]['min'].'"'.
						  ' avg="'.$grades[$i]['Columns'][$key]['avg'].'"'.
						  ">\n");
				  }
				  else
				  {
					  fputs($fout,"\t\t\t\t<Col name=\"$key\">\n");
				  }
				  fputs($fout,"\t\t\t\t\t<Value><![CDATA[".trim($value)."]]></Value>\n");
				  fputs($fout,"\t\t\t\t</Col>\n");
			  }
			  fputs($fout,"\t\t\t</Row>\n");
			  $isFirst = false;
		  }
		  fputs($fout,"\t\t</Table>\n");
	  }
	  fputs($fout,"\t\t<Comment><![CDATA[".trim($grades[$i]["Comment"])."]]></Comment>\n");
	  fputs($fout,"\t\t<Objection>\n");
	  fputs($fout,"\t\t\t<Start><![CDATA[".trim($grades[$i]["ObjectionStart"])."]]></Start>\n");
	  fputs($fout,"\t\t\t<End><![CDATA[".trim($grades[$i]["ObjectionEnd"])."]]></End>\n");
	  for ($j=0 ; $j<count($grades[$i]['Objections']) ; $j++)
	  {
		  fputs($fout,"\t\t\t<ObjectionMsg><![CDATA[".trim($grades[$i]["Objections"][$j])."]]></ObjectionMsg>\n");
   	  }
	  fputs($fout,"\t\t</Objection>\n");
	  fputs($fout,"\t</Grade>\n");
}
fputs($fout,"</Grades>\n");
fclose($fout);
?>
