<?php
	if (!isset($indexFile) || trim(basename($_SERVER['PHP_SELF'])) != trim($indexFile))
	{
		die('You can not access this page directly.');
	}
?>
<?php
if (!$_SESSION['isAdmin'])
{
	die('Access Denied');
}
require_once 'parseInfo.php';	
$infoFile = "syllabus/courseinfo.xml";

if (isset($_GET['cmd']) && $_GET['cmd']=="addTA")
{
	$info = parseCourseInfo();
	if (! ($fout = fopen($infoFile,"w")) )
	{
		die("Couldn't open $infoFile for writing.");
	}
	if (!isset($info['TA']))
	{
		$info['TA'] = array();
	}
	$info['TA'][] = array("Name" => $_POST['taName'],
							"Email" => $_POST['taMail'],
							"HomePage" => (trim($_POST['taPage']) != "" ? "http://".str_replace("http://","",$_POST['taPage']) : ""));		
	fputs($fout,"<?xml version='1.0' encoding='UTF-8' ?>\n");
	fputs($fout,"<Course>\n");
	reset($info);
	while (list($key,$value) = each($info))
	{
		if (is_array($info[$key]))
		{
			if ($key == "TA")
			{
				for ($i=0 ; $i<count($info[$key]) ; $i++)
				{
					fputs($fout,"\t<TA>\n");
					while (list($inkey,$invalue) = each($info[$key][$i]))
					{
						fputs($fout,"\t\t<$inkey><![CDATA[$invalue]]></$inkey>\n");
					}
					fputs($fout,"\t</TA>\n");
				}				
			}
			else
			{
				fputs($fout,"\t<$key>\n");
				reset($info[$key]);					
				while (list($inkey,$invalue) = each($info[$key]))
				{
					fputs($fout,"\t\t<$inkey><![CDATA[$invalue]]></$inkey>\n");
				}
				fputs($fout,"\t</$key>\n");
			}
		}
		else
		{
			fputs($fout,"\t<$key><![CDATA[$value]]></$key>\n");
		}
	}
	fputs($fout,"</Course>\n");
	fclose($fout);
}
elseif (isset($_POST['param1']) && $_POST['param1'] == "delTA")
{
	$info = parseCourseInfo();
	if (! ($fout = fopen($infoFile,"w")) )
	{
		die("Couldn't open $infoFile for writing.");
	}
	fputs($fout,"<?xml version='1.0' encoding='UTF-8' ?>\n");
	fputs($fout,"<Course>\n");
	reset($info);
	while (list($key,$value) = each($info))
	{
		if (is_array($info[$key]))
		{
			if ($key == "TA")
			{
				for ($i=0 ; $i<count($info[$key]) ; $i++)
				{
					if ($i == $_POST['param2'])
					{
						continue;
					}
					fputs($fout,"\t<TA>\n");
					while (list($inkey,$invalue) = each($info[$key][$i]))
					{
						fputs($fout,"\t\t<$inkey><![CDATA[$invalue]]></$inkey>\n");
					}
					fputs($fout,"\t</TA>\n");
				}
				for ($i	= $_POST['param2'] ; $i<count($info['TA'])-1 ; $i++)
				{
					$j = $i+1;
					$_POST["TA{$i}_Name"] = $_POST["TA{$j}_Name"];
				}
			}
			else
			{
				fputs($fout,"\t<$key>\n");
				reset($info[$key]);					
				while (list($inkey,$invalue) = each($info[$key]))
				{
					fputs($fout,"\t\t<$inkey><![CDATA[$invalue]]></$inkey>\n");
				}
				fputs($fout,"\t</$key>\n");
			}
		}
		else
		{
			fputs($fout,"\t<$key><![CDATA[$value]]></$key>\n");
		}
	}
	fputs($fout,"</Course>\n");
	fclose($fout);
}
elseif (isset($_POST['param1']) && $_POST['param1'] == "addTAFrm")
{
?>
	<form method=post action="<?php echo getInternallink("syllabus","edit","cmd=addTA"); ?>">
	<table align=center class=blockcontent2 cellspacing=6 cellpadding=1 width=50%>
		<tr>
			<td colspan=2>
				<table class=blockhead>
					<tr>
						<td align=center>
							Add new Teacher Assistant
						</td>
					</tr>
				</table>
			</td>
		</tr>
		<tr>
			<td align=right>
				Name:
			</td>
			<td>
				 <input name=taName>
			</td>
		</tr>
		<tr>
			<td align=right>
				Email:
			</td>
			<td>
				<input name=taMail> <span class=comment>(Optional)</span>
			</td>
		</tr>
		<tr>
			<td align=right>
				Homepage:
			</td>
			<td>
				<input name=taPage> <span class=comment>(Optional)</span>
			</td>
		</tr>
		<tr>
			<td colspan=2 align=center>
				<input type=submit value="  Add  ">
			</td>
		</tr>
	</table>
	<?php
		reset($_POST);
		while(list($key,$value) = each($_POST))
		{
			echo "<input type=hidden value=\"".htmlspecialchars($value)."\" name=\"$key\">\n";
		}
	?>
	</form>
<?php
}
elseif (isset($_POST['param1']) && $_POST['param1'] == "editLogoFrm")
{
?>
	<form method=post action="<?php echo getInternallink("syllabus","edit","cmd=editLogo"); ?>" enctype="multipart/form-data">
	<table align=center class=blockcontent2 cellspacing=6 cellpadding=1 width=80%>
		<tr>
			<td colspan=2>
				<table class=blockhead>
					<tr>
						<td align=center>
							Edit Course Logo
						</td>
					</tr>
				</table>
			</td>
		</tr>
		<tr>
			<td align=right>
				Course Logo:
			</td>
			<td>
				 <input name=Logo type=file> (Keep blank for an empty logo.)
			</td>
		</tr>
		<tr>
			<td colspan=2 align=center>
				<input type=submit value="  Edit  ">
			</td>
		</tr>
	</table>
	<?php
		reset($_POST);
		while(list($key,$value) = each($_POST))
		{
			echo "<input type=hidden value=\"".htmlspecialchars($value)."\" name=\"$key\">\n";
		}
	?>
	</form>
<?php
}
if (isset($_GET['cmd']) && $_GET['cmd']=="editLogo")
{
	if (!isset($_FILES['Logo']) or $_FILES['Logo']['name'] == "")
	{
		`rm -f syllabus/Logo`;
	}
	else
	{
		if(!is_uploaded_file($_FILES["Logo"]["tmp_name"]))
		{
			show_error("Couldn't upload Logo file to the server.");
		}
		elseif(!move_uploaded_file($_FILES["Logo"]["tmp_name"],"syllabus/Logo"))
		{	
			show_error("Couldn't transfer Logo file on server.");
		}
	}
	url_redirect(getInternallink("syllabus","edit"),2,"Logo edited.");
}

$info = parseCourseInfo();
reset($info);
while (list($key,$value) = each($info))
{
	if (!is_array($info[$key]))
	{
		if (isset($_POST[$key]))
		{
			$info[$key] = html_entity_decode($_POST[$key]);			
		}
	}
}

if (isset($_POST['Ins_HomePage']) and trim($_POST['Ins_HomePage']) != "")
{
		$_POST['Ins_HomePage'] = "http://".str_replace("http://","",$_POST['Ins_HomePage']);
}

if (isset($_POST['Ins_Name'])) $info['Instructor']['Name'] = $_POST['Ins_Name'];
if (isset($_POST['Ins_Email'])) $info['Instructor']['Email'] = $_POST['Ins_Email'];
if (isset($_POST['Ins_HomePage'])) $info['Instructor']['HomePage'] = $_POST['Ins_HomePage'];

if (isset($_POST['param1']) && $_POST['param1'] == "change")
{
	if (isset($info['TA']) && count($info['TA'])>0)
	{
		for ($i=0 ; $i<count($info['TA']) ; $i++)
		{
			if (isset($_POST["TA{$i}_Name"]))
			{
				$info['TA'][$i]['Name'] = $_POST["TA{$i}_Name"];
			}
			if (isset($_POST["TA{$i}_Email"]))
			{
				$info['TA'][$i]['Email'] = $_POST["TA{$i}_Email"];
			}
			if (isset($_POST["TA{$i}_HomePage"]))
			{
				$info['TA'][$i]['HomePage'] = $_POST["TA{$i}_HomePage"];
			}
		}
	}
	if (! ($fout = fopen($infoFile,"w")) )
	{
		die("Couldn't open $infoFile for writing.");
	}
	fputs($fout,"<?xml version='1.0' encoding='UTF-8' ?>\n");
	fputs($fout,"<Course>\n");
	reset($info);
	while (list($key,$value) = each($info))
	{
		if (is_array($info[$key]))
		{
			if ($key == "TA")
			{
				for ($i=0 ; $i<count($info[$key]) ; $i++)
				{
					$info[$key][$i]['HomePage'] = "http://".str_replace("http://","",$info[$key][$i]['HomePage']);
					if ($info[$key][$i]['HomePage'] == "http://")
					{
						$info[$key][$i]['HomePage'] = "";
					}
					fputs($fout,"\t<TA>\n");
					while (list($inkey,$invalue) = each($info[$key][$i]))
					{
						fputs($fout,"\t\t<$inkey><![CDATA[$invalue]]></$inkey>\n");
					}
					fputs($fout,"\t</TA>\n");
				}
				for ($i	= $_POST['param2'] ; $i<count($info['TA'])-1 ; $i++)
				{
					$j = $i+1;
					$_POST["TA{$i}_Name"] = $_POST["TA{$j}_Name"];
				}
			}
			else
			{
				fputs($fout,"\t<$key>\n");
				reset($info[$key]);					
				while (list($inkey,$invalue) = each($info[$key]))
				{
					fputs($fout,"\t\t<$inkey><![CDATA[$invalue]]></$inkey>\n");
				}
				fputs($fout,"\t</$key>\n");
			}
		}
		else
		{
			fputs($fout,"\t<$key><![CDATA[$value]]></$key>\n");
		}
	}
	fputs($fout,"</Course>\n");
	fclose($fout);
	url_redirect(getInternallink("syllabus","syllabus"));
}
else
{
?>
<TABLE cellSpacing=0 cellPadding=0  border=0 width="97%" align=center>
	<TR>
		<TD>
			<?php createSectionTitle('Edit Course Information'); ?>
		</TD>
	</TR>
	<tr>
		<td>
			<form method=post action="<?php echo getInternallink("syllabus","edit"); ?>">
				<input type=hidden value="change" name="param1">
				<input type=hidden value="" name="param2">
				<table class=blockcontent2 align=center width="90%" cellspacing=5 cellpadding=1>					
					<tr>	
						<td>
							<br />
						</td>
					</tr>
					<tr>
						<td align=right>
							Course Name:
						</td>
						<td>
							 <input name=Name size=35 value="<?php echo $info['Name']; ?>"
						</td>
					</tr>
					<tr>
						<td align=right>
							Course Code:
						</td>
						<td>
							 <input name=Number size=10 value="<?php echo $info['Number']; ?>">
						</td>
					</tr>
					<tr>
						<td align=right>
							Semester:
						</td>
						<td>
							 <input name=Semester size=15 value="<?php echo $info['Semester']; ?>">
						</td>
					</tr>
					<tr>
						<td align=right>
							Group:
						</td>
						<td>
							 <input name=Group size=3 value="<?php echo $info['Group']; ?>">
						</td>
					</tr>
					<tr>
						<td align=right>
							Credit:
						</td>
						<td>
							 <input name=Credit size=3 value="<?php echo $info['Credit']; ?>"> <span class=comment>Unit(s)</span>
						</td>
					</tr>
					<tr>	
						<td colspan=2>
							<hr />
						</td>
					</tr>
					<tr>
						<td align=right>
							Department:
						</td>
						<td>
							 <input name=Department size=15 value="<?php echo $info['Department']; ?>">
						</td>
					</tr>
					<tr>
						<td align=right>
							University:
						</td>
						<td>
							 <input name=University size=35 value="<?php echo $info['University']; ?>">
						</td>
					</tr>
					<tr>	
						<td colspan=2>
							<hr />
						</td>
					</tr>
					<tr>
						<td align=right>
							Class time:
						</td>
						<td>
							 <input name=LectureClass size=40 value="<?php echo $info['LectureClass']; ?>">
						</td>
					</tr>

					<tr>
						<td align=right>
							Room:
						</td>
						<td>
							 <input name=Room size=15 value="<?php echo $info['Room']; ?>">
						</td>
					</tr>
                    
                    					<tr>	
						<td colspan=2>
							<hr />
						</td>
					</tr>
                    
                    <tr>
						<td align=right>
							Register Code: 
						</td>
						<td>
							 <input name=regcod size=40 value="<?php echo $info['regcod']; ?>">
						</td>
					</tr>
                    
                    <tr>
						<td align=right>
							Email Verification: 
						</td>
						<td>
							 Yes: <input name=emailVerification type=radio value="yes" <?php if($info['emailVerification'] == "yes"){ echo "checked"; } ?>>
                             No: <input name=emailVerification type=radio value="no" <?php if($info['emailVerification'] == "no"){ echo "checked"; } ?> >
						</td>
					</tr>
                    
					<tr>	
						<td colspan=2>
							<hr />
						</td>
					</tr>
					<tr>
						<td align=right valign=top>
							Text book(s):
						</td>
						<td>
							 <textarea name=TextBook cols=70 rows=7><?php echo trim($info['TextBook']); ?></textarea>
						</td>
					</tr>
					<tr>
						<td align=right valign=top>
							Evaluation (Grading Policy):
						</td>
						<td>
							<textarea name=Evaluation cols=70 rows=6><?php echo trim($info['Evaluation']); ?></textarea>
						</td>
					</tr>
					<tr>	
						<td colspan=2>
							<hr />
						</td>
					</tr>
					<tr>
						<td align=right>
							Instructor Name:
						</td>
						<td>
							 <input name=Ins_Name size=30 value="<?php echo $info['Instructor']['Name']; ?>">
						</td>
					</tr>
					<tr>
						<td align=right>
							Email:
						</td>
						<td>
							 <input name=Ins_Email size=40 value="<?php echo $info['Instructor']['Email']; ?>">
						</td>
					</tr>
					<tr>
						<td align=right>
							Homepage:
						</td>
						<td>
							 <input name=Ins_HomePage size=40 value="<?php echo $info['Instructor']['HomePage']; ?>">
						</td>
					</tr>
					<tr>	
						<td colspan=2>
							<hr />
						</td>
					</tr>					
<?php
if (isset($info['TA']) && count($info['TA'])>0)
{
	for ($i=0 ; $i<count($info['TA']) ; $i++)
	{
		if (isset($_POST["TA{$i}_Name"]))
		{
			$info['TA'][$i]['Name'] = $_POST["TA{$i}_Name"];
		}
		if (isset($_POST["TA{$i}_Email"]))
		{
			$info['TA'][$i]['Email'] = $_POST["TA{$i}_Email"];
		}
		if (isset($_POST["TA{$i}_HomePage"]))
		{
			$info['TA'][$i]['HomePage'] = $_POST["TA{$i}_HomePage"];
		}
?>					
					<tr>
						<td align=right>
							Teacher Assistant (<?php echo $i+1; ?>) Name:
						</td>
						<td>
							 <input name=TA<?php echo $i; ?>_Name size=30 value="<?php echo $info['TA'][$i]['Name']; ?>">
						</td>
					</tr>
					<tr>
						<td align=right>
							Email:
						</td>
						<td>
							 <input name=TA<?php echo $i; ?>_Email size=40 value="<?php echo $info['TA'][$i]['Email']; ?>">
						</td>
					</tr>
					<tr>
						<td align=right>
							Homepage:
						</td>
						<td>
							 <input name=TA<?php echo $i; ?>_HomePage size=50 value="<?php echo $info['TA'][$i]['HomePage']; ?>">
							 <input type=submit value="Delete this TA" 
								onclick="param1.value='delTA';param2.value='<?php echo $i; ?>';">
						</td>
					</tr>
					<tr>	
						<td colspan=2>
							<hr />
						</td>
					</tr>
<?php
	}
}
?>
					<tr>
						<td align=center colspan=2>
							<input type=submit value="  Edit  ">
							<input type=button value=" Cancel " 
								onclick="document.location='<?php echo getInternallink("syllabus","syllabus"); ?>';">
						</td>
					</tr>
					<tr>	
						<td colspan=2>
							<hr />
						</td>
					</tr>
					<tr>
						<td colspan=2 align=right>
							<input type=submit value="Add new Teacher Assistant" 
								onclick="param1.value='addTAFrm';">
						</td>
					</tr>
					<tr>
						<td colspan=2 align=right>
							<input type=submit value="Edit Logo"
								onclick="param1.value='editLogoFrm';">
						</td>
					</tr>
				</table>
			</form>
		</td>
	</tr>
</TABLE>
<?php
}
?>
