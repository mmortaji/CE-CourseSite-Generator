<?php
	if (!isset($indexFile) || trim(basename($_SERVER['PHP_SELF'])) != trim($indexFile))
	{
		die('You can not access this page directly.');
	}
    
	$currentTag = "";
    $titleValue = "";
    $dateValue = "";
    $comment = "";
    $events = array();

function calCharacterData($parser, $data)
{
     global $currentTag,$dateValue,$titleValue,$comment;
     if (strcmp($currentTag,"Date") == 0)
     {
          $dateValue .= $data;
     }
     elseif (strcmp($currentTag,"Topic") == 0)
     {
          $titleValue .= $data;
     }
     elseif ($currentTag == "Comment")
     {
          $comment .= $data;
     }
}

function calStartElement($parser, $name, $attr)
{
         global $currentTag;
         $currentTag = $name;
}

function calEndElement($parser, $name)
{
         global $currentTag,$dateValue,$titleValue,$events,$comment;
         if (strcmp($name,"Event")==0)
         {
			 $events[] = array("Topic" => $titleValue,
									 "Date" => $dateValue,
									 "Comment" => $comment);
             $dateValue = "";
             $titleValue = "";
             $comment = "";
         }
}

function parseEvents()
{
	global $events,$events,$currentTag,$titleValue,$dateValue;
	$xmlfile = "calendar/calendar.xml";
	$events = array();
	$currentTag = "";
	$titleValue = "";
	$dateValue = "";

	$xmlParser = xml_parser_create();
	xml_set_element_handler($xmlParser,"calStartElement","calEndElement");
	xml_set_character_data_handler($xmlParser,"calCharacterData");
	xml_parser_set_option($xmlParser,XML_OPTION_CASE_FOLDING,false);
	if (! ($fp = fopen($xmlfile,"r")) )
	{
		die("Could not open $xmlfile for reading.");
	}
	while (($data = fread($fp,4096)))
	{
	   if (!xml_parse($xmlParser,$data,feof($fp)))
	   {
			die(sprintf("XML error at line %d column %d : %s",
								 xml_get_current_line_number($xmlParser),
								 xml_get_current_column_number($xmlParser),
								 xml_error_string(xml_get_error_code($xmlParser))));
	   }
	}
	fclose($fp);
	xml_parser_free($xmlParser);
	$temp = array();
	for ($i=0 ; $i<count($events) ; $i++)
	{
		for ($j=$i+1 ; $j<count($events) ; $j++)
		{
			if ($events[$i]['Date'] > $events[$j]['Date'])
			{
				$temp = $events[$i];
				$events[$i] = $events[$j];
				$events[$j] = $temp;
			}
		}
	}
	return $events;
}
?>
