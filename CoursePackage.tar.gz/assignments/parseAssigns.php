<?php
if (!isset($indexFile) || trim(basename($_SERVER['PHP_SELF'])) != trim($indexFile))
{
	die('You can not access this page directly.');
}

    $currentTag = "";
    $comment = "";
    $fileComment = "";
    $dueDate = "";
    $fileValue = "";
	$titleValue = "";
	$dirValue = "";
    $assigns = array();
	$assignfiles = array();
    

function assignCharacterData($parser, $data)
{
     global $currentTag,$fileValue,$dueDate,$comment,$fileComment,$dirValue,$titleValue;
     if (strcmp($currentTag,"Name") == 0)
     {
          $fileValue .= $data;
     }
     elseif ( $currentTag == "DueDate")
     {
          $dueDate .= $data;
          
     }
     elseif ($currentTag == "FileComment")
     {
		$fileComment .= $data;
	 }
	 elseif ($currentTag == "Comment")
	 {
		 $comment .= $data;
	 }
	 elseif ($currentTag == "Title")
	 {
			 $titleValue .= $data;
	 }
	 elseif ($currentTag == "Dir")
	 {
			 $dirValue .= $data;
	 }
}

function assignStartElement($parser, $name, $attr)
{
         global $currentTag;
         $currentTag = $name;
}

function assignEndElement($parser, $name)
{
	global $currentTag,$fileValue,$dueDate,$titleValue,$dirValue,$assignfiles,$assigns,$comment,$fileComment;
	if ($name == "File")
	{
		$assignfiles[] = array("FileName" => trim($fileValue),
						"FileComment" => trim($fileComment));
		$fileValue = "";
		$fileComment = "";
	}
	elseif ($name == "Assignment")
	{
			$assigns[] = array("Title" => trim($titleValue),
								"Comment" => trim($comment),
								"Dir" => trim($dirValue),
								"Files" => $assignfiles,
								"DueDate" => trim($dueDate));
			$titleValue = "";
			$comment = "";
			$dirValue = "";
			$assignfiles = array();
			$dueDate = "";			
	}
}

function parseAssigns()
{
	global $assigns;
	$xmlfile = "assignments/assigns.xml";

	$xmlParser = xml_parser_create();
	xml_set_element_handler($xmlParser,"assignStartElement","assignEndElement");
	xml_set_character_data_handler($xmlParser,"assignCharacterData");
	xml_parser_set_option($xmlParser,XML_OPTION_CASE_FOLDING,false);
	if (! ($fp = fopen($xmlfile,"r")) )
	{
		die("Could not open $xmlfile for reading.");
	}
	while (($data = fread($fp,4096)))
	{
	   if (!xml_parse($xmlParser,$data,feof($fp)))
	   {
			die(sprintf("XML error at line %d column %d : %s",
								 xml_get_current_line_number($xmlParser),
								 xml_get_current_column_number($xmlParser),
								 xml_error_string(xml_get_error_code($xmlParser))));
	   }
	}
	fclose($fp);
	xml_parser_free($xmlParser);
	return $assigns;
}
?>
