<?php
	if (!isset($indexFile) || trim(basename($_SERVER['PHP_SELF'])) != trim($indexFile) && !defined('INSTALL'))
	{
		die('You can not access this page directly.');
	}
?>
<?php
    $currentTag = "";
    $currentCategory = "Course";
    $NameValue = "";
    $EmailValue = "";
    $HomePageValue = "";
    $startDateValue = "";
    $info = array();
	$info['TA'] = array();

function infoCharacterData($parser, $data)
{
     global $currentTag,$currentCategory,$info,$NameValue,$EmailValue,$HomePageValue,$startDateValue;
     if (trim($data) == "") return;
     if ($currentCategory == "Course")
     {
		 if (!isset($info[$currentTag]))
		 {
			 $info[$currentTag] = "";
		 }
		 $info[$currentTag] .= $data;
	 }
	 elseif ($currentCategory == "TA")
	 {
		 $var = $currentTag."Value";
		 $$var .= $data;
	 }
	 else
	 {
		 $info[$currentCategory][$currentTag] .= $data;
	 }
}

function infoStartElement($parser, $name, $attr)
{
	global $currentTag,$currentCategory,$info;
    if ($name=="Instructor" || $name=="TA")
    {
		$currentCategory = $name;
		$currentTag = "";
	}
	elseif ($name != "Course")
	{
		 $currentTag = $name;
		 if ($currentCategory == "Course")
		 {
		 	 $info[$name] = "";
		 }
		 elseif ($currentCategory == "Instructor")
		 {
		 	$info[$currentCategory][$name] = "";
		 }
	}
}

function infoEndElement($parser, $name)
{
	global $currentTag,$info,$currentCategory,$NameValue,$EmailValue,$HomePageValue,$startDateValue;
	static $TAnum=0;
	if ($name == "Instructor" || $name == "TA")
	{
		$currentCategory = "Course";
		if ($name == "TA")
		{
			$info['TA'][] = array("Name" => trim($NameValue),
						 "Email" => trim($EmailValue),
						 "HomePage" => trim($HomePageValue));
			$NameValue = "";
			$EmailValue = "";
			$HomePageValue = "";
		}
	}
}

function parseCourseInfo()
{
    global $info,$currentCategory,$currentTag,$NameValue,$EmailValue,$HomePageValue,$StartDateValue;
    $xmlfile = "syllabus/courseinfo.xml";
	$currentTag = "";
    $currentCategory = "Course";
    $NameValue = "";
    $EmailValue = "";
    $HomePageValue = "";
    $startDateValue = "";
    $info = array();
	$info['TA'] = array();


      $xmlParser = xml_parser_create();
      xml_set_element_handler($xmlParser,"infoStartElement","infoEndElement");
      xml_set_character_data_handler($xmlParser,"infoCharacterData");
      xml_parser_set_option($xmlParser,XML_OPTION_CASE_FOLDING,false);
      if (! ($fp = fopen($xmlfile,"r")) )
      {
            die("Could not open $xmlfile for reading.");
      }
      while (($data = fread($fp,4096)))
      {
           if (!xml_parse($xmlParser,$data,feof($fp)))
           {
                die(sprintf("XML error at line %d column %d : %s",
                                     xml_get_current_line_number($xmlParser),
                                     xml_get_current_column_number($xmlParser),
                                     xml_error_string(xml_get_error_code($xmlParser))));
           }
      }
      fclose($fp);
      xml_parser_free($xmlParser);
//	  echo "<pre>";
//	  print_r($info);
//    echo "</pre>";
//    die();

      return $info;
}
?>
