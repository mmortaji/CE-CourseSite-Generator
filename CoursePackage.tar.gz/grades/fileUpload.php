<?php
if (!$_SESSION['isAdmin'])
{
	die("ACCESS DENIED");
}
require_once 'parseGrades.php';
require_once 'includes/fileUpload.php';

if (isset($_GET['cmd']) && $_GET['cmd']=="do")
{
	$newFile = "grades/files/".$_FILES["userfile"]["name"];
	if (file_exists($newFile))
	{
		$newFile = get_unexisting_file_name($newFile);
	}
	if (!is_uploaded_file($_FILES["userfile"]["tmp_name"]))
	{
		show_error("Error in uploading file");
	}
	else
	{
		if (!move_uploaded_file($_FILES["userfile"]["tmp_name"],$newFile))
		{
			show_error("An error occured whilt trying to upload your file.");
		}
		else
		{
			if (!isset($_POST['objStart']))
			{
					$_POST['objStart'] = "";
					$_POST['objEnd'] = "";
			}
			chmod($newFile,0644);
			$grades = parseGrades();
			$newgrades = array();
			$newgrades[] = array("File" => $newFile,
								"Type" => "File",
								"Title" => trim(rawurldecode($_POST['name'])),
								"Comment" => trim(rawurldecode($_POST['comment'])),
								"Objections" => array(),
								"ObjectionStart" => trim(rawurldecode($_POST['objStart'])),
								"ObjectionEnd" => trim(rawurldecode($_POST['objEnd'])));
			$grades = array_merge($newgrades,$grades);
			require 'writeGrades.php';
			url_redirect(getInternallink("grades","grades"));
		}
	}		
}
else
{
?>
<table width=97% align=center cellspacing=0 cellpadding=0>
	<tr>
		<td>
			<?php createSectionTitle("Upload Grades File"); ?>
		</td>
	</tr>
	<tr>
		<td>
			<br/>
			<form method=post enctype="multipart/form-data" action="<?php echo getInternallink("grades","fileUpload","cmd=do"); ?>">
				<table class=blockcontent2 width=70% align=center>
					<tr>
						<td align=right>
							<br/><br/>
							Grades File:
						</td>
						<td>
							<br/><br/>
							<input name=userfile type=file size=40>
						</td>
					</tr>
					<tr>
						<td align=center colspan=2>
							<br/>
							<input type=submit value=" Upload ">
							<input type=button value=" Cancel " onclick="document.location='<?php echo getInternallink("grades","grades"); ?>';">
							<br/><br/>
						</td>
					</tr>
				</table>
				<input type=hidden value="<?php echo rawurlencode($_GET['name']); ?>" name=name>
				<input type=hidden value="<?php echo rawurlencode($_GET['comment']); ?>" name=comment>
				<?php
				if (isset($_GET['objStart'])) 
				{
				?>
				<input type=hidden value="<?php echo rawurlencode($_GET['objStart']); ?>" name=objStart>
				<input type=hidden value="<?php echo rawurlencode($_GET['objEnd']); ?>" name=objEnd>
				<?php
				}
				?>
			</form>				
		</td>
	</tr>
</table>
<?php
}
?>
