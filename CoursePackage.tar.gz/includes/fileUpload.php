<?php 

function search_img_in_html($htmlFile)
{
	$imgFilePath = array();

	$fp = fopen($htmlFile, "r") or die('<center>can not open file</center>');

	$buffer = fread( $fp, filesize($htmlFile) ) or die('<center>can not read file</center>');;
	
	$imgTagList = array();
	$imgPathList = array();

	if ( preg_match_all('~<[[:space:]]*img[^>]*>~i', $buffer, $matches) )
	{
		$imgTagList = $matches[0];
	}

	fclose ($fp);
	unset($buffer);

	if ( sizeof($imgTagList)  > 0)
	{
		foreach($imgTagList as $thisImgTag)
		{
			if ( preg_match('~src[[:space:]]*=[[:space:]]*[\"]{1}([^\"]+)[\"]{1}~i', 
							$thisImgTag, $matches) )
			{
				$imgPathList[] = $matches[1];
			}
		}

		$imgPathList = array_unique($imgPathList);		// remove duplicate entries
	}

	return $imgPathList;

}

function create_unexisting_directory($desiredDirName)
{

    $finalName = get_unexisting_file_name($desiredDirName);
    //die($finalName);	
	if ( mkdir($finalName, 0755) )
	{
		return $finalName;
	}
	else
	{
		return false;
	}
}

function get_unexisting_file_name($desiredDirName)
{
	$nb = '';
    
    $fileName = $desiredDirName;

	while ( file_exists($fileName.$nb) )
	{
		$nb += 1;
	}

    return $fileName.$nb;
}

function move_uploaded_file_collection_into_directory($uploadedFileCollection, $destPath)
{
    $uploadedFileNb = count($uploadedFileCollection['name']);
	$newFileList = array();
	for ($i=0; $i < $uploadedFileNb; $i++)
	{

		if (is_uploaded_file($uploadedFileCollection['tmp_name'][$i]))
		{
            if ( move_uploaded_file($uploadedFileCollection['tmp_name'][$i],
                                    $destPath.'/'.$uploadedFileCollection['name'][$i]) )
			{
				$newFileList[] = basename($destPath).'/'.$uploadedFileCollection['name'][$i];
				chmod(dirname($_SERVER['SCRIPT_FILENAME'])."/".$destPath."/".$uploadedFileCollection['name'][$i],0644);
			}
            else
            {
            	die('<center>can not move uploaded file</center>');
            }
		}
	}
	return $newFileList;
}

function replace_img_path_in_html_file($originalImgPath, $newImgPath, $htmlFile)
{
	/*
	 * Open the old html file and replace the src path into the img tag
	 */

	$fp = fopen($htmlFile, 'r') or die ('<center>cannot open file</center>');

	$newHtmlFileContent = "";
	while ( !feof($fp) )
	{
		$buffer = fgets($fp, 4096);

		for ($i = 0, $fileNb = count($originalImgPath); $i < $fileNb ; $i++)
		{
			$buffer = str_replace(	$originalImgPath[$i],
									'./'.$newImgPath[$i],
									$buffer);
		}

		$newHtmlFileContent .= $buffer;
	}

	fclose ($fp) or die ('<center>cannot close file</center>');;

	/*
	 * Write the resulted new file
	 */

	$fp = fopen($htmlFile, 'w')      or die('<center>cannot open file</center>');
	fwrite($fp, $newHtmlFileContent) or die('<center>cannot write in file</center>');
}
?>
