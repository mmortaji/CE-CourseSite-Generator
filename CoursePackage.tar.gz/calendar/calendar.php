<?php
	if (!isset($indexFile) || trim(basename($_SERVER['PHP_SELF'])) != trim($indexFile))
	{
		die('You can not access this page directly.');
	}
	require 'parseCalendar.php';
?>
<TABLE cellSpacing=0 cellPadding=0  border=0 width="97%" align=center>
	<TR>
		<TD>
			<?php createSectionTitle('Calendar'); ?>
		</TD>
	</TR>
<?php
if ($_SESSION['isAdmin'] and !$_SESSION['isTa'] and (!$_SESSION['isStudent']) )
{
	if (isset($_GET['cmd']) && $_GET['cmd'] == "addFrm")
	{
?>
	<tr>
		<td>
			<form method=post action="<?php echo getInternallink("calendar","calendar","cmd=add"); ?>">
				<table class=blockcontent2 align=center cellspacing=5>
					<tr>
						<td>
							<br/>
						</td>
					</tr>
					<tr>
						<td align=right>
							Year:
						</td>
						<td>
						<?php
							require_once 'includes/shamsi.php';
							list($M_y,$M_m,$M_d) = explode("-",date("Y-m-d"));
							list($y,$m,$d) = Miladi_to_Shamsi($M_y,$M_m,$M_d);

							echo '<select name="year">';
							for ($year=$y-2 ; $year<$y+5 ; $year++)
							{
								echo "<option value=\"$year\"";
								if ($year == $y)
								{
									echo " selected";
								}
								echo ">$year</option>\n";
							}
							echo "</select>\n";
							echo "&nbsp;&nbsp;&nbsp;Month: &nbsp;";
							echo "<select name=\"month\">\n";
							for ($i=1 ; $i<13 ; $i++)
							{
								echo "<option value=\"$i\"";
								if ($i==$m)
								{
									echo " selected";
								}
								echo ">";
								if ($i<10)
								{
									echo "0";
								}
								echo "$i</option>\n";
							}
							echo "</select>\n";

							echo "&nbsp;&nbsp;&nbsp;Day: &nbsp;";
							echo "<select name=\"day\">\n";
							for ($i=1 ; $i<32 ; $i++)
							{
								echo "<option value=\"$i\"";
								if ($i==$d)
								{
									echo " selected";
								}
								echo ">";
								if ($i<10)
								{
									echo "0";
								}
								echo "$i</option>\n";
							}
							echo "</select>\n";
						?>
						</td>
					</tr>
					<tr>
						<td align=right>
							Topic:
						</td>
						<td>
							 <input name=eventTopic size=60>
						</td>
					</tr>
					<tr>
						<td align=right>
							&nbsp;&nbsp;Comments:
						</td>
						<td>
							<input name=comments size=80>
						</td>
					</tr>
					<tr>
						<td align=center colspan=2>
							<input type=submit value="  Add  ">
							<input type=button value=" Cancel "
								onclick="document.location='<?php echo getInternallink("calendar","calendar"); ?>';">
							<br/><br/>
						</td>
					</tr>
				</table>
			</form>
		</td>
	</tr>
<?php
	}
	elseif (isset($_GET['cmd']) && $_GET['cmd'] == "editFrm")
	{
		$events = parseEvents();
		$id = $_GET['id'];
?>
	<tr>
		<td>
			<form method=post action="<?php echo getInternallink("calendar","calendar","cmd=edit&amp;id=$id"); ?>">
				<table class=blockcontent2 align=center width="40%" cellspacing=5>
					<tr>
						<td>
							<br/>
						</td>
					</tr>
					<tr>
						<td align=right>
							Year:
						</td>
						<td>
						<?php
							require_once 'includes/shamsi.php';
							list($y,$m,$d) = explode("/",$events[$id]['Date']);
							echo '<select name="year">';
							for ($year=$y-2 ; $year<$y+5 ; $year++)
							{
								echo "<option value=\"$year\"";
								if ($year == $y)
								{
									echo " selected";
								}
								echo ">$year</option>\n";
							}
							echo "</select>\n";
							echo "&nbsp;&nbsp;&nbsp;Month: &nbsp;";
							echo "<select name=\"month\">\n";
							for ($i=1 ; $i<13 ; $i++)
							{
								echo "<option value=\"$i\"";
								if ($i==$m)
								{
									echo " selected";
								}
								echo ">";
								if ($i<10)
								{
									echo "0";
								}
								echo "$i</option>\n";
							}
							echo "</select>\n";

							echo "&nbsp;&nbsp;&nbsp;Day: &nbsp;";
							echo "<select name=\"day\">\n";
							for ($i=1 ; $i<32 ; $i++)
							{
								echo "<option value=\"$i\"";
								if ($i==$d)
								{
									echo " selected";
								}
								echo ">";
								if ($i<10)
								{
									echo "0";
								}
								echo "$i</option>\n";
							}
							echo "</select>\n";
						?>
						</td>
					</tr>
					<tr>
						<td align=right>
							Topic:
						</td>
						<td>
							 <input name=eventTopic size=60 value="<?php echo htmlspecialchars(trim($events[$id]['Topic'])); ?>">
						</td>
					</tr>
					<tr>
						<td align=right>
							&nbsp;&nbsp;Comments:
						</td>
						<td>
							<input name=comments size=80 value="<?php echo htmlspecialchars(trim($events[$id]['Comment'])); ?>"
						</td>
					</tr>
					<tr>
						<td align=center colspan=2>
							<input type=submit value="  Edit  ">
							<input type=button value=" Cancel "
								onclick="document.location='<?php echo getInternallink("calendar","calendar"); ?>';">
							<br/><br/>
						</td>
					</tr>
				</table>
			</form>
		</td>
	</tr>
<?php
	}
	else
	{
?>
	<tr>
		<td align=right>
			<form method=post action="<?php echo getInternallink("calendar","calendar","cmd=addFrm"); ?>">
				<input type=submit value="Add new event">
			</form>
		</td>
	</tr>
<?php
	}
	if (isset($_GET['cmd']) && $_GET['cmd'] == "add")
	{
		if (trim($_POST['eventTopic']) == "")
		{
			show_error("Invalid Topic");
		}
		$events = parseEvents();
		$date = trim($_POST['year'])."/";
		if ($_POST['month'] < 10)
		{
			$date .= "0";
		}
		$date .= trim($_POST['month'])."/";
		if ($_POST['day'] < 10)
		{
			$date .= "0";
		}
		$date .= trim($_POST['day']);
		$events[] = array("Date" => $date,
							"Topic" => trim($_POST['eventTopic']),
							"Comment" => trim($_POST['comments']));
		require 'writeEvents.php';
		url_redirect(getInternallink("calendar","calendar"));
	}
	elseif (isset($_GET['cmd']) && $_GET['cmd'] == "edit")
	{
		if (trim($_POST['eventTopic']) == "")
		{
			show_error("Invalid Topic");
		}
		$events = parseEvents();
		$date = trim($_POST['year'])."/";
		if ($_POST['month'] < 10)
		{
			$date .= "0";
		}
		$date .= trim($_POST['month'])."/";
		if ($_POST['day'] < 10)
		{
			$date .= "0";
		}
		$date .= trim($_POST['day']);
		$events[$_GET['id']] = array("Date" => $date,
							"Topic" => trim($_POST['eventTopic']),
							"Comment" => trim($_POST['comments']));
		require 'writeEvents.php';
		url_redirect(getInternallink("calendar","calendar"));
	}
	elseif (isset($_GET['cmd']) && $_GET['cmd'] == "del")
	{
		$events = parseEvents();
		$new = array();
		$j=0;
		for ($i=0 ; $i<count($events) ; $i++)
		{
			if ($i != $_GET['id'])
			{
				$new[$j++] = $events[$i];
			}
		}
		$events = $new;
		require 'writeEvents.php';
		url_redirect(getInternallink("calendar","calendar"));
	}
}
$events = parseEvents();

if (count($events) == 0 && !$_SESSION['isAdmin'])
{
	show_msg('No event yet.');
}
else
{
?>
	<tr>
		<td>
			<table width="90%" align=center class=table2 cellspacing=1 cellpadding=3>
				<tr>
					<th width=1%>
						&nbsp;Date&nbsp;
					</th>
					<th>
						&nbsp;Topic&nbsp;
					</th>
					<th>
						Comments
					</th>
					<?php
					if (($_SESSION['isAdmin'] or $_SESSION['isTa']) && (!$_SESSION['isStudent']) )
					{
					?>
					<th width=1>
						&nbsp;Edit&nbsp;
					</th>
					<th width=1>
						&nbsp;Delete&nbsp;
					</th>
					<?php
					}
					?>
				</tr>
<?php
$j=1;
for ($i=0 ; $i<count($events) ; $i++)
{
?>
				<tr>
					<td class=row<?php echo $j; ?> align=center>
						&nbsp;&nbsp;<?php echo trim($events[$i]['Date']); ?>&nbsp;&nbsp;
					</td>
					<td class=row<?php echo $j; ?>>
						&nbsp;&nbsp;<?php echo htmlspecialchars(trim($events[$i]['Topic'])); ?>
					</td>
					<td class=row<?php echo $j; ?>>
						&nbsp;&nbsp;<?php echo htmlspecialchars(trim($events[$i]['Comment'])); ?>
					</td>
					<?php
					if (($_SESSION['isAdmin'] or $_SESSION['isTa']) && (!$_SESSION['isStudent']) )
					{
					?>
					<td align=center class=row<?php echo $j; ?>>
						<a href="<?php echo getInternallink("calendar","calendar","cmd=editFrm&amp;id=$i"); ?>">
							<img src="images/edit.gif" border=0>
						</a>
					</td>
					<td align=center class=row<?php echo $j; ?>>
						<a href="<?php echo getInternallink("calendar","calendar","cmd=del&amp;id=$i"); ?>"
							onclick="return confirm('Are you sure to delete this event?');">
							<img src="images/delete.gif" border=0>
						</a>
					</td>
					<?php
					}
					?>
				</tr>
<?php
	$j = ($j==2 ? 1 : 2);
}
?>
			</table>
		</td>
	</tr>
<?php
}
?>
</TABLE>
