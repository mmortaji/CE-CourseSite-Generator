<?php die("ACCESS DENIED");?>
