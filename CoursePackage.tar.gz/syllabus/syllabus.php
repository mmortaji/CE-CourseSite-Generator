<?php
	if (!isset($indexFile) || trim(basename($_SERVER['PHP_SELF'])) != trim($indexFile))
	{
		die('You can not access this page directly.');
	}
?>
<TABLE cellSpacing=0 cellPadding=0 width="97%" border=0 align=center>
	<tr>
		<td>
			<?php createSectionTitle('Course Syllabus'); ?>
		<td>
	</TR>
	<?php
	if ($_SESSION['isAdmin'] and !$_SESSION['isTa'] and (!$_SESSION['isStudent']) )
	{
	?>
	<tr>
		<td align=right>
			<input type=button value="Edit Course Information" onclick="document.location='<?php echo getInternallink("syllabus","edit"); ?>';">
			<br /><br />
		</td>
	</tr>
	<?php
	}
	?>
	<tr>
		<TD>
			<table width=97% align=center>
				<tr>
					<td>
						<TABLE cellSpacing=0 cellPadding=2 width="100%" border=0>
							<TR>
								<TD class=titlebar>
								  &nbsp;<?php echo "$Course[Name] - $Course[Number]"; ?>
								</TD>
							</TR>
							<tr>
								<td class=table1>
									<ul>
										<?php echo "<li>Credit: $Course[Credit] Units</li>";
												 echo "<li>Semester: $Course[Semester]</li>";?>
										<li>Group: &nbsp;<?php echo $Course['Group']; ?></li>
										<li>Lecture Class:
										&nbsp;<?php echo "$Course[LectureClass]"; ?>
										</li>
										<li>Room:
										&nbsp;<?php echo "$Course[Room]"; ?></li>
                                        
								</td>
							</tr>
						</TABLE>
						<br />
					</td>
				</tr>
				<tr>
					<td>
						<TABLE cellSpacing=0 cellPadding=2 width="100%" border=0>
							<TR>
								<TD class=titlebar>
								  &nbsp;Text Book(s)
								</TD>
							</TR>
							<tr>
								<td class=table1>
									<ul>
										<li><?php
											if (trim($Course['TextBook']) != "")
											{
												echo str_replace("  "," &nbsp;",nl2br(htmlspecialchars($Course['TextBook'])));
											}
											else
											{
												 echo "Not specified yet.";
											}
											?></li>
								</td>
							</tr>
						</TABLE>
						<br />
					</td>
				</tr>


<?php if($_SESSION["isAdmin"]){ ?>
				<tr>
					<td>
						<TABLE cellSpacing=0 cellPadding=2 width="100%" border=0>
							<TR>
								<TD class=titlebar>
								  &nbsp;Register
								</TD>
							</TR>
							<tr>
								<td class=table1>
									<ul>
										<li>
									  <?php
echo "Register Code:".$Course['regcod'];


echo "</li><li>";
if($Course['emailVerification'] == "yes"){
echo "Email Verification: enable";
}
else{
    echo "Email Verification: disable  ";
}
									  ?>
								</td>
							</tr>
						</TABLE>
						<br />
					</td>
				</tr>
                
                
                <?php } ?>

				<tr>
					<td>
						<TABLE cellSpacing=0 cellPadding=2 width="100%" border=0>
							<TR>
								<TD class=titlebar>
								  &nbsp;Instructor
								</TD>
							</TR>
							<tr>
								<td class=table1>
									<ul>
										<li>
									  <?php
										  if ($Course['Instructor']['HomePage'] != "")
										  {
											echo '<A href="'.$Course['Instructor']['HomePage'].'">'.$Course['Instructor']['Name']."</A>";
										  }
										  else
										  {
											echo $Course['Instructor']['Name'];
										  }
										  if ($Course['Instructor']['Email'] != "")
										  {
											echo '&nbsp;&nbsp&nbsp;e-mail: <A href="mailto:'.$Course['Instructor']['Email'].'">';
											echo $Course['Instructor']['Email']."</A>";
										  }
									  ?>
								</td>
							</tr>
						</TABLE>
						<br />
					</td>
				</tr>
<?php 
  if (isset($Course['TA']) && count($Course['TA'])>0)
									  {
                                          ?>
				<tr>
					<td>
						<TABLE cellSpacing=0 cellPadding=2 width="100%" border=0>
							<TR>
								<TD class=titlebar>
								  &nbsp;Teacher Assistants
								</TD>
							</TR>
							<tr>
								<td class=table1>
									<ul>
									<?php
									
										  reset($Course['TA']);
										  while (list($key,$value) = each($Course['TA']))
										  {
											echo '<li>';
											if ( $Course['TA'][$key]["HomePage"] != "" )
											{
												  echo '<A href="'.$Course['TA'][$key]["HomePage"].'">';
											}
											echo "&nbsp;";
											echo $Course['TA'][$key]["Name"];
											if ( $Course['TA'][$key]["HomePage"] != "" )
											{
											  echo '</A>';
											}
											if ( $Course['TA'][$key]["Email"] != "")
											{
											  echo ',&nbsp;&nbsp;e-mail: <A href="mailto:'.$Course['TA'][$key]["Email"].'">'.$Course['TA'][$key]["Email"].'</A>';
											}
											echo "</li>";
										  }
									  
									 
									?>
								</td>
							</tr>
						</TABLE>
						<br />
					</td>
				</tr>
                <?php }
                if (trim($Course['Evaluation']) != "")
												{
                 ?>

				<tr>
					<td>
						<TABLE cellSpacing=0 cellPadding=2 width="100%" border=0>
							<TR>
								<TD class=titlebar>
								  &nbsp;Evaluation [Grading Policy ]
								</TD>
							</TR>
							<tr>
								<td class=table1>
									<ul>
										<li>
											<?php
												
													echo str_replace("  "," &nbsp;",nl2br(htmlspecialchars($Course['Evaluation'])));
											
											?>
										</li>
								</td>
							</tr>
						</TABLE>
					</td>
				</tr>
                <?php } ?>
			</table>
		</TD>
	</TR>
</table>

