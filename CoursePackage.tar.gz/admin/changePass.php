<?php
if (!isset($indexFile) || trim(basename($_SERVER['PHP_SELF'])) != trim($indexFile))
{
	die('You can not access this page directly.');
}


$adminsFile = 'admin/admins.inf';
if (!file_exists($adminsFile))
{
		show_error("Couln't find administrators' file.");
}
$admins = file($adminsFile);
if (isset($_GET['cmd']))
{
	if ($_GET['cmd'] == "do")
	{
		for ($i=0 ; $i<count($admins) ; $i++)
		{
			list($admin,$pass) = explode("|",$admins[$i]);
			if (trim($admin) == trim($_SESSION['UserName']) and  md5(trim($_POST['oldPass'])) != trim($pass))
			{
				show_error("Invalid Old Password");
			}
		}
		if (trim($_POST['newPass1']) == "")
		{
			show_error("Invalid Password");
		}
		if ($_POST['newPass1'] != $_POST['newPass2'])
		{
			show_error("The two passwords are not identical");
		}
		$admins = file($adminsFile);
		for ($i=0 ; $i<count($admins) ; $i++)
		{
			list($admin,$pass,$semat,$email,$verify) = explode("|",$admins[$i]);
			if (trim($admin) == trim($_SESSION['UserName']))
			{
				$admins[$i] = trim($admin)."|".md5(trim($_POST['newPass1']))."|".trim($semat)."|".trim($email)."|".trim($verify);
			}
		}
		if (!($file = fopen($adminsFile,"w")))
		{
			die("Coudn't open $adminsFile for writing.");
		}
		for ($i=0 ; $i<count($admins) ; $i++)
		{
			$admins[$i] = trim($admins[$i]);
			if ($admins[$i] != "")
			{
				fputs($file,"$admins[$i]\n");
			}
		}
		fclose($file);
		url_redirect(getIndex(),"1","Your Password Changed.");
	}
}
?>
<table width=95% align=center>
	<tr>
		<td>
			<?php createSectionTitle('Change Password'); ?>
		</td>
	</tr>
	<tr>	
		<td>			
		</td>
	</tr>
	<tr>
		<td>
			<form method=post action="<?php echo getInternallink("admin","changePass","cmd=do"); ?>">			
			<table align=center class=blockcontent2 width=50%>
				<tr>
					<td>
						<br/>
					</td>
				</tr>	
				<tr>
					<td align=right>
						Old Password:
					</td>
					<td>
						<input name=oldPass type=password>
					</td>
				</tr>
				<tr>
					<td align=right>
						New Password:
					</td>
					<td>
						<input name=newPass1 type=password>
					</td>
				</tr>
				<tr>
					<td align=right>
						Retype New Password:
					</td>
					<td>
						<input name=newPass2 type=password>
					</td>
				</tr>
				<tr>
					<td align=center colspan=2>
						<input type=submit value=" Change ">
						<input type=button value=" Cancel " onclick="document.location='<?php echo getIndex(); ?>';">
						<br/><br/>
					</td>	
				</tr>
			</table>
			</form>
		</td>
	</tr>
</table>
