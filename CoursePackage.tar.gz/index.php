<?php
ob_start();
session_start();
error_reporting(E_ALL ^ E_NOTICE);

if (file_exists("install.php"))
{
	header("Location: http://$_SERVER[SERVER_NAME]".dirname($_SERVER['SCRIPT_NAME'])."/install.php");
	die();
}

define('FROM_INDEX',true);
if (isset($_SERVER['PATH_INFO']))
{
	$vars = explode("/",$_SERVER['PATH_INFO']);
	if (count($vars) % 2 == 0)
	{
		$vars[] = "";
	}
	for ($i=1 ; $i<count($vars) ; $i+=2)
	{
		if (strpos($vars[$i],"=") === false and strpos($vars[$i+1],"=") === false)
		{
			$_GET[$vars[$i]] = $vars[$i+1];
			$_REQUEST[$vars[$i]] = $vars[$i+1];
		}
		elseif (strpos($vars[$i],"=") === false)
		{
			$part_end = strpos($vars[$i+1],"&");
			if ($part_end === false)
			{
				$part_end = strlen($vars[$i+1]);
			}
			$_REQUEST[$vars[$i]] = $_GET[$vars[$i]] = substr($vars[$i+1],0,$part_end);
			$vars[$i+1] = substr($vars[$i+1],$part_end+1);
			while ($vars[$i+1] != "")
			{
				$part_end = strpos($vars[$i+1],"&");
				if ($part_end === false)
				{
					$part_end = strlen($vars[$i+1]);
				}
				if (strpos($vars[$i+1],"=") === false)
				{
					$_REQUEST[$vars[$i+1]] = $_GET[$vars[$i+1]] = "";
				}
				else
				{
					list($key,$value) = explode("=",substr($vars[$i+1],0,$part_end));
					$_REQUEST[$key] = $_GET[$key] = $value;
				}
				$vars[$i+1] = substr($vars[$i+1],$part_end+1);
			}
		}
		else
		{
			while ($vars[$i] != "")
			{
				$part_end = strpos($vars[$i],"&");
				if ($part_end === false)
				{
					$part_end = strlen($vars[$i]);
				}
				if (strpos(substr($vars[$i],0,$part_end),"=") === false)
				{
					$_REQUEST[substr($vars[$i],0,$part_end)] = $_GET[substr($vars[$i],0,$part_end)] = "";
				}
				else
				{
					list($key,$value) = explode("=",substr($vars[$i],0,$part_end));
					$_REQUEST[$key] = $_GET[$key] = $value;
				}
				$vars[$i] = substr($vars[$i],$part_end+1);
			}
		}
	}
}
//print_r($_GET);
require 'includes/common.php';
require 'includes/counter.php';
require_once 'users/checkLogin.php';

fixSlashes();

if (isset($_GET['section'])) $section = $_GET['section'];
if (isset($_GET['file'])) $file = $_GET['file'];
if (!isset($_SESSION['isAdmin'])) $_SESSION['isAdmin'] = false;
if (!isset($_SESSION['Logged_in'])) $_SESSION['Logged_in'] = false;
if (!isset($_SESSION['UserName'])) $_SESSION['UserName'] = "";
check_Login($_SESSION['UserName'],"",false);

if (isset($section)) {

	if (!isset($file))
	{
		$file = $section;
	}

	$file = trim($file);

	// if (ereg("\.\.",$file)) {
	// 	die("ACCESS DENIED");
	// }

    $filePath = "$section/$file.php";
    if (!file_exists($filePath)) {
        die("Sorry, such file doesn't exist... $filePath");
    }
    if (!$_SESSION['isAdmin'])
    {
		$items = parseItems();
		for ($i=0 ; $i<count($items) ; $i++)
		{
			 if (trim($items[$i]['type']) == "Internal")
			 {
				 if (trim($items[$i]['section']) == trim($section))
				 {
					 if ($items[$i]['disabled'])
					 {
						 die('This page is deactivated by website administrator');
					 }
					 else
					 {
						 break;
					 }
				 }
			 }
		}
	}
?>
<HTML>
	<?php makeHEAD($section); ?>
	<BODY>
		<DIV align=center>
			<?php showHeader();	?>
			<TABLE cellspacing=0 cellpadding=3 width=100% border=0>
				<TR>
					<TD vAlign=top width=160>
						<?php showMenu("."); ?>
					</TD>
    				<TD vAlign=top>
						<?php include $filePath; ?>
					</TD>
				</TR>
			</TABLE>
			<?php
				$files = array();
				if ($dir = @opendir("$section")) {
				  while (($f = readdir($dir)) !== false) {
					  if ($f != "." && $f != "..")
					  {
						  $files[] = "$section/$f";
					  }
				  }
				  closedir($dir);
				}
				showFooter($files); ?>
		</DIV>
	</BODY>
</HTML>
<?php
}
else {
    // Homepage contents
	require 'news/parseNews.php';
    $news = parseNews();
    require_once 'includes/shamsi.php';
?>
<HTML>
	<?php makeHEAD("Home","."); ?>
	<BODY>
		<DIV align=center>
			<?php showHeader();	?>
			<TABLE cellspacing=0 cellpadding=3 width=100% border=0>
			<TR>
				<TD vAlign=top width=160>
					<?php showMenu("."); ?>
				</TD>
   				<TD vAlign=top>
   					<TABLE width="97%" border=0 cellspacing=0 cellpadding=0 align=center>
					<?php if ($_SESSION['isAdmin'] and !$_SESSION['isTa'] and (!$_SESSION['isStudent']) ) {
							$themes = array();
							$themedir = dirname($_SERVER['SCRIPT_FILENAME'])."/themes";
							if ($dirhandle = opendir($themedir))
							{
								while ($file = readdir($dirhandle))
								{
									if ($file == "." || $file == "..")
									{
										continue;
									}
									if (is_dir("$themedir/$file"))
									{
										$themes[] = $file;
									}
									else
									{
										die("$themedir/$file");
									}
								}
							}
							else
							{
								show_error("Couldn't open themes directory.");
							}
							if (count($themes)>1)
							{
						?>
						<tr>
							<td align=right>
								<form method=post action="<?php echo getInternallink("admin","changeTheme"); ?>">
								<table align=right>
									<tr>
										<td align=right>
											Theme:
										</td>
										<td>
											<select name=themeName>
												<?php
												$curtheme = file("admin/theme.inf");
												$curtheme = $curtheme[0];
												for ($i=0 ; $i<count($themes) ; $i++)
												{
													echo "<option value=\"$themes[$i]\"";
													if ($themes[$i] == $curtheme)
													{
														echo " selected";
													}
													echo ">$themes[$i]</option>\n";
												}
												?>
											</select>
											<input type=submit value="Change">
										</td>
									</tr>
								</table>
								</form>
							</td>
						</tr>
					<?php }
					}
					?>
						<tr>
							<td>
								<br/>
							</td>
						</tr>
							<TR>
    						<td>
								<?php if (count($news)>0 || $_SESSION["isAdmin"]) {
									createSectionTitle('Announcments');
								} ?>
    						</td>
    					</TR>
						<?php if (($_SESSION['isAdmin'] or $_SESSION['isTa']) && (!$_SESSION['isStudent']) ) {  ?>
						<TR>
							<TD align=right>
								<form method=post action="<?php echo getInternallink("news","changeNews","cmd=AddFrm"); ?>">
									<input type=submit value='Add New Announcement'>
								</form>
							</TD>
						</TR>
						<?php
						}
						?>
					<tr>
							<td>
								<table width=95% align=center>
									<tr>
										<td>
											<?php
											   for ($i=0 ; $i<count($news) ; $i++)
											   {
											?>
											<TR>
												<TD>
												<TABLE cellSpacing=0 cellPadding=0 width="100%" border=0>
														<TR>
																<TD>
																	<TABLE class=titlebar width="100%" border=0>
																		<TBODY>
																			<TR>
																				<TD>&nbsp;
																				  <?php
																					  echo faDate($news[$i]["date"]);
																				  ?>
																				 </td>
																				 <td align=right>
																					<?php 
																						echo date("F d, Y h:i A",$news[$i]["date"]);
																					?>&nbsp;&nbsp;
																				</TD>
																				<?php if (($_SESSION['isAdmin'] or $_SESSION['isTa']) && (!$_SESSION['isStudent']) )
																				{
																				?>
																				<TD width=10 align=right>
																					<A href="<?php echo getInternallink("news","changeNews","cmd=edit&amp;id=$i"); ?>">
																					<IMG src=images/edit.gif
																					alt=Edit
																					border=0
																					width="11"
																					height="15"></A>&nbsp;
																				</TD>
																				<TD width=10 align=right>
																					<A href="<?php echo getInternallink("news","changeNews","cmd=delete&amp;id=$i"); ?>" onclick="return confirmation();">
																					<IMG src=images/delete.gif
																					alt=Delete
																					border=0
																					width="12"
																					height="14"></A>
																				</TD>

																				<?
																				}
																				?>
																			</TR>
																		</TBODY>
																	</TABLE>
																</TD>
															</TR>
													</TABLE>
													<TABLE align=center border=0 class=table1>
														<TR>
															<TD>
																<table width=97% align=center>
																	<tr>
																		<td>
																			<?php  if($news[$i]["rtl"] == 1){ echo "<div style='text-align :right'>"; } echo nl2br(str_replace("  "," &nbsp;",trim($news[$i]["content"]))); echo "</div>"; ?>
																		</td>
																	</tr>
																</table>
															</TD>
														</TR>
													</TABLE>
													<BR>
												</TD>
											</TR>
											<?php
											  }
											?>
										</td>
									</tr>
								</table>
							</td>
						</tr>
						<tr>
							<td>
								<table width=100% border=0>
									<tr>
										<td align=center class=gen>
											<b>Instructor:</b><br/>
											<a href="<?php echo $Course['Instructor']['HomePage']; ?>">
												<b><?php echo $Course['Instructor']['Name']; ?></b>
											</a>
											<?php
												if ($Course['Instructor']['Email'] != "") {
											?>
											<br/>
											<a href="mailto:<?php echo $Course['Instructor']['Email']; ?>">
												<b>(<?php echo $Course['Instructor']['Email']; ?>)</b>
											</a>
											<?php } ?>
											<br/><br/>
											<?php
											if ($Course['Credit'] != "") {
											 echo $Course['Credit']." Units<br/>";
											}
											if ($Course['LectureClass'] != "") {
											 echo $Course['LectureClass']."<br/>";
											}
											if ($Course['Room'] != "") {
											 echo "Room: ".$Course['Room']."<br/>";
											} ?>
										</td>
										<td align=right width=1%>
											<?php
												if (file_exists("syllabus/Logo")) { ?>
													<img src="syllabus/Logo" border=0 width=200>
											<? } else { ?>
												<br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/>
											<?php } ?>
										</td>
									</tr>
								</table>
							</td>
						</tr>

      				</TABLE>
      			</TD>
      		</TR>
      	</TABLE>
		<BR>
		<?php showFooter(array("news/news.xml",__FILE__)); ?>
	</DIV>
</BODY>
</HTML>

<SCRIPT>
function confirmation ()
{
         if (confirm(" Are you sure to delete this announcement?"))
             {return true;}
         else
             {return false;}
}
</SCRIPT>
<?php
ob_end_flush();
}

?>
