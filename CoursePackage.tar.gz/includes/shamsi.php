<?php

$M_days_in_month = array(31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31);
$S_days_in_month = array(31, 31, 31, 31, 31, 31, 30, 30, 30, 30, 30, 29);

function div($a, $b)
{
   return (int) ($a / $b);
}

function Miladi_to_Shamsi($M_y, $M_m, $M_d)
{
   global $M_days_in_month;
   global $S_days_in_month;

   $My = $M_y-1600;
   $Mm = $M_m-1;
   $Md = $M_d-1;

   $M_day_no = 365*$My+div($My+3,4)-div($My+99,100)+div($My+399,400);

   for ($i=0; $i < $Mm; ++$i)
      $M_day_no += $M_days_in_month[$i];
   if ($Mm>1 && (($My%4==0 && $My%100!=0) || ($My%400==0)))
      /* leap and after Feb */
      ++$M_day_no;
   $M_day_no += $Md;

   $S_day_no = $M_day_no-79;

   $S_np = div($S_day_no, 12053);
   $S_day_no %= 12053;

   $Sy = 979+33*$S_np+4*div($S_day_no,1461);

   $S_day_no %= 1461;

   if ($S_day_no >= 366) {
      $Sy += div($S_day_no-1, 365);
      $S_day_no = ($S_day_no-1)%365;
   }

   for ($i = 0; $i < 11 && $S_day_no >= $S_days_in_month[$i]; ++$i) {
      $S_day_no -= $S_days_in_month[$i];
   }
   $Sm = $i+1;
   $Sd = $S_day_no+1;


   return array($Sy, $Sm, $Sd);
}

function farsiNum($num)
{
    $faNum = "";
    for ($i=0 ; $i<strlen($num) ; $i++)
    {
        switch (substr($num,$i,1))
        {
            case '0':
                 $faNum .= "&#1632;";
                 break;
            case '1':
                 $faNum .= "&#1633;";
                 break;
            case '2':
                 $faNum .= "&#1634;";
                 break;
            case '3':
                 $faNum .= "&#1635;";
                 break;
            case '4':
                 $faNum .= "&#1636;";
                 break;
            case '5':
                 $faNum .= "&#1637;";
                 break;
            case '6':
                 $faNum .= "&#1638;";
                 break;
            case '7':
                 $faNum .= "&#1639;";
                 break;
            case '8':
                 $faNum .= "&#1640;";
                 break;
            case '9':
                 $faNum .= "&#1641;";
                 break;
            default:
                 $faNum .= substr($num,$i,1);
            }
    }
    return $faNum;
}

function shamsiMonth($m)
{
	switch ($m)
	{
		case 1:
			return "&#1601;&#1585;&#1608;&#1585;&#1583;&#1740;&#1606;";
		case 2:
			return "&#1575;&#1585;&#1583;&#1740;&#1576;&#1607;&#1588;&#1578;";
		case 3:
			return "&#1582;&#1585;&#1583;&#1575;&#1583;";
		case 4:
			return "&#1578;&#1740;&#1585;";
		case 5:
			return "&#1605;&#1585;&#1583;&#1575;&#1583;";
		case 6:
			return "&#1588;&#1607;&#1585;&#1740;&#1608;&#1585;";
		case 7:
			return "&#1605;&#1607;&#1585;";
		case 8:
			return "&#1570;&#1576;&#1575;&#1606;";
		case 9:
			return "&#1570;&#1584;&#1585;";
		case 10:
			return "&#1583;&#1740;";
		case 11:
			return "&#1576;&#1607;&#1605;&#1606;";
		case 12:
			return "&#1575;&#1587;&#1601;&#1606;&#1583;";
	}
}

function faDate($date)
{
	list($y,$m,$d) = explode("-",date("Y-m-d",$date));
	list($y,$m,$d) = Miladi_to_shamsi($y,$m,$d);
	$res = "$y-";
	if ($m<10)
	{
		$res .= "0";
	}
	$res .= "$m-";
	if ($d<10)
	{
		$res .= "0";
	}
	$res .= $d;
	return $res;
}

?>
