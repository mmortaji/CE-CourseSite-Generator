<?php
	if (!isset($indexFile) || trim(basename($_SERVER['PHP_SELF'])) != trim($indexFile))
	{
		die('You can not access this page directly.');
	}
?>



<?php
if (isset($_GET['cmd']) && !$_SESSION['isAdmin'] && $_GET['cmd']!="changeDir" && $_GET['cmd']!="goUp")
{
	die('ACCESS DENIED');
}

if (!isset($_SESSION['curDir']))
{
	$_SESSION['curDir'] = 'root';
}
$ResourceFile = "resources/$_SESSION[curDir]/resources.xml";
require 'parseResources.php';
require 'includes/fileUpload.php';

function deleteDir($dirname)
{
	if ($dir = opendir($dirname))
	{
		while (($file = readdir($dir)) !== false )
		{
			if ($file == "." || $file == "..")
			{
				continue;
			}
			if (is_dir("$dirname/$file"))
			{
				deleteDir("$dirname/$file");
			}
			else
			{
				unlink("$dirname/$file");
			}
		}
		closedir($dir);
	}
	else
	{
		echo "Couldn't read directory contents.";
	}
	if (!rmdir($dirname))
	{
		echo "Couldn't delete this directory";
	}
	return;
}


if (isset($_GET['cmd']) && $_GET['cmd'] == "addDirFrm")
{
?>
	<form method=post action="<?php echo getInternallink("resources","resources","cmd=addDir"); ?>">
		<table class=table2 align=center width=60%>
			<tr>
				<td class=blockhead align=center colspan=2>
					Make a new folder
				</td>
			</tr>
			<tr>
				<td>
					<br />
				</td>
			</tr>
			<tr>
				<td align=right>
					Folder Name:
				</td>
				<td>
					 <input name=dirName>
				</td>
			</tr>
			<tr>
				<td align=right>
					Folder Description:
				</td>
				<td valign=top>
					 <input name=dirComment size=40> &nbsp;<span class=comment>(optional)</span>
				</td>
			</tr>
			<tr>
				<td align=center colspan=2>
					<br />
					<input type=submit value="Create">
					<input type=button value="Cancel" onclick="document.location='<?php echo getInternallink("resources","resources"); ?>';">
					<br/ ><br />
				</td>
			</tr>
		</table>
	</form>
<?php
}
else if (isset($_GET['cmd']) && $_GET['cmd'] == "addDir")
{
	if (trim($_POST['dirName']) == "")
	{
		show_error("Invalid Folder Name.");
	}
	else
	{
		if (!@mkdir("resources/$_SESSION[curDir]/".trim($_POST['dirName']),0755))
		{
			show_error("Couln't create the new folder.");
		}
		else
		{
			$items = array_merge(array(array("Name" => trim($_POST['dirName']),
								"Type" => "Directory",
								"Comment" => trim($_POST['dirComment']))),parseResources($_SESSION['curDir']));
			require 'writeResources.php';
			if ( !($fout = fopen("resources/$_SESSION[curDir]/".trim($_POST['dirName'])."/resources.xml","w")))
			{
				show_error("Couldn't save new settings.");
			}
			fputs($fout,"<?xml version='1.0' encoding='UTF-8' ?>\n");
			fputs($fout,"<Resources>\n");
			fputs($fout,"</Resources>\n");
			fclose($fout);
			chmod("resources/$_SESSION[curDir]/".trim($_POST['dirName'])."/resources.xml",0644);
			url_redirect(getInternallink("resources","resources"));
		}
	}
}
elseif (isset($_GET['cmd']) && $_GET['cmd'] == "addlinkFrm")
{
?>
	<form method=post action="<?php echo getInternallink("resources","resources","cmd=addLink"); ?>">
		<table class=table2 align=center width=60%>
			<tr>
				<td class=blockhead align=center colspan=2>
					Add a new hypherlink
				</td>
			</tr>
			<tr>
				<td>
					<br />
				</td>
			</tr>
			<tr>
				<td align=right>
					Link title:
				</td>
				<td>
					 <input name=linkTitle>
				</td>
			</tr>
			<tr>
				<td align=right>
					Link URL:
				</td>
				<td>
					 <input name=linkURL>
				</td>
			</tr>
			<tr>
				<td align=right>
					Link Description:
				</td>
				<td>
					 <input name=linkComment size=40> <span class=comment>(Optional)</span>
				</td>
			</tr>
			<tr>
				<td align=center colspan=2>
					<br />
					<input type=submit value=" Add ">
					<input type=button value="Cancel" onclick="document.location='<?php echo getInternallink("resources","resources"); ?>';">
					<br/ ><br />
				</td>
			</tr>
		</table>
	</form>
<?php
}
else if (isset($_GET['cmd']) && $_GET['cmd'] == "addLink")
{
	if (trim($_POST['linkTitle']) == "")
	{
		show_error("Invalid link title.");
	}
	elseif (trim($_POST['linkURL']) == "")
	{
		show_error("Invalid link URL.");
	}
	else
	{
		$items = parseResources($_SESSION['curDir']);
		reset($items);
		while (list($key) = each($items))
		{
		    if (trim($items[$key]['Type']) == 'Link' &&
				trim($items[$key]['Name']) == trim($_POST['linkTitle']) &&
				trim($items[$key]['URL']) == trim($_POST['linkURL']))
		    {
				show_error("There is currently a link with this properties in this folder.");
		    }
		}

		$items = array_merge(array(array("Name" => trim($_POST['linkTitle']),
										"Type" => "Link",
										"URL" => trim($_POST['linkURL']),
										"Comment" => trim($_POST['linkComment']))),$items);
		require 'writeResources.php';
		// This will cause GET and POST contents to be deleted
		url_redirect(getInternallink("resources","resources"));
	}
}
else if (isset($_GET['cmd']) && $_GET['cmd'] == "addfileFrm")
{
    
?>


	<form enctype="multipart/form-data" method=post action="<?php echo getInternallink("resources","resources","cmd=addfile"); ?>">
		<table class=table2 align=center width=60%>
			<tr>
				<td class=blockhead align=center colspan=2>
					Upload file
				</td>
			</tr>
			<tr>
				<td>
					<br />
				</td>
			</tr>
			<tr>
				<td align=right>
					Drag&Drop File: 
				</td>
				<td>
					 <input name=userfile type=file size=30>
				</td>
			</tr>
			<tr>
				<td align=right>
					File Description:
				</td>
				<td>
					<input name=fileComment size=40> <span class=comment>(Optional)</span>
				</td>
			</tr>
			<tr>
               
                
				<td align=center colspan=2>
					<br />
					<input type=submit value=" Upload ">
					<input type=button value="Cancel" onclick="document.location='<?php echo getInternallink("resources","resources"); ?>';">
					<br/ ><br />
				</td>
			</tr>
		</table>
	</form>
<?php
}else if (isset($_GET['cmd']) && $_GET['cmd'] == "addfile")
{
	$items = parseResources($_SESSION['curDir']);
	reset($items);
	while( list($key) = each($items) )
	{
		if (trim($items[$key]['Type']) == 'File' &&
				trim($items[$key]['Name']) == trim($_FILES['userfile']['name']))
		{
			show_error("There is currently a file with this name in this folder.");
		}
	}
	if (!is_uploaded_file($_FILES["userfile"]["tmp_name"]))
	{
		show_error("Error in uploading file.<br/>Maximum upload file size is ".
			ini_get("upload_max_filesize")." If you want to upload a bigger file ask server administrator".
			" to increase maximum upload file size.<br> You can also use FTP to upload your file and then".
			" add a link to the file in resources page.");
	}
	else
	{
		$newFile = "resources/$_SESSION[curDir]/".$_FILES["userfile"]["name"];
		if (!move_uploaded_file($_FILES["userfile"]["tmp_name"],$newFile))
		{
			show_error("An error occured while trying to upload your file.");
		}
		else
		{
			chmod($newFile,0644);
			if (strrchr($_FILES['userfile']['name'], '.') == '.htm'
				|| strrchr($_FILES['userfile']['name'], '.') == '.html')
			{
				$imgFilePath = search_img_in_html($newFile);
				if ( sizeof($imgFilePath) > 0 )
				{
					$dialogBox = "<br><table class=table2 width=90% align=center><tr><td align=center><br/><b>You are uploading an HTML file which contains the following images.</b><br>\n"
							."If you want this images to be displayed correctly please enter their locations.<br>\n"
				             ."<form method=\"post\" action=\"".getInternallink("resources","resources","cmd=upImages")."\" "
				             ."enctype=\"multipart/form-data\">\n"
				             ."<input type=\"hidden\" name=\"relatedFile\""
				             ."value=\"".$_FILES['userfile']['name']."\">\n"
				             ."<input type=hidden name=fileComment value=\"".rawurlencode($_POST['fileComment'])."\">"
				             ."<table border=\"0\">\n";

					foreach($imgFilePath as $thisImgKey => $thisImgFilePath )
					{
						$dialogBox .= "<tr>\n"
									 ."<td>"
									 ."<label for=\"".$thisImgKey."\">".basename($thisImgFilePath)." : </label>"
									 ."</td>\n"
									 ."<td>"
									 ."<input type=\"file\"	id=\"".$thisImgKey."\" name=\"imgFile[]\">"
									 ."<input type=\"hidden\" name=\"imgFilePath[]\" "
									 ."value=\"".$thisImgFilePath."\">"
									 ."</td>\n"
									 ."</tr>\n";
					}

					$dialogBox .= "</table>\n"

								 ."<div align=\"center\"><br/>"
								 ."<input type=\"submit\" value=\"    OK    \"> "
								 ."<input type=\"submit\" value=\"Discard Images\">\n"
								 ."</div>\n"
								 ."</form></td></tr></table>\n";

					die($dialogBox);
                }
            }

			$items = array_merge(array(array("Name" => trim($_FILES['userfile']['name']),
											"Type" => "File",
											"Comment" => trim($_POST['fileComment']))),$items);
			require 'writeResources.php';
			url_redirect(getInternallink("resources","resources&cmd=addfileFrm"));
		}
	}
}else if (isset($_GET['cmd']) && $_GET['cmd'] == "upImages")
{
		$uploadImgFileNb = sizeof($_FILES['imgFile']);

		if ($uploadImgFileNb > 0)
		{
			// Try to create  a directory to store the image files

            //$imgDirectory = $_REQUEST['relatedFile'].'_files';
            //$imgDirectory = create_unexisting_directory($baseWorkDir.$imgDirectory);

			$newFile = "resources/$_SESSION[curDir]/$_POST[relatedFile]";
			$imgDir = str_replace(".html","","{$newFile}_Files");
			$imgDir = str_replace(".htm","",$imgDir);
			$imgDir = create_unexisting_directory(dirname($_SERVER['SCRIPT_FILENAME'])."/".$imgDir);
			$relative_imgDir = str_replace(dirname($_SERVER['SCRIPT_FILENAME'])."/",'',$imgDir);

            // set the makeInvisible command param appearing later in the script
			//$mkInvisibl = str_replace($baseWorkDir, '', $imgDirectory);

			// move the uploaded image files into the corresponding image directory

			// Try to create  a directory to store the image files
            $newImgPath = move_uploaded_file_collection_into_directory($_FILES['imgFile'], $relative_imgDir);

            replace_img_path_in_html_file($_POST['imgFilePath'],
                                          $newImgPath,
                                          "resources/$_SESSION[curDir]"."/".$_POST['relatedFile']);

		}
		$items = parseResources($_SESSION['curDir']);
		$items = array_merge(array(array("Name" => trim($_POST['relatedFile']),
										"Type" => "File",
										"Comment" => trim(rawurldecode($_POST['fileComment'])))),$items);
		require 'writeResources.php';
		url_redirect(getInternallink("resources","resources"));
}
else if (isset($_GET['cmd']) && $_GET['cmd'] == "changeDir")
{
	if (!is_dir("resources/$_SESSION[curDir]/$_GET[id]"))
	{
		show_error("Request Failed.");
	}
	else
	{
		$_SESSION['curDir'] .= "/$_GET[id]";
	}
}
else if (isset($_GET['cmd']) && $_GET['cmd'] == "goUp")
{
	if (!(strrpos($_SESSION['curDir'],"/") === false))
	{
		$_SESSION['curDir'] = substr($_SESSION['curDir'],0,strrpos($_SESSION['curDir'],"/"));
	}
}
else if (isset($_GET['cmd']) && $_GET['cmd'] == "del")
{
	$items = parseResources($_SESSION['curDir']);
	$_GET['id'] = trim($_GET['id']);
	$newItems = array();
	$j=0;
	for ($i=0 ; $i<count($items) ; $i++)
	{
		if ($i == $_GET['id'])
		{
			if ($items[$i]['Type'] == 'Directory')
			{
				deleteDir(dirname($_SERVER['SCRIPT_FILENAME'])."/resources/$_SESSION[curDir]/".trim($items[$i]["Name"]));
			}
			elseif ($items[$i]['Type'] == "File")
			{
				$resourcePath = "resources/$_SESSION[curDir]/".trim($items[$i]["Name"]);
				@unlink($resourcePath);
			}
		}
		else
		{
			$newItems[$j++] = $items[$i];
		}
	}
	$items = $newItems;
	require 'writeResources.php';
	url_redirect(getInternallink("resources","resources"));
}
?>
<TABLE cellSpacing=0 cellPadding=0 width="97%" border=0 align=center>
	<TR>
		<TD>
			<?php createSectionTitle('Available Resources'); ?>
		</TD>
	</TR>
</TABLE>
<?php
if (($_SESSION['isAdmin'] or $_SESSION['isTa']) && (!$_SESSION['isStudent']) )
{
?>
	<table align=center wisdth=90%>
		<tr>
			<td align=right>
				<a href="<?php echo getInternallink("resources","resources","cmd=addDirFrm"); ?>">
					<img src="images/folder.gif" border=0>
					Make a new folder
				</a>&nbsp;&nbsp;&nbsp;&nbsp;
				<a href="<?php echo getInternallink("resources","resources","cmd=addlinkFrm"); ?>">
					<img src="images/link.gif" border=0>
					Create hypherlink
				</a>&nbsp;&nbsp;&nbsp;&nbsp;
				<a href="<?php echo getInternallink("resources","resources","cmd=addfileFrm"); ?>">
					<img src="images/download.gif" border=0>
					Upload file
				</a>
			</td>
		</tr>
	</table>
	<br />
<?php
}
$items = parseResources($_SESSION['curDir']);
if (count($items) == 0 && $_SESSION['curDir'] == 'root')
{
	if (!$_SESSION['isAdmin'])
	{
		show_msg('No resource yet :(');
	}
}
else
{
?>
	<table class=table2 align=center width=90% cellspacing=1 cellpadding=5	>
		<tr>
			<th>
				Name
			</th>
			<th>
				Size
			</th>
			<th>
				Description
			</th>
			<?php
				if (($_SESSION['isAdmin'] or $_SESSION['isTa']) && (!$_SESSION['isStudent']) )
				{
			?>
			<th width=1>
				&nbsp;Delete&nbsp;
			</th>
			<?php
				}
			?>
		</tr>
	<?php
	if ($_SESSION['curDir'] != 'root')
	{
		echo '<tr><td><a href="'.getInternallink("resources","resources","cmd=goUp").'">';
		echo '<b>&nbsp;..</b></td><td></td><td>&nbsp;Parent Folder</td></tr>';
	}
	$class=1;
	for ($i=0 ; $i<count($items) ; $i++)
	{
		$class = ($class==1 ? 2 : 1);
		echo "<tr><td class=row$class>";
		if ($items[$i]['Type'] == 'Directory')
		{
			echo '<img src="images/folder.gif" border=0>';
			echo '<A href="'.getInternallink("resources","resources","cmd=changeDir&amp;id=".$items[$i]["Name"]).'">';
		}
		elseif ($items[$i]['Type'] == "File")
		{
			$resourcePath = "resources/$_SESSION[curDir]/".$items[$i]["Name"];
			echo "<a  href=\"$resourcePath\">";
			$resInfo = pathinfo($resourcePath);
			if (!isset($resInfo["extension"]))
			{
					$resInfo["extension"] = "";
			}
			$resInfo["extension"] = strtoupper($resInfo["extension"]);
			if (trim($resInfo["extension"]) == "PDF")
			{
				echo '<img src="images/pdf.gif" border=0>';
			} elseif (trim($resInfo["extension"]) == "HTM" || trim($resInfo["extension"] == "HTML"))
			{
				echo '<img src="images/html.gif" border=0>';
			}
			elseif (trim($resInfo["extension"]) == "DOC")
			{
				echo '<img src="images/doc.gif" border=0>';
			}
			elseif (trim($resInfo["extension"]) == "PPT")
			{
				echo '<img src="images/ppt.gif" border=0>';
			}
			elseif (trim($resInfo["extension"]) == "XLS")
			{
				echo '<img src="images/xls.gif" border=0>';
			}
			elseif (trim($resInfo["extension"]) == "ZIP" || trim($resInfo["extension"]) == "GZ")
			{
				echo '<img src="images/zip.gif" border=0>';
			}
			elseif (trim($resInfo["extension"]) == "TXT")
			{
				echo '<img src="images/txt.gif" border=0>';
			}
			elseif (trim($resInfo["extension"]) == "RAR")
			{
				echo '<img src="images/rar.gif" border=0>';
			}
			elseif (trim($resInfo["extension"]) == "JPG" || trim($resInfo["extension"]) == "GIF"
					|| trim($resInfo["extension"]) == "BMP" || trim($resInfo["extension"]) == "PNG")
			{
				echo '<img src="images/gif.gif" border=0>';
			}
			elseif (trim($resInfo["extension"]) == "EXE")
			{
				echo '<img src="images/exe.gif" border=0>';
			}
			else
			{
				echo '<img src="images/document.gif" border=0>';
			}

		}
		else
		{
			echo '<a href="http://'.str_replace("http://","",$items[$i]["URL"]).'">';
			echo '<img src="images/link.gif" border=0>';
		}
		echo "&nbsp;&nbsp;".htmlspecialchars(trim($items[$i]['Name']));
		echo '</a><br/></td>';
		echo "<td align=right class=row$class>";
		if ($items[$i]['Type'] == 'File')
		{
			$filePath = dirname($_SERVER['SCRIPT_FILENAME'])."/resources/$_SESSION[curDir]/".trim($items[$i]["Name"]);
			if (file_exists($filePath))
			{
				echo filesize($filePath);
			}
			else
			{
				echo "It seems that this file is deleted!";
			}
		}
		echo '&nbsp;</td>';
		echo "<td class=row$class>&nbsp;";
		echo $items[$i]['Comment'];
		echo '</td>';
		if (($_SESSION['isAdmin'] or $_SESSION['isTa']) && (!$_SESSION['isStudent']) )
		{
			echo "<td align=center class=row$class><a href=\"".getInternallink("resources","resources","cmd=del&amp;id=$i").'" onClick="return confirm('."'Are you sure to delete?'".');">';
			echo '<img src="images/delete.gif" border=0>';
			echo '</a></td>';
		}
		echo '</tr>';
	}
	?>
	</table>
<?php
}
?>
