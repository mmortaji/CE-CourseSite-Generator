<?php
if (!$_SESSION['isAdmin'] && !$_SESSION['Logged_in'])
{
		show_error("Only members can access this page.");
}
require_once 'parseGrades.php';
require_once 'functions.php';

$grades = parseGrades();
$grade = $grades[$_GET['id']];

createSectionTitle('Objections');

if (!hasObjection($grade))
{
		show_error("These grades don't have an objection period");
}

// if ($_SESSION['isAdmin'] or $_SESSION['isTa'] or $_SESSION['isStudent'])
// {
	if (isset($_GET['cmd']) && $_GET['cmd'] == "delAll")
	{
		$grades[$_GET['id']]['Objections'] = array();
		require 'writeGrades.php';
		url_redirect(getInternallink("grades","grades"),1,"All Objections Deleted");
	}
	elseif (isset($_GET['cmd']) && $_GET['cmd'] == "del")
	{
		$objs = $grades[$_GET['id']]['Objections'];
		$newObjs = array();
		$j=0;
		for ($i=0; $i<count($objs) ; $i++)
		{
				if ($i != $_GET['obj'])
				{
						$newObjs[$j++] = $objs[$i];
				}
		}
		$grades[$_GET['id']]['Objections'] = $newObjs;
		require 'writeGrades.php';
		url_redirect(getInternallink("grades","objection","id=$_GET[id]"));
	}
	else
	{
		for ($num=0 ; $num<count($grade['Objections']) ; $num++)
		{
?>
			<table class=table2 width=90% align=center>
				<tr>
					<td>
						<img src="images/spacer.gif" height=5><br/>
						<table align=center width=97%>
							<tr>
								<td>
									<?php echo str_replace("  "," &nbsp;",nl2br(htmlspecialchars(trim($grade['Objections'][$num])))); ?>
								</td>
							</tr>
						</table>
						<img src="images/spacer.gif" height=5><br/>
					</td>
				</tr>
                <?php if ($_SESSION['isAdmin'] or $_SESSION['isTa'] and !$_SESSION['isStudent']) { ?>
				<tr>
					<td align=right>
						<input type=button value="Delete" onclick="document.location
							='<?php echo getInternallink("grades","objection","cmd=del&amp;id=$_GET[id]&amp;obj=$num"); ?>';">
					</td>
				</tr>
                <?php } ?>
			</table>
			<br/>
<?php
		}
		if ($_SESSION['isAdmin'] and !$_SESSION['isTa'] and !$_SESSION['isStudent']) { 
?>		
		<div align=center>
			<input type=button value="Delete All Objections" 
				onclick="document.location='<?php echo getInternallink("grades","objection","cmd=delAll&amp;id=$_GET[id]"); ?>';">
		</div>
        <br>
<?php
        }
	}
// }
// if($_SESSION['isStudent'] or $_SESSION['isTa'])
// {
	// if (ObjectionPeriod($grade) != "NOW")
	// {
	// 		show_error("You can not post your objection on these grades now.");
	// }
	if (isset($_GET['cmd']) && $_GET['cmd'] == "post")
	{
			if (trim($_POST['msg']) == "")
			{
					show_error("Cannor send an empty message.");
			}
			$message = "Objection From: $_SESSION[UserName]\n";
			$message .= "Posted at : ".faDate(time())."\n\n";
			$message .= trim($_POST['msg']);
			$grades[$_GET['id']]['Objections'][] = $message;
			require 'writeGrades.php';
			url_redirect(getInternallink("grades","objection&id=$_GET[id]"),1,"Your objection posted.");
	}	
     if (ObjectionPeriod($grade) == "NOW" or ($_SESSION['isAdmin'] and !$_SESSION['isTa'] and !$_SESSION['isStudent'] )) 
	 {
?>
<form method=post action="<?php echo getInternallink("grades","objection","cmd=post&amp;id=$_GET[id]"); ?>">
	<table class=table2 width=90% align=center>
		<tr>
			<td>
				<br/>
			</td>
		</tr>
		<tr>
			<td align=right valign=top>
				Your Message:
			</td>
			<td>
				<textarea name=msg rows=8 cols=80></textarea>
			</td>
		</tr>
		<tr>
			<td align=center colspan=2>
				<input type=submit value=" Post ">
				<input type=button value="Cancel" 
					onclick="document.location='<?php echo getInternallink("grades","grades"); ?>';">
				<br/><br/>
			</td>
		</tr>
	</table>
</form>
<?php
     }
    if ($_SESSION['isTa'] or $_SESSION['isStudent'] and ObjectionPeriod($grade) != "NOW")
	{
			echo    ("<center><b>You can not post your objection becuase time is passed.</b></center>");
            
	}
    // }
?>
