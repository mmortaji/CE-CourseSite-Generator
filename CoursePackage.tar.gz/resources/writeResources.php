<?php
if (!$_SESSION['isAdmin'])
{
	die('Access Denied');
}
$ResourceFile = "resources/$_SESSION[curDir]/resources.xml";
if (! ($fout = fopen($ResourceFile,"w")) )
{
	@rmdir("resources/$_SESSION[curDir]/".trim($_POST['dirName']));
	show_error("Couldn't open $ResourceFile for writing.");
}
fputs($fout,"<?xml version='1.0' encoding='UTF-8' ?>\n");
fputs($fout,"<Resources>\n");
for ($i=0 ; $i<count($items); $i++)
{
	  fputs($fout,"\t<Resource type=\"".$items[$i]['Type']."\">\n");
	  fputs($fout,"\t\t<Name><![CDATA[".trim($items[$i]["Name"])."]]></Name>\n");
	  if ($items[$i]['Type'] == "Link")
	  {
		  fputs($fout,"\t\t<URL><![CDATA[".trim($items[$i]["URL"])."]]></URL>\n");
	  }
	  fputs($fout,"\t\t<Comment><![CDATA[".trim($items[$i]["Comment"])."]]></Comment>\n");
	  fputs($fout,"\t</Resource>\n");
}
fputs($fout,"</Resources>\n");
fclose($fout);
?>
