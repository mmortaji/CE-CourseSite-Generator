<?php
function ldap_auth($username, $password){
	$adminsFile = "admin/admins.inf";
	$admins = file($adminsFile);
	//print_r($admins);
	//die('>'.md5(180));
	for ($i=0 ; $i<count($admins) ; $i++)
	{
		list($admin,$pass,$semat,$email,$verify) = explode("|",$admins[$i]);		
		if ((trim($username) == trim($admin)) and (md5(trim($password)) == trim($pass)) and trim($verify) != "NV")
		{
			return true;
		}
	}
	return false;
}
?>
