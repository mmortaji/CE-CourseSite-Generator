<?php
	if (!isset($indexFile) || trim(basename($_SERVER['PHP_SELF'])) != trim($indexFile))
	{
		die('You can not access this page directly.');
	}
?>
<?php
    $currentNewsTag = "";
    $dateValue = "";
    $contentValue = "";
    $rtlValue = "";
    $news = array();

function newsCharacterData($parser, $data)
{
     global $currentNewsTag,$dateValue,$contentValue,$rtlValue;
     if (strcmp($currentNewsTag,"date") == 0)
     {
          $dateValue .= $data;
     } elseif (strcmp($currentNewsTag,"content") == 0)
     {
          $contentValue .= $data;
     }elseif (strcmp($currentNewsTag,"rtl") == 0)
     {
          $rtlValue .= $data;
     }
}

function newsStartElement($parser, $name, $attr)
{
         global $currentNewsTag;
         $currentNewsTag = $name;
}

function newsEndElement($parser, $name)
{
         global $currentNewsTag,$dateValue,$contentValue,$rtlValue,$news;
         if (strcmp($name,"item")==0)
         {
              $news[] = array("date" => $dateValue,
                                   "content" => $contentValue,
                                   "rtl" => $rtlValue);
              $dateValue = "";
              $contentValue = "";
              $rtlValue = "";
         }
}

function parseNews()
{
      global $news,$dateValue,$contentValue,$rtlValue,$currentNewsTag,$NewsFile;
      $xmlfile = "news/news.xml";

      $xmlParser = xml_parser_create();
      xml_set_element_handler($xmlParser,"newsStartElement","newsEndElement");
      xml_set_character_data_handler($xmlParser,"newsCharacterData");
      xml_parser_set_option($xmlParser,XML_OPTION_CASE_FOLDING,false);
      if (! ($fp = fopen($xmlfile,"r")) )
      {
            die("Could not open $xmlfile for reading.");
      }
      while (($data = fread($fp,4096)))
      {
           if (!xml_parse($xmlParser,$data,feof($fp)))
           {
                die(sprintf("XML error at line %d column %d : %s",
                                     xml_get_current_line_number($xmlParser),
                                     xml_get_current_column_number($xmlParser),
                                     xml_error_string(xml_get_error_code($xmlParser))));
           }
      }
      fclose($fp);
      xml_parser_free($xmlParser);
      return $news;
}
?>
