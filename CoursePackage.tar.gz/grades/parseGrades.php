<?php
	if (!isset($indexFile) || trim(basename($_SERVER['PHP_SELF'])) != trim($indexFile))
	{
		die('You can not access this page directly.');
	}
?>
<?php
    $currentTag = "";
    $fileValue = "";
    $colValue = "";
    $colName = "";
    $comment = "";
	$titleValue = "";
    $grades = array();
	$table = array();
	$curRow = array();
	$typeValue = "";
	$cols = array();
	$objStart = "";
	$objEnd = "";
    

function gradesCharacterData($parser, $data)
{
     global $currentTag,$fileValue,$colValue,$comment,$titleValue,$objStart,$objEnd,$objMsg;
	 switch ($currentTag)
	 {
			 case "File":
					 $fileValue .= $data;
					 break;
			 case "Value":
					 $colValue .= $data;
					 break;
			 case "Comment":
					 $comment .= $data;
					 break;
			 case "Title":
					 $titleValue .= $data;
					 break;
			 case "Start":
					 $objStart .= $data;
					 break;
			 case "End":
					 $objEnd .= $data;
					 break;
			 case "ObjectionMsg":
					 $objMsg .= $data;
					 break;
	 }
}

function gradesStartElement($parser, $name, $attr)
{
         global $currentTag,$grades,$curRow,$colName,$typeValue,$cols;
         if ($name == "Grade")
         {
			 $typeValue = $attr['type'];
		 }
		 elseif ($name == "Col")
		 {
			 $colName = $attr['name'];
			 if (!isset($cols[$colName]))
			 {
					 $cols[$colName] = array("max" => 0, 
					 						"min" => 0,
											"avg" => 0);
			 }
			 if (isset($attr['min']))
			 {
				 $cols[$colName]["min"] = $attr['min'];
			 }
			 if (isset($attr['max']))
			 {
				 $cols[$colName]['max'] = $attr['max'];
			 }
			 if (isset($attr['avg']))
			 {
				 $cols[$colName]['avg'] = $attr['avg'];
			 }
		 }
         $currentTag = $name;
}

function gradesEndElement($parser, $name)
{
	global $currentTag,$fileValue,$colValue,$grades,$curRow,$typeValue;
	global $colName,$table,$comment,$cols,$titleValue,$objStart,$objEnd,$objMsg,$objMessages;
	if ($name == "Col")
	{
		$curRow[$colName] = $colValue;
		$colValue = "";
		$colName = "";
	}
	elseif ($name == "Row")
	{
		$table[] = $curRow;
	}
	elseif ($name == "ObjectionMsg")
	{
		$objMessages[] = $objMsg;
		$objMsg = "";
	}
	elseif ($name == "Grade")
	{
		if ($typeValue == "File")
		{
			$grades[] = array("Title" => trim($titleValue),
								"Type" => "File",
								"Comment" => trim($comment),
								"File" => trim($fileValue),
								"ObjectionStart" => trim($objStart),
								"ObjectionEnd" => trim($objEnd),
								"Objections" => $objMessages);
		}
		else
		{
			$grades[] = array("Title" => trim($titleValue),
								"Comment" => trim($comment),
								"Type" => "Table",
								"Columns" => $cols,
								"Table" => $table,
								"ObjectionStart" => trim($objStart),
								"ObjectionEnd" => trim($objEnd),
								"Objections" => $objMessages);
		}
		$currentTag = "";
    	$fileValue = "";
	    $colValue = "";
	    $colName = "";
    	$comment = "";
		$titleValue = "";
		$table = array();
		$curRow = array();
		$typeValue = "";
		$cols = array();
	    $objStart = "";
		$objEnd = "";
		$objMsg = "";
		$objMessages = array();
	}
}

function parseGrades()
{
	global $grades,$currentTag,$fileValue,$colValue,$colName,$comment,$titleValue,$grades;
	global $table,$curRow,$typeValue,$cols,$objStart,$objEnd,$objMsg,$objMessages;
 
	$xmlfile = "grades/grades.xml";
    $currentTag = "";
    $fileValue = "";
    $colValue = "";
    $colName = "";
    $comment = "";
	$titleValue = "";
    $grades = array();
	$table = array();
	$curRow = array();
	$typeValue = "";
	$cols = array();
	$objStart = "";
	$objEnd = "";
	$objMsg = "";
	$objMessages = array();
 
	$xmlParser = xml_parser_create();
	xml_set_element_handler($xmlParser,"gradesStartElement","gradesEndElement");
	xml_set_character_data_handler($xmlParser,"gradesCharacterData");
	xml_parser_set_option($xmlParser,XML_OPTION_CASE_FOLDING,false);
	if (! ($fp = fopen($xmlfile,"r")) )
	{
		die("Could not open $xmlfile for reading.");
	}
	while (($data = fread($fp,4096)))
	{
	   if (!xml_parse($xmlParser,$data,feof($fp)))
	   {
			die(sprintf("XML error at line %d column %d : %s",
								 xml_get_current_line_number($xmlParser),
								 xml_get_current_column_number($xmlParser),
								 xml_error_string(xml_get_error_code($xmlParser))));
	   }
	}
	fclose($fp);
	xml_parser_free($xmlParser);
/*	echo "<pre>";
	print_r($grades);
	die("</pre>");    */
	return $grades;
}
?>
