<?php
session_start();
header('Content-type: image/jpeg');
$code=$_SESSION['code'];
$font_size=15;
$image_width=140;
$image_height=40;
$image= imagecreate($image_width,$image_height);
imagecolorallocate($image,220,220,220);
$text_color= imagecolorallocate($image,0,0,0);
imagettftext($image, $font_size,0,10,25, $text_color,'font.ttf', $code);
imagejpeg($image);
?>