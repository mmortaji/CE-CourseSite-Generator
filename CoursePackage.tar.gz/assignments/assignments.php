<?php
if (!isset($indexFile) || trim(basename($_SERVER['PHP_SELF'])) != trim($indexFile))
{
	die('You can not access this page directly.');
}

require_once 'parseAssigns.php';

createSectionTitle('Assignments');
if (($_SESSION['isAdmin'] or $_SESSION['isTa']) && (!$_SESSION['isStudent']) )
{
	if (isset($_GET['cmd']) && $_GET['cmd'] == "del")
	{
		function deleteDir($dirname)
		{
			if ($dir = opendir($dirname))
			{
				while (($file = readdir($dir)) !== false )
				{
					if ($file == "." || $file == "..")
					{
						continue;
					}
					if (is_dir("$dirname/$file"))
					{
						deleteDir("$dirname/$file");
					}
					else
					{
						unlink("$dirname/$file");
					}
				}
				closedir($dir);
			}
			else
			{
				show_error("Couldn't read directory contents.");
			}
			if (!rmdir($dirname))
			{
				show_error("Couldn't delete directory");
			}
			return;
		}

		$assigns = parseAssigns();
		$id = $_GET['id'];
		$dir = dirname($_SERVER['SCRIPT_FILENAME'])."/".$assigns[$id]['Dir'];
		if (!is_dir($dir))
		{
			show_error("Couldn't find assignment directory.");
		}
		deleteDir($dir);
		$new = array();
		$j=0;
		for ($i=0 ; $i<count($assigns) ; $i++)
		{
			if ($i != $id)
			{
				$new[$j++] = $assigns[$i];
			}
		}
		$assigns = $new;
		require 'writeAssigns.php';
		url_redirect(getInternallink("assignments","assignments"));
	}
?>
	<div align=right>
		<form method=post action="<?php echo getInternallink("assignments","addNew","start"); ?>">
			<input type=submit value=" Add new assignments ">
		</form>
	</div>
<?php
}
$assigns = parseAssigns();
//die($assigns[0]['Files'][0]['FileComment']);
for ($i=0 ; $i<count($assigns) ; $i++)
{
?>
	<table width=95% align=center cellspacing=0 cellpadding=0>
		<tr>
			<td class=titleBar>
				<table width=100% cellspacing=0 cellpadding=0>
					<tr>
						<td>
							&nbsp;&nbsp;<b><?php echo htmlspecialchars($assigns[$i]['Title']); ?></b>
						</td>
						<td align=right>
							<b>
							<?php
								echo "Deadline: ".$assigns[$i]['DueDate'];
							?>
							&nbsp;
							</b>
						</td>

						<?php if (($_SESSION['isAdmin'] or $_SESSION['isTa']) && (!$_SESSION['isStudent']) ) { ?>
						<td align=right width=1%>
							<a href="<?php echo getInternallink("assignments","edit","start&amp;id=$i"); ?>" title="Edit">
								<img src="images/edit.gif" border=0>
							</a>
						</td>
						<td align=right width=1%>
							<a href="<?php echo getInternallink("assignments","assignments","cmd=del&amp;id=$i"); ?>" title="Delete" onclick="return confirm('Selected assignment and all of its files will be deleted.');">
								<img src="images/delete.gif" border=0>
							</a>
						</td>
						<?php } ?>
					</tr>
				</table>
			</td>
		</tr>
		<tr>
			<td>
				<table class=table1 cellspacing=0 cellpadding=0>
					<tr>
						<td>
							<img src="images/spacer.gif" height=1><br/>
						</td>
					</tr>
					<?php
					if (count($assigns[$i]['Files'])>0)
					{
					?>
					<tr>
						<td>
							<b> &nbsp; &raquo;&nbsp;Assignment File<?php if (count($assigns[$i]['Files'])>1) echo "s"; ?>:</b><br/><img src="images/spacer.gif" height=4><br/>
							<table width=95% align=center>
								<?php
									$files = $assigns[$i]['Files'];
									for ($j = 0 ; $j<count($files) ; $j++)
									{
								?>
										<tr>
											<td>
												<li>
													<a href="<?php echo $assigns[$i]['Dir']."/".$files[$j]['FileName']; ?>">
														<?php echo $files[$j]['FileName']; ?>
													</a>
													<?php
														if (trim($files[$j]['FileComment']) != "")
														{
															echo nl2br("&nbsp;&nbsp;[ ".trim($files[$j]['FileComment'])." ]");
														}
													?>
												</li>
											</td>
										</tr>
								<?php
									}
								?>
							</table>
						</td>
					</tr>
					<?php
					}
					if (trim($assigns[$i]['Comment']) != "") { ?>
					<tr>
						<td>
							<?php
								if (count($assigns[$i]['Files'])>0)
								{
										echo "<b> &nbsp; &raquo;&nbsp;Comments:<br/></b>";
										echo "<img src=\"images/spacer.gif\" height=4><br/>";
								}
							?>
							<table width=97% align=center>
								<tr>
									<td>
										<?php echo nl2br(str_replace("  "," &nbsp;",trim($assigns[$i]['Comment']))); ?>
									</td>
								</tr>
							</table>
						</td>
					</tr>
					<?php } ?>
					<tr>
						<td>
							<img src="images/spacer.gif" height=4><br/>
						</td>
					</tr>
				</table>
			</td>
		</tr>
	</table>
	<br/>
<?php
}

if (count($assigns) == 0 and !$_SESSION['isAdmin'])
{
	show_msg('No assignment yet :)');
}
?>
