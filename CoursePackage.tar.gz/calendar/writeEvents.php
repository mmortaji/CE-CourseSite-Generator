<?php
if (!isset($indexFile) || trim(basename($_SERVER['PHP_SELF'])) != trim($indexFile))
{
	die('You can not access this page directly.');
}

if (!$_SESSION['isAdmin'])
{
	die('Access Denied');
}
$calendarFile = "calendar/calendar.xml";
if (! ($fout = fopen($calendarFile,"w")) )
{
	die("Couldn't open $calendarFile for writing.");
}
fputs($fout,"<?xml version='1.0' encoding='UTF-8' ?>\n");
fputs($fout,"<Events>\n");
for ($i=0 ; $i<count($events); $i++)
{
	fputs($fout,"\t<Event>\n");
	fputs($fout,"\t\t<Date><![CDATA[".trim($events[$i]["Date"])."]]></Date>\n");
	fputs($fout,"\t\t<Topic><![CDATA[".trim($events[$i]["Topic"])."]]></Topic>\n");
	fputs($fout,"\t\t<Comment><![CDATA[".trim($events[$i]["Comment"])."]]></Comment>\n");
	fputs($fout,"\t</Event>\n");
}
fputs($fout,"</Events>\n");
fclose($fout);
?>
