<?php

if (!isset($indexFile) || trim(basename($_SERVER['PHP_SELF'])) != trim($indexFile))
{
	die('You can not access this page directly.');
}

require_once 'checkLogin.php';
$onlinesFile = 'users/onlines.inf';

if (isset($_GET['id']))
{
	$id = $_GET['id'];
}
else
{
	$id = "";
}
if ($id == "out")
{
	$onlines = file($onlinesFile);
	$newOnlines = array();
	for ($i=0 ; $i<count($onlines) ; $i++)
	{
		list($name,$time) = explode("|",$onlines[$i]);
		if (trim($name) != trim($_SESSION["UserName"]))
		{
			$newOnlines[] = $onlines[$i];
		}
	}
	writeOnlines($newOnlines);
	//$_SESSION["UserName"] = "";
	$_SESSION["Logged_in"] = false;
	$_SESSION["isAdmin"] = false;	
	url_redirect();
}
else if ($id == "in")
{
	check_login($_POST['username'],$_POST['password']);
	$onlines = file($onlinesFile);
	$found = false;
	$name_time_session = array();
	$j=0;
	for ($i=0 ; $i<count($onlines) ; $i++)
	{
		list($memberName,$loginTime,$memberSession) = explode("|",trim($onlines[$i]));
		$name_time_session[$j] = array();
		$name_time_session[$j]['name'] = trim($memberName);
		if (trim($memberName) == $_POST['username'])
		{
			$found = true;			
			$name_time_session[$j]['time'] = time();
			$name_time_session[$j]['session'] = session_id();
		}
		else
		{
			$name_time_session[$j]['time'] = trim($loginTime);
			$name_time_session[$j]['session'] = trim($memberSession);
		}		
		$j++;
	}
	if (!$found)
	{
		$name_time_session[] = array( "name" => trim($_POST['username']),"time" => time(),"session" => session_id());
	}
	$onlines = array();
	for ($i=0 ; $i<count($name_time_session) ; $i++)
	{
		$onlines[] = implode("|",$name_time_session[$i]);
	}
	writeOnlines($onlines);
	if ($handle = fopen("users/lastLogin.inf","w+"))
	{
		fputs($handle,$_POST['username']);
		fclose($handle);
	}
	url_redirect();
}
?>
