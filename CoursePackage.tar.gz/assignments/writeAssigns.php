<?php
if (!$_SESSION['isAdmin'])
{
	die("ACCESS DENIED");
}
$assignsFile = "assignments/assigns.xml";
if (! ($fout = fopen($assignsFile,"w")) )
{
	die("Couldn't open $assignsFile for writing.");
}
fputs($fout,"<?xml version='1.0' encoding='UTF-8' ?>\n");
fputs($fout,"<Assignments>\n");
global $assigns;
for ($i=0 ; $i<count($assigns) ; $i++)
{
	  fputs($fout,"\t<Assignment>\n");
	  fputs($fout,"\t\t<Title><![CDATA[".trim($assigns[$i]['Title'])."]]></Title>\n");
	  fputs($fout,"\t\t<DueDate><![CDATA[".trim($assigns[$i]['DueDate'])."]]></DueDate>\n");
	  reset($assigns[$i]['Files']);
	  while( list($key,$value) = each($assigns[$i]['Files']) )
	  {
		  fputs($fout,"\t\t<File>\n");
		  fputs($fout,"\t\t\t<Name><![CDATA[".trim($value['FileName'])."]]></Name>\n");
		  fputs($fout,"\t\t\t<FileComment><![CDATA[".trim($value['FileComment'])."]]></FileComment>\n");	  
		  fputs($fout,"\t\t</File>\n");
	  }
	  fputs($fout,"\t\t<Comment><![CDATA[".trim($assigns[$i]["Comment"])."]]></Comment>\n");
	  fputs($fout,"\t\t<Dir><![CDATA[".trim($assigns[$i]['Dir'])."]]></Dir>\n");
	  fputs($fout,"\t</Assignment>\n");
}
fputs($fout,"</Assignments>\n");
fclose($fout);
?>
