<?php
if (!$_SESSION['isAdmin'])
{
	die("ACCESS DENIED");
}
require_once 'parseGrades.php';
require_once 'includes/fileUpload.php';
require_once 'functions.php';

$gradesFile = "grades/grades.xml";
$grades = parseGrades();
?>

<table width=97% align=center cellspacing=0 cellpadding=0>
	<tr>
		<td>
			<?php createSectionTitle("Edit Grades File"); ?>
		</td>
	</tr>
	
<?php
if (isset($_REQUEST['cmd']) && $_REQUEST['cmd']=="newFile")
{
	$oldFile = dirname($_SERVER['SCRIPT_FILENAME'])."/".trim($grades[$_REQUEST['id']]['File']);
	if (file_exists($oldFile))
	{
		if (!@unlink($oldFile))
		{
			show_error("An error occures while trying to delete the old file.");
		}
	}
	$newFile = get_unexisting_file_name("grades/files/".$_FILES['userfile']['name']);
	if (!is_uploaded_file($_FILES["userfile"]["tmp_name"]))
	{
		show_error("Error in uploading file");
	}
	else
	{
		if (!move_uploaded_file($_FILES["userfile"]["tmp_name"],$newFile))
		{
			show_error("An error occured whilt trying to upload your file.");
		}
		else
		{
			chmod($newFile,0644);
			$grades[$_REQUEST['id']]['File'] = $newFile;
			require 'writeGrades.php';
			$query = "id=$_REQUEST[id]&amp;name=".rawurlencode($_REQUEST['name']);
			$query .= "&amp;comment=".rawurlencode($_REQUEST['comment']);
			$query .= "&amp;objStart=".rawurlencode($_REQUEST['objStart']);
			$query .= "&amp;objEnd=".rawurlencode($_REQUEST['objEnd']);
			url_redirect(getInternallink("grades","editFile",$query));
		}
	}
}
elseif (isset($_POST['cmd']) && $_POST['cmd']=="newFileFrm")
{
?>
	<tr>
		<td>
			<br/>
			<form method=post enctype="multipart/form-data" action="<?php echo getInternallink("grades","editFile","cmd=newFile&amp;name=".rawurlencode($_POST['name'])."&amp;comment=".rawurlencode($_POST['comment'])); ?>">
				<table class=blockcontent2 width=70% align=center>
					<tr>
						<td align=right>
							<br/><br/>
							New Grades File:
						</td>
						<td>
							<br/><br/>
							<input name=userfile type=file size=40>
						</td>
					</tr>
					<tr>
						<td align=center colspan=2>
							<br/>
							<input type=submit value=" Upload ">
							<input type=button value=" Cancel " onclick="document.location='<?php 
									$query = "id=$_REQUEST[id]&amp;name=".rawurlencode($_POST['name']);
									$query .= "&amp;comment=".rawurlencode($_POST['comment']);
								    $query .= "&amp;objStart=".rawurlencode($_REQUEST['startyear']."/");
									$query .= rawurlencode($_REQUEST['startmonth']."/".$_REQUEST['startday']);
									$query .= "&amp;objEnd=".rawurlencode($_REQUEST['endyear']."/");
									$query .= rawurlencode($_REQUEST['endmonth']."/".$_REQUEST['endday']);
									echo getInternallink("grades","editFile",$query); ?>';">
							<br/><br/>
						</td>
					</tr>
				</table>
				<input type=hidden name="id" value="<?php echo $_REQUEST['id']; ?>">
				<input type=hidden name="objStart" value="
					<?php echo rawurlencode($_REQUEST['startyear']."/".$_REQUEST['startmonth']."/".$_REQUEST['startday']);?>
							">
				<input type=hidden name="objEnd" value="
					<?php echo rawurlencode($_REQUEST['endyear']."/".$_REQUEST['endmonth']."/".$_REQUEST['endday']);?>
							">

			</form>				
		</td>
	</tr>
<?php
}
elseif (isset($_REQUEST['cmd']) && $_REQUEST['cmd']=="do")
{
	$grades[$_GET['id']]['Comment'] = trim($_POST['comment']);
	$grades[$_GET['id']]['Title'] = trim($_POST['name']);
	if (isset($_REQUEST['canObject']))
	{
			$grades[$_GET['id']]['ObjectionStart'] = $_POST['startyear']."/".$_POST['startmonth']."/".$_POST['startday'];
			$grades[$_GET['id']]['ObjectionEnd'] = $_POST['endyear']."/".$_POST['endmonth']."/".$_POST['endday'];
	}
	else
	{
			$grades[$_GET['id']]['ObjectionStart'] = "";
			$grades[$_GET['id']]['ObjectionEnd'] = "";
	}	
	require 'writeGrades.php';
	url_redirect(getInternallink("grades","grades"));			
}
else
{
?>

	<tr>
		<td>
			<br/>
			<form method=post enctype="multipart/form-data" action="<?php echo getInternallink("grades","editFile","id=$_GET[id]"); ?>">
				<input type=hidden name="cmd" value="do">
				<table class=blockcontent2 width=90% align=center>
					<tr>
						<td align=right>
							Title:
						</td>
						<td>
							<input value="<?php if (isset($_REQUEST['name']))
												{
														echo htmlspecialchars($_REQUEST['name']);
												}
												else
												{
														echo htmlspecialchars($grades[$_GET['id']]['Title']);
												}
											?>" name=name>
						</td>
					</tr>
					<tr>
						<td align=right valign=top>
							&nbsp;Comment:
						</td>
						<td>
							<textarea name=comment rows=8 cols=80><?php 
										if (isset($_REQUEST['comment']))
										{
												echo htmlspecialchars($_REQUEST['comment']);
										}
										else
										{
												echo trim(htmlspecialchars($grades[$_GET['id']]['Comment']));
										}	?></textarea>
						</td>
					</tr>
					<tr>
						<td colspan=2>
							&nbsp;<input type=checkbox name=canObject 
										<?php if (hasObjection($grades[$_GET['id']])) echo "checked"; ?>>
								  Members can object on their grades in the following period:
						</td>
					</tr>
					<tr>
						<td align=right>
							From:
						</td>
						<td>
									<?php
											require_once 'includes/shamsi.php';
											if (isset($_REQUEST['objStart']))
											{
												list($y,$m,$d) = explode("/",rawurldecode($_REQUEST['objStart']));
											}
											elseif (hasObjection($grades[$_GET['id']]))
											{			
												list($y,$m,$d) = explode("/",$grades[$_GET['id']]['ObjectionStart']);
											}
											else
											{
												list($M_y,$M_m,$M_d) = explode("-",date("Y-m-d"));
												list($y,$m,$d) = Miladi_to_Shamsi($M_y,$M_m,$M_d);
											}

											echo '<select name="startyear">';
											for ($year=$y-2 ; $year<$y+5 ; $year++)
											{
											echo "<option value=\"$year\"";
											if ($year == $y)
											{
												echo " selected";
											}
											echo ">$year</option>\n";
											}
											echo "</select>\n";
											echo "&nbsp; / &nbsp;";
											echo "<select name=\"startmonth\">\n";
											for ($i=1 ; $i<13 ; $i++)
											{
												echo "<option value=\"$i\"";
												if ($i==$m)
												{
													echo " selected";
												}
												echo ">";
												if ($i<10)
												{
													echo "0";
												}
												echo "$i</option>\n";
											}
											echo "</select>\n";
									
											echo "&nbsp; / &nbsp;";
											echo "<select name=\"startday\">\n";
											for ($i=1 ; $i<32 ; $i++)
											{
											echo "<option value=\"$i\"";
											if ($i==$d)
											{
												echo " selected";
											}
											echo ">";
											if ($i<10)
											{
												echo "0";
											}
											echo "$i</option>\n";
										}
										echo "</select>\n<br/>";
									?>
						</td>
					</tr>
					<tr>
						<td align=right>
							To:
						</td>
						<td>
									<?php
										if (isset($_REQUEST['objEnd']))
										{
											list($y,$m,$d) = explode("/",rawurldecode($_REQUEST['objEnd']));
										}
										elseif (hasObjection($grades[$_GET['id']]))
										{			
											list($y,$m,$d) = explode("/",$grades[$_GET['id']]['ObjectionEnd']);
										}
										else
										{
											list($M_y,$M_m,$M_d) = explode("-",date("Y-m-d",time()+84600*7));
											list($y,$m,$d) = Miladi_to_Shamsi($M_y,$M_m,$M_d);
										}

										echo '<select name="endyear">';
										for ($year=$y-2 ; $year<$y+5 ; $year++)
										{
											echo "<option value=\"$year\"";
											if ($year == $y)
											{
												echo " selected";
											}
											echo ">$year</option>\n";
										}
										echo "</select>\n";
										echo "&nbsp; / &nbsp;";
										echo "<select name=\"endmonth\">\n";
										for ($i=1 ; $i<13 ; $i++)
										{
											echo "<option value=\"$i\"";
											if ($i==$m)
											{
												echo " selected";
											}
											echo ">";
											if ($i<10)
											{
												echo "0";
											}
											echo "$i</option>\n";
										}
										echo "</select>\n";
									
										echo "&nbsp; / &nbsp;";
										echo "<select name=\"endday\">\n";
										for ($i=1 ; $i<32 ; $i++)
										{
											echo "<option value=\"$i\"";
											if ($i==$d)
											{
												echo " selected";
											}
											echo ">";
											if ($i<10)
											{
												echo "0";
											}
											echo "$i</option>\n";
										}
										echo "</select>\n";
									?>
						</td>
					</tr>
					<tr>
						<td align=right>
							Grades File:
						</td>
						<td>							
							<b><?php echo basename($grades[$_GET['id']]['File']); ?></b>&nbsp;
							<input type=submit value="Change File" onclick="cmd.value='newFileFrm';">
						</td>
					</tr>					
					<tr>
						<td align=center colspan=2>
							<br/>
							<input type=submit value=" Edit ">
							<input type=button value=" Cancel " onclick="document.location='<?php echo getInternallink("grades","grades"); ?>';">
							<br/><br/>
						</td>
					</tr>
				</table>				
			</form>				
		</td>
	</tr>
<?php
}
?>
</table>
