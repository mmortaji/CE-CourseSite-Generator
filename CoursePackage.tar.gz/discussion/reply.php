<?php
	if (!isset($indexFile) || trim(basename($_SERVER['PHP_SELF'])) != trim($indexFile))
	{
		die('You can not access this page directly.');
	}
if (!isset($_SESSION['Logged_in']) || !$_SESSION['Logged_in'])
{
	  show_error("Only Members Can Access This Page.<br/>If you are a member please Login first.");
}
else
{
	require 'parseMsgs.php';
	if (isset($_GET['cmd']) && $_GET['cmd'] == "send")
	{
		if (trim($_POST['subject']) == "")
		{
			show_error("Empty Subject");		
		}
		elseif (trim($_POST['msg']) == "")
		{
			show_error("Empty Message.");		
		}
		else
		{
			$messages = array_merge(array(array("Subject" => trim($_POST['subject']),
											"Content" => trim($_POST['msg']),
											"Date" => trim(time()),
											"Author" => trim($_SESSION["UserName"]))),parseMessages());
			$msgFile = "discussion/discussion.xml";
			if (! ($fout = fopen($msgFile,"w")) )
			{
				die("Couldn't open $msgFile for writing.");
			}
			fputs($fout,"<?xml version='1.0' encoding='UTF-8' ?>\n");
			fputs($fout,"<Messages>\n");
			for ($i=0 ; $i<count($messages); $i++)
			{
				  fputs($fout,"\t<Message>\n");
				  fputs($fout,"\t\t<Subject><![CDATA[".trim($messages[$i]["Subject"])."]]></Subject>\n");
				  fputs($fout,"\t\t<Author><![CDATA[".trim($messages[$i]["Author"])."]]></Author>\n");
				  fputs($fout,"\t\t<Date>".trim($messages[$i]["Date"])."</Date>\n");
				  fputs($fout,"\t\t<Content><![CDATA[".trim($messages[$i]["Content"])."]]></Content>\n");
				  fputs($fout,"\t</Message>\n");
			}
			fputs($fout,"</Messages>\n");
			fclose($fout);
			url_redirect(getInternallink("discussion","discussion"));
		}
	}
	else
	{
		$messages = parseMessages();
?>
	<Form action="<?php echo getInternallink("discussion","reply","cmd=send"); ?>"  method=POST>
		<TABLE cellSpacing=0 cellPadding=1 width="95%" border=0 align=center>
			<TR>
				<TD align=left class=block>
					<TABLE cellSpacing=0 cellPadding=2 width="100%" border=0  class=blockhead>
						<TR>
							<TD>
								<B>&nbsp;Reply</B>
							</TD>
						</TR>
					</TABLE>          								
					<TABLE class=blockcontent cellspacing=7>
						<TR>
							<TD align=right>														
								Subject:
							</TD>
							<TD>
								<INPUT name=subject size="40" value="Re: <?php echo $messages[$_GET['id']]['Subject']; ?>">
							</TD>
						</TR>
						<TR>
							<TD valign="top" align=right>
								Message:
							</TD>
							<TD>
								<textarea name=msg rows=10 cols=100></textarea>
							</TD>
						</TR>
						<TR >
							<TD align=center colspan=2>
								<br />
								<INPUT type=submit value="  Send  "> 
								<input type=button value=" Cancel " 
									onclick="document.location='<?php echo getInternallink("discussion","discussion"); ?>';">
							</TD>
						</TR>
					</TABLE>									
				</TD>
			</TR>
		</TABLE>
	</Form>
<?php
	}
}
?>      			
