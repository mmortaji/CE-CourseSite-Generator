<?php
	if (!isset($indexFile) || trim(basename($_SERVER['PHP_SELF'])) != trim($indexFile))
	{
		die('You can not access this page directly.');
	}
    $currentTag = "";
    $subjectValue = "";
    $dateValue = "";
    $authorValue = "";
    $contentValue = "";
    $messages = array();

function MsgCharacterData($parser, $data)
{
     global $currentTag,$dateValue,$subjectValue,$authorValue,$contentValue;
     if (strcmp($currentTag,"Date") == 0)
     {
          $dateValue .= $data;
     } elseif (strcmp($currentTag,"Subject") == 0)
     {
          $subjectValue .= $data;
     } elseif (strcmp($currentTag,"Author") == 0)
     {
          $authorValue .= $data;
     } elseif ($currentTag == "Content")
     {
		 $contentValue .= $data;
	 }
}

function MsgStartElement($parser, $name, $attr)
{
         global $currentTag;
         $currentTag = $name;
}

function MsgEndElement($parser, $name)
{
         global $currentTag,$dateValue,$subjectValue,$messages,$authorValue,$contentValue;
         if (strcmp($name,"Message")==0)
         {
			 $messages[] = array("Subject" => trim($subjectValue),
									"Date" => trim($dateValue),
									"Author" => trim($authorValue),
									"Content" => trim($contentValue));
             $dateValue = "";
             $subjectValue = "";
             $authorValue = "";
             $contentValue = "";
         }
}

function parseMessages()
{
	global $messages,$currentTag,$subjectValue,$dateValue,$authorValue;
	$xmlfile = "discussion/discussion.xml";
	$messages = array();
	$currentTag = "";
	$subjectValue = "";
	$dateValue = "";
	$authorValue = "";

      $xmlParser = xml_parser_create();
      xml_set_element_handler($xmlParser,"MsgStartElement","MsgEndElement");
      xml_set_character_data_handler($xmlParser,"MsgCharacterData");
      xml_parser_set_option($xmlParser,XML_OPTION_CASE_FOLDING,false);
      if (! ($fp = fopen($xmlfile,"r")) )
      {
            die("Could not open $xmlfile for reading.");
      }
      while (($data = fread($fp,4096)))
      {
           if (!xml_parse($xmlParser,$data,feof($fp)))
           {
                die(sprintf("XML error at line %d column %d : %s",
                                     xml_get_current_line_number($xmlParser),
                                     xml_get_current_column_number($xmlParser),
                                     xml_error_string(xml_get_error_code($xmlParser))));
           }
      }
      fclose($fp);
      xml_parser_free($xmlParser);
/*      echo "<pre>";
      print_r($messages);
      die("</pre>");        */
      return $messages;
}
?>
