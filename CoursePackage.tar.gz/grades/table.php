<?php
if (!$_SESSION['isAdmin'])
{
	die("ACCESS DENIED");
}
require_once 'parseGrades.php';
$studentsFile = 'grades/students.lst';

if (isset($_GET['cmd']) && $_GET['cmd']=="do")
{
			$grades = parseGrades();
			$newgrades = array();
			$table = array();
			for ($i=0 ; $i<$_POST['col'] ; $i++)
			{
					if (trim($_POST["title_$i"] == ""))
					{
						$_POST["title_$i"] = "Column #".($i+1);
					}				
					for ($j=$i+1 ; $j<$_POST['col'] ; $j++)
					{
							if (trim($_POST["title_$i"]) == trim($_POST["title_$j"]))
							{
									$_POST["title_$j"] .= "?";
							}
					}
			}
			for ($i=0 ; $i<$_POST['row'] ; $i++)
			{
				$table[$i] = array();
				for ($j=0 ; $j<$_POST['col'] ; $j++)
				{
					$table[$i][$_POST["title_$j"]] = $_POST["value_{$i}_$j"];
				}
			}
			$cols = array();
			for ($i=1 ; $i<$_POST['col'] ; $i++)
			{
				$cols[$_POST["title_$i"]] = array();
				if (isset($_POST["min_$i"]))
				{
					$cols[$_POST["title_$i"]]['min'] = "1";
				}
				else
				{
					$cols[$_POST["title_$i"]]['min'] = "0";
				}
				if (isset($_POST["max_$i"]))
				{
					$cols[$_POST["title_$i"]]['max'] = "1";
				}
				else
				{
					$cols[$_POST["title_$i"]]['max'] = "0";
				}
				if (isset($_POST["avg_$i"]))
				{
					$cols[$_POST["title_$i"]]['avg'] = "1";
				}
				else
				{
					$cols[$_POST["title_$i"]]['avg'] = "0";
				}
			}
			if (!isset($_POST['objStart']))
			{
					$_POST['objStart'] = "";
					$_POST['objEnd'] = "";
			}
			$newgrades[] = array( 'Comment' => trim(rawurldecode($_POST['comment'])),
									"Title" => trim(rawurldecode($_POST['name'])),
									"Type" => "Table",
									"Table" => $table,
									"Columns" => $cols,
									"Objections" => array(),
									"ObjectionStart" => trim(rawurldecode($_POST['objStart'])),
									"ObjectionEnd" => trim(rawurldecode($_POST['objEnd'])));
			$grades = array_merge($newgrades,$grades);
			//print_r($grades);
			//die();
			require 'writeGrades.php';
			url_redirect(getInternallink("grades","grades"));
}
else
{
?>
<table width=97% align=center cellspacing=0 cellpadding=0>
	<tr>
		<td>
			<?php createSectionTitle("Enter Grades"); ?>
		</td>
	</tr>
	<tr>
		<td>
			<form method=post action="<?php echo getInternallink("grades","table","cmd=do"); ?>">
				<table class=blockcontent2 width=100% align=center>
					<tr>
						<td>
							<br/>
							<table border=0 align=center cellspacing=2>
								<tr>
									<td align=right>
										Column title:
									</td>
									<?php
										for ($i=0 ; $i<$_GET['col'] ; $i++)
										{
											echo "<td><input name=title_$i size=20></td>\n";
										}
									?>											
								</tr>
								<?php
									$students = array();
									if (isset($_GET['import']))
									{
										$students = file($studentsFile);
									}
									for ($i=0 ; $i<$_GET['row'] ; $i++)
									{
										echo "<tr><td align=right>#".($i+1)."</td>\n";
										echo "<td align=center><input name=value_{$i}_0 size=17 value=\"";
										if (isset($students[$i]))
										{
											echo trim($students[$i]);
										}
										echo "\"></td>\n";
										for ($j=1 ; $j<$_GET['col'] ; $j++)
										{
											echo "<td align=center><input name=value_{$i}_$j size=5 dir=rtl></td>\n";
										}
										echo "</tr>\n";
									}
								?>
								<tr>
									<td align=right>
										Column Maximum:
									</td>
									<td>
									</td>
									<?php
										for ($i=1 ; $i<$_GET['col'] ; $i++)
										{
											echo "<td align=center><input checked name=max_$i type=checkbox></td>\n";
										}
									?>											
								</tr>
								<tr>
									<td align=right>
										Column Minimum:
									</td>
									<td>
									</td>
									<?php
										for ($i=1 ; $i<$_GET['col'] ; $i++)
										{
											echo "<td align=center><input checked name=min_$i type=checkbox></td>\n";
										}
									?>											
								</tr>
								<tr>
									<td align=right>
										Column Average:
									</td>
									<td>
									</td>
									<?php
										for ($i=1 ; $i<$_GET['col'] ; $i++)
										{
											echo "<td align=center><input checked name=avg_$i type=checkbox></td>\n";
										}
									?>											
								</tr>
							</table>
						</td>
					</tr>
					<tr>
						<td align=center colspan=2>
							<br/>
							<input type=submit value="   OK   ">
							<input type=button value=" Cancel " onclick="document.location='<?php echo getInternallink("grades","grades"); ?>';">
							<br/><br/>
						</td>
					</tr>
				</table>
				<input type=hidden value="<?php echo rawurlencode($_GET['name']); ?>" name=name>
				<input type=hidden value="<?php echo $_GET['row']; ?>" name=row>
				<input type=hidden value="<?php echo $_GET['col']; ?>" name=col>
				<input type=hidden value="<?php echo rawurlencode($_GET['comment']); ?>" name=comment>
			<?php
				if (isset($_GET['objStart']))
				{
			?>
				<input type=hidden value="<?php echo rawurlencode($_GET['objStart']); ?>" name=objStart>
				<input type=hidden value="<?php echo rawurlencode($_GET['objEnd']); ?>" name=objEnd>
			<?php
				}
			?>
			</form>				
		</td>
	</tr>
</table>
<?php
}
?>
