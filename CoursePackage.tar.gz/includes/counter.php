<?php
if (!isset($_SESSION['visitTimes'.md5($Course['Name'])]))
{
	$handle = fopen("includes/count.dat","r");
	$content = trim(fread($handle,4096));
	if (!is_numeric($content))
	{
		$content = 0;
	}
	$content++;
	$_SESSION['visitTimes'.md5($Course['Name'])] = $content;
	fclose($handle);
	$handle = fopen("includes/count.dat","w");
	fwrite($handle,$content);
	fclose($handle);
}
?>
