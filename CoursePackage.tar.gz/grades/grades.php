<?php
if (!isset($indexFile) || trim(basename($_SERVER['PHP_SELF'])) != trim($indexFile))
{
	die('You can not access this page directly.');
}

require_once 'parseGrades.php';
require_once 'includes/shamsi.php';
require_once 'functions.php';

$studentsFile = 'grades/students.lst';


?>
<table width="97%" align=center cellspacing=0 cellpadding=0>
	<tr>
		<td>
			<?php createSectionTitle('Grades'); ?>
		</td>
	</tr>
<?php
if (isset($_GET['cmd']) && $_GET['cmd'] == "print")
{
    if(isset($_GET['addres'])){
      
         	ob_clean();

$myfile = fopen($_GET['addres'], "r") or die("Unable to open file!");
                                                                       ?>
                                  
                                    <?php
                                                
                                                echo "<br><br>
                                                <table align=center border=1 cellspacing=1 cellpadding=4>
                                                <caption><b>$Course[Name]<br/>".$_GET['gradename']." Grades</b><br/></caption>\n <br><br>
                                                <tr>
                                                <th>Name</th>
                                                <th>Grade</th>
                                                </tr>";
                                                $number=0;
                                                  while(!feof($myfile)) {
                                                      $data = fgets($myfile); 
                                                      
                                                    echo "<tr><td align=center>" . str_replace('	','</td><td align=center>',$data) . '</td></tr>';
                                                                         }                     
                                                  echo "</table>";
											


	ob_end_flush();
	die();
    }else {
	ob_clean();
	$grades = parseGrades();
	$i = $_GET['id'];
	echo "<br/><table align=center border=1 cellspacing=1 cellpadding=4>\n";
	echo "<caption><b>$Course[Name]<br/>".$grades[$i]['Title']." Grades</b><br/></caption>\n";
	reset($grades[$i]['Columns']);
	$writeMax = false;
	$writeMin = false;
	$writeAvg = false;
	echo "<tr>\n";
	while (list($key) = each($grades[$i]['Columns']))
	{
		echo "<th>&nbsp; ".$key." &nbsp;</th>\n";
		${"Col_".trim($key)} = array();
		if ($grades[$i]['Columns'][$key]['max'])
		{
				$writeMax = true;
		}
		if ($grades[$i]['Columns'][$key]['min'])
		{
				$writeMin = true;
		}
		if ($grades[$i]['Columns'][$key]['avg'])
		{
				$writeAvg = true;
		}
	}
	echo "</tr>\n";
	for ($j=0 ; $j<count($grades[$i]['Table']) ; $j++)
	{
		echo "<tr>\n";
		reset($grades[$i]['Table'][$j]);
		while (list($key,$value) = each($grades[$i]['Table'][$j]))
		{
			$value = trim($value);
			echo "<td align=right>&nbsp;$value&nbsp;</td>\n";
			if (is_numeric($value))
			{
				array_push(${"Col_".trim($key)},$value);
			}
		}
		echo "</tr>\n";
	}
	if ($writeMax)
	{
		echo "<tr>\n<td align=right class=row3><b>&nbsp;Maximum:&nbsp;</b></td>\n";
		reset($grades[$i]['Columns']);
		next($grades[$i]['Columns']);
		while( list($key) = each($grades[$i]['Columns']))
		{
			echo "<td align=right>&nbsp;";
			if ($grades[$i]['Columns'][$key]['max'])
			{
				sort(${"Col_".trim($key)},SORT_NUMERIC);
				echo "&nbsp;".end(${"Col_".trim($key)})."&nbsp;";
			}
			echo "</td>\n";

		}
		echo "</tr>\n";
	}

	if ($writeAvg)
	{
		echo "<tr>\n<td align=right><b>&nbsp;Average:&nbsp;</b></td>\n";
		reset($grades[$i]['Columns']);
		next($grades[$i]['Columns']);
		while( list($key) = each($grades[$i]['Columns']))
		{
			echo "<td align=right>&nbsp;";
			if ($grades[$i]['Columns'][$key]['avg'] and count(${"Col_".trim($key)}) > 0)
			{
				echo "&nbsp;".round(array_sum(${"Col_".trim($key)})/count(${"Col_".trim($key)}),2)."&nbsp;";
			}
			echo "</td>\n";

		}
		echo "</tr>\n";
	}

	if ($writeMin)
	{
		echo "<tr>\n<td align=right><b>&nbsp;Minimum:&nbsp;</b></td>\n";
		reset($grades[$i]['Columns']);
		next($grades[$i]['Columns']);
		while( list($key) = each($grades[$i]['Columns']))
		{
			echo "<td align=right>&nbsp;";
			if ($grades[$i]['Columns'][$key]['min'])
			{
				sort(${"Col_".trim($key)},SORT_NUMERIC);
				echo "&nbsp;".reset(${"Col_".trim($key)})."&nbsp;";
			}
			echo "</td>\n";
		}
		echo "</tr>\n";
	}
	echo "</table></br>\n";
	ob_end_flush();
	die();
}//else
}

if (($_SESSION['isAdmin'] or $_SESSION['isTa']) && (!$_SESSION['isStudent']) )
{
	if (isset($_GET['cmd']) && $_GET['cmd'] == "addFrm")
	{
?>
		<tr>
			<td>
				<form method=post action="<?php echo getInternallink("grades","grades","cmd=add"); ?>">
					<table width="70%" align=center class=blockcontent2 cellspacing=0 cellpadding=0>
						<tr>
							<td>
								<br />
								&nbsp;&nbsp;Grades of: <input name=gradesName><hr />
							</td>
						</tr>
						<tr>
							<td>
								&nbsp;&nbsp;Comment: &nbsp;&nbsp;<textarea name=comment rows=5 cols=80 align=right></textarea>
							</td>
						</tr>
						<tr>
							<td>
							<?php $students = file($studentsFile); ?>
								<hr/>&nbsp;<input type=radio name=gradeType value="table" checked>Let me enter grades in a table with
								<input name="row" size=2 <?php if (count($students)>0) echo 'value="'.count($students).'"'; ?>> rows and <input name="col" size=2> columns.<br/>
								<?php if (count($students)>0) echo '&nbsp; &nbsp; &nbsp; &nbsp; <input type=checkbox name="import" checked>Fill it\'s first column with students list'; ?>
								<hr/>&nbsp;<input type=radio name=gradeType value="file">Grades are in a file, let me upload it.<hr />
							</td>
						</tr>
						<tr>
							<td>
								&nbsp;<input type=checkbox name="objection">
								Let students post their objections to these grades in the following period:<br/>
								<table width=90% align=center>
									<tr>
										<td align=right>
											From:
										</td>
										<td>
										<?php
											require_once 'includes/shamsi.php';
											list($M_y,$M_m,$M_d) = explode("-",date("Y-m-d"));
											list($y,$m,$d) = Miladi_to_Shamsi($M_y,$M_m,$M_d);

											echo '<select name="startyear">';
											for ($year=$y-2 ; $year<$y+5 ; $year++)
											{
											echo "<option value=\"$year\"";
											if ($year == $y)
											{
												echo " selected";
											}
											echo ">$year</option>\n";
											}
											echo "</select>\n";
											echo "&nbsp; / &nbsp;";
											echo "<select name=\"startmonth\">\n";
											for ($i=1 ; $i<13 ; $i++)
											{
												echo "<option value=\"$i\"";
												if ($i==$m)
												{
													echo " selected";
												}
												echo ">";
												if ($i<10)
												{
													echo "0";
												}
												echo "$i</option>\n";
											}
											echo "</select>\n";

											echo "&nbsp; / &nbsp;";
											echo "<select name=\"startday\">\n";
											for ($i=1 ; $i<32 ; $i++)
											{
											echo "<option value=\"$i\"";
											if ($i==$d)
											{
												echo " selected";
											}
											echo ">";
											if ($i<10)
											{
												echo "0";
											}
											echo "$i</option>\n";
										}
										echo "</select>\n<br/>";
									?>
									</td>
								</tr>
								<tr>
									<td align=right>
										To:
									</td>
									<td>
									<?php
										list($M_y,$M_m,$M_d) = explode("-",date("Y-m-d",time()+84600*7));
										list($y,$m,$d) = Miladi_to_Shamsi($M_y,$M_m,$M_d);

										echo '<select name="endyear">';
										for ($year=$y-2 ; $year<$y+5 ; $year++)
										{
											echo "<option value=\"$year\"";
											if ($year == $y)
											{
												echo " selected";
											}
											echo ">$year</option>\n";
										}
										echo "</select>\n";
										echo "&nbsp; / &nbsp;";
										echo "<select name=\"endmonth\">\n";
										for ($i=1 ; $i<13 ; $i++)
										{
											echo "<option value=\"$i\"";
											if ($i==$m)
											{
												echo " selected";
											}
											echo ">";
											if ($i<10)
											{
												echo "0";
											}
											echo "$i</option>\n";
										}
										echo "</select>\n";

										echo "&nbsp; / &nbsp;";
										echo "<select name=\"endday\">\n";
										for ($i=1 ; $i<32 ; $i++)
										{
											echo "<option value=\"$i\"";
											if ($i==$d)
											{
												echo " selected";
											}
											echo ">";
											if ($i<10)
											{
												echo "0";
											}
											echo "$i</option>\n";
										}
										echo "</select>\n";
									?>
									</td>
								</tr>
							</table>
							</td>
						</tr>
						<tr>
							<td align=center>
								<br />
								<input type=submit value="   OK   ">
								<input type=button value=" Cancel " onclick="document.location='<?php echo getInternallink("grades","grades"); ?>';">
								<br /><br />
							</td>
						</tr>
					</table>
				</form>
				<br/>
			</td>
		</tr>
<?
	}
	elseif (isset($_GET['cmd']) && $_GET['cmd'] == "add")
	{
		if (trim($_POST['gradesName']) == "")
		{
			show_error("You must fill the <b>Grades of</b> field.");
		}
		if ($_POST['gradeType'] == 'file')
		{
			$query = "name=".rawurlencode($_POST['gradesName']);
			$query .= "&amp;comment=".rawurlencode($_POST['comment']);
			if (isset($_POST['objection']))
			{
					$query .= "&amp;objStart=".rawurlencode($_POST['startyear']);
					$query .= rawurlencode("/".$_POST['startmonth']."/".$_POST['startday']);
					$query .= "&amp;objEnd=".rawurlencode($_POST['endyear']);
					$query .= rawurlencode("/".$_POST['endmonth']."/".$_POST['endday']);
			}
			url_redirect(getInternallink("grades","fileUpload",$query));
		}
		else
		{
			if (!is_numeric($_POST['row']))
			{
				show_error("Please enter a valid number of rows","Table Error");
			}
			if (!is_numeric($_POST['col']))
			{
				show_error("Please enter a valid number of columns","Table Error");
			}
			if ($_POST['col'] < 2)
			{
				show_error("Columns number can not be smaller than 2");
			}
			if ($_POST['row'] < 1)
			{
				show_error("Rows number can not be smaller than 1");
			}
			$query = "name=".rawurlencode($_POST['gradesName']);
			$query .= "&amp;row=$_POST[row]&amp;col=$_POST[col]&amp;comment=".rawurlencode($_POST[comment]);
			if (isset($_POST['objection']))
			{
					$query .= "&amp;objStart=".rawurlencode($_POST['startyear']);
					$query .= rawurlencode("/".$_POST['startmonth']."/".$_POST['startday']);
					$query .= "&amp;objEnd=".rawurlencode($_POST['endyear']);
					$query .= rawurlencode("/".$_POST['endmonth']."/".$_POST['endday']);
			}
			if (isset($_POST['import']))
			{
				$query .= "&amp;import";
			}
			url_redirect(getInternallink("grades","table",$query));
		}

	}
	elseif (isset($_GET['cmd']) && $_GET['cmd'] == "del")
	{
		$grades = parseGrades();
		if ($grades[$_GET['id']]['Type'] == "File")
		{
			$file = dirname($_SERVER['SCRIPT_FILENAME'])."/".trim($grades[$_GET['id']]['File']);
			if (file_exists($file))
			{
				if (!@unlink($file))
				{
					show_error("An error occured while trying to delete the grades file.");
				}
			}
		}
		$newgrades = array();
		$j=0;
		for ($i=0 ; $i<count($grades) ; $i++)
		{
			if ($i != $_GET['id'])
			{
				$newgrades[$j++] = $grades[$i];
			}
		}
		$grades = $newgrades;
		require 'writeGrades.php';
		url_redirect(getInternallink("grades","grades"));
	}
	elseif (isset($_GET['cmd']) && $_GET['cmd'] == "edit")
	{
		$grades = parseGrades();
		if ($grades[$_GET['id']]['Type'] == "File")
		{
			url_redirect(getInternallink("grades","editFile","id=$_GET[id]"));
		}
		else
		{
			url_redirect(getInternallink("grades","editTable","id=$_GET[id]"));
		}
	}
	else
	{
?>
		<tr>
			<td align=right>
				<input type=button value="Add new grades" onclick="document.location='<?php echo getInternallink("grades","grades","cmd=addFrm"); ?>';">
				<br/><br/>
			</td>
		</tr>
<?php
	}
}
$grades = parseGrades();
for ($i=0 ; $i<count($grades) ; $i++)
{
?>
	<tr>
		<td>
			<table width=95% align=center cellspacing=0 cellpadding=0>
				<tr>
					<td>
						<table class=titlebar>
							<tr>
								<td>
									&nbsp;<?php echo htmlspecialchars($grades[$i]['Title']); ?> Grades
								</td>
                                
                                
                              
								<?php if ($grades[$i]['Type'] == "Table") { ?>
								<td align=right width=1%>
									<a href="<?php echo getInternallink("grades","grades","cmd=print&amp;id=$i"); ?>" title="Printer Friendly">
										<img src="images/print.gif" border=0>
									</a>
								</td>
								<?php
								}
								if (($_SESSION['isAdmin'] or $_SESSION['isTa']) && (!$_SESSION['isStudent']) )
								{
								?>
								<td align=right width=25>
									<a href="<?php echo getInternallink("grades","grades","cmd=edit&amp;id=$i"); ?>" title="Edit">
										<img src="images/edit.gif" border=0>
									</a>
								</td>
								<td align=right width=20>
									<a href="<?php echo getInternallink("grades","grades","cmd=del&amp;id=$i"); ?>" title="Delete" onclick="return confirm('Selected grades will be deleted.');">
										<img src="images/delete.gif" border=0>
									</a>
								</td>
								<?php } ?>
							</tr>
						</table>
					</td>
				<tr>
					<td>
						<table class=table2 width=100% cellspacing=0 cellpadding=0>
							<tr>
								<td>
									<?php
										if ($grades[$i]['Type'] == "File")
										{
											$file = trim($grades[$i]['File']);
											if (!file_exists($file))
											{
												echo "It seems that grades file ($file) is deleted!!!";
											}
											else
											{
												
												$resInfo = pathinfo($file);
												if (!isset($resInfo["extension"]))
												{
														$resInfo["extension"] = "";
												}
												$resInfo["extension"] = strtoupper($resInfo["extension"]);
												if (trim($resInfo["extension"]) == "PDF")
												{   
                                                    echo '<br/><ul><li><a href="'.$file.'">';
													echo '<img src="images/pdf.gif" border=0>';
                                                    echo '&nbsp;Grades File</a>';
												echo '&nbsp;&nbsp;[ ';
												echo 'size: '.filesize($file).' bytes ]</li></ul>';
												}
												elseif (trim($resInfo["extension"]) == "HTM" || trim($resInfo["extension"] == "HTML"))
												{
                                                    echo '<br/><ul><li><a href="'.$file.'">';
													echo '<img src="images/html.gif" border=0>';
                                                    echo '&nbsp;Grades File</a>';
												echo '&nbsp;&nbsp;[ ';
												echo 'size: '.filesize($file).' bytes ]</li></ul>';
												}
												elseif (trim($resInfo["extension"]) == "DOC")
												{
													
												}
												elseif (trim($resInfo["extension"]) == "PPT")
												{
                                                    echo '<br/><ul><li><a href="'.$file.'">';
													echo '<img src="images/ppt.gif" border=0>';
                                                    echo '&nbsp;Grades File</a>';
												echo '&nbsp;&nbsp;[ ';
												echo 'size: '.filesize($file).' bytes ]</li></ul>';
												}
												elseif (trim($resInfo["extension"]) == "XLS")
												{
                                                    echo '<br/><ul><li><a href="'.$file.'">';
													echo '<img src="images/xls.gif" border=0>';
                                                    echo '&nbsp;Grades File</a>';
												echo '&nbsp;&nbsp;[ ';
												echo 'size: '.filesize($file).' bytes ]</li></ul>';
												}
												elseif (trim($resInfo["extension"]) == "ZIP" || trim($resInfo["extension"]) == "GZ")
												{
                                                    echo '<br/><ul><li><a href="'.$file.'">';
													echo '<img src="images/zip.gif" border=0>';
                                                    echo '&nbsp;Grades File</a>';
												echo '&nbsp;&nbsp;[ ';
												echo 'size: '.filesize($file).' bytes ]</li></ul>';
												}
												elseif (trim($resInfo["extension"]) == "TXT")
												{
													
												}
												elseif (trim($resInfo["extension"]) == "RAR")
												{
                                                    echo '<br/><ul><li><a href="'.$file.'">';
													echo '<img src="images/rar.gif" border=0>';
                                                    echo '&nbsp;Grades File</a>';
												echo '&nbsp;&nbsp;[ ';
												echo 'size: '.filesize($file).' bytes ]</li></ul>';
												}
												elseif (trim($resInfo["extension"]) == "JPG" || trim($resInfo["extension"]) == "GIF"
														|| trim($resInfo["extension"]) == "BMP" || trim($resInfo["extension"]) == "PNG")
												{
                                                    echo '<br/><ul><li><a href="'.$file.'">';
													echo '<img src="images/gif.gif" border=0>';
                                                    echo '&nbsp;Grades File</a>';
												echo '&nbsp;&nbsp;[ ';
												echo 'size: '.filesize($file).' bytes ]</li></ul>';
												}
												elseif (trim($resInfo["extension"]) == "EXE")
												{
                                                    echo '<br/><ul><li><a href="'.$file.'">';
													echo '<img src="images/exe.gif" border=0>';
                                                    echo '&nbsp;Grades File</a>';
												echo '&nbsp;&nbsp;[ ';
												echo 'size: '.filesize($file).' bytes ]</li></ul>';
												}
												else
												{
													echo '<img src="images/document.gif" border=0>';
												}
                                                
                                                
												
                                                              $gradename = htmlspecialchars($grades[$i]['Title']);
                                                                       $myfile = fopen($file, "r") or die("Unable to open file!");
                                                                      
                                                if(trim($resInfo["extension"]) == "TXT" or trim($resInfo["extension"]) == "DOC" or trim($resInfo["extension"]) == "DOCX"){
                                                    ?>
                                                                                        <!--<a href="<?php echo getInternallink("grades","grades","cmd=print&amp;id=$i&amp;addres=$file&amp;gradename=$gradename"); ?>" title="Printer Friendly"><img src="images/print.gif" border=0></a>-->
                                                    <?php
                                                echo "<br><br>
                                                <table align=center class=table2 cellspacing=1 cellpadding=4>
                                                <tr>
                                                <th>Name</th>
                                                <th>Grade</th>
                                                </tr>";
                                                $number=0;
                                                  while(!feof($myfile)) {
                                                      $data = fgets($myfile); 
                                                      
                                                    echo "<tr><td class=row1 align=center>" . str_replace('	','</td><td class=row1 align=center>',$data) . '</td></tr>';
                                                                         }                      
                                                  echo "</table>";
											}
                                            }
										}
										else
										{ 
                                       
											echo "<br/><table align=center class=table2 cellspacing=1 cellpadding=4>\n";
											reset($grades[$i]['Columns']);
											$writeMax = false;
											$writeMin = false;
											$writeAvg = false;
											echo "<tr>\n";
											while (list($key) = each($grades[$i]['Columns']))
											{
												echo "<th>&nbsp; ".$key." &nbsp;</th>\n";
												${"Col_".trim($key)} = array();
												if ($grades[$i]['Columns'][$key]['max'])
												{
														$writeMax = true;
												}
												if ($grades[$i]['Columns'][$key]['min'])
												{
														$writeMin = true;
												}
												if ($grades[$i]['Columns'][$key]['avg'])
												{
														$writeAvg = true;
												}
											}
											echo "</tr>\n";
											$class = 1;
											for ($j=0 ; $j<count($grades[$i]['Table']) ; $j++)
											{
												echo "<tr>\n";
												reset($grades[$i]['Table'][$j]);
												while (list($key,$value) = each($grades[$i]['Table'][$j]))
												{
													$value = trim($value);
													echo "<td align=right class=row$class>&nbsp;$value&nbsp;</td>\n";
													if (is_numeric($value))
													{
														array_push(${"Col_".trim($key)},$value);
													}
												}
												echo "</tr>\n";
												$class = ($class == 1 ? 2 : 1);
											}
											if ($writeMax)
											{
												echo "<tr><td align=right class=row3><b>&nbsp;Maximum:&nbsp;</b></td>";
												reset($grades[$i]['Columns']);
												next($grades[$i]['Columns']);
												while( list($key) = each($grades[$i]['Columns']))
												{
													echo "<td align=right class=row3>";
													if ($grades[$i]['Columns'][$key]['max'])
													{
														sort(${"Col_".trim($key)},SORT_NUMERIC);
														echo "&nbsp;".end(${"Col_".trim($key)})."&nbsp;";
													}
													echo "</td>";

												}
												echo "</tr>";
											}

											if ($writeAvg)
											{
												echo "<tr><td align=right class=row3><b>&nbsp;Average:&nbsp;</b></td>";
												reset($grades[$i]['Columns']);
												next($grades[$i]['Columns']);
												while( list($key) = each($grades[$i]['Columns']))
												{
													echo "<td align=right class=row3>";
													if ($grades[$i]['Columns'][$key]['avg'] and count(${"Col_".trim($key)}) > 0)
													{
														echo "&nbsp;".round(array_sum(${"Col_".trim($key)})/count(${"Col_".trim($key)}),2)."&nbsp;";
													}
													echo "</td>";

												}
												echo "</tr>";
											}

											if ($writeMin)
											{
												echo "<tr><td align=right class=row3><b>&nbsp;Minimum:&nbsp;</b></td>";
												reset($grades[$i]['Columns']);
												next($grades[$i]['Columns']);
												while( list($key) = each($grades[$i]['Columns']))
												{
													echo "<td align=right class=row3>";
													if ($grades[$i]['Columns'][$key]['min'])
													{
														sort(${"Col_".trim($key)},SORT_NUMERIC);
														echo "&nbsp;".reset(${"Col_".trim($key)})."&nbsp;";
													}
													echo "</td>";
												}
												echo "</tr>";
											}
											echo "</table></br>\n";
										}
									?>
								</td>
							</tr>
						<?php if (trim($grades[$i]['Comment']) != "")
							{
							?>
							<tr>
								<td>
									<table width=97% align=center>
										<tr>
											<td>
												<b>Comment:</b><br/>
											   	<?php echo str_replace("  "," &nbsp;",nl2br(htmlentities($grades[$i]['Comment']))); ?>
											</td>
										</tr>
									</table>
									<br/>
								</td>
							</tr>
							<?php
							}
							else
							{
							?>
							<tr>
								<td>
									<br/>
								</td>
							</tr>
							<?php
							}
							// if (ObjectionPeriod($grades[$i]) == "NOW")
							// {
							?>
							<tr>
								<td align=center>
									Members can post their objections to their grades
									<a href="<?php echo getInternallink("grades","objection","id=$i"); ?>">
										here
									</a> until <?php echo $grades[$i]['ObjectionEnd']; ?>
									<br/><br/>
								</td>
							</tr>
							<?php
							// }
							/*elseif (hasObjection($grades[$i]))
							{
									if (ObjectionPeriod($grades[$i]) == "AFTER")
									{
							?>
							<tr>
								<td align=center>
									Members can post their objections to these grades between
									<?php echo $grades[$i]['ObjectionStart']." and ".$grades[$i]['ObjectionEnd']; ?>
									<br/><br/>
								</td>
							</tr>
							<?php
									}
									else
									{
							?>
							<tr>
								<td align=center>
									Objection period was until <?php echo $grades[$i]['ObjectionEnd']; ?> and is passed.
									<br/><br/>
								</td>
							</tr>
							<?php
									}
							}*/
							if ((($_SESSION['isAdmin'] or $_SESSION['isTa']) && (!$_SESSION['isStudent']) ) && hasObjection($grades[$i]))
							{
							?>
							<tr>
								<td align=center>
									<input type=button value=" View Objections "
										onclick="document.location='<?php echo getInternallink("grades","objection","id=$i"); ?>';">
									<br/><br/>
								</td>
							</tr>
							<?php
							}
							?>
						</table>
					</td>
				</tr>
			</table>
			<br/>
		</td>
	</tr>
<?php
}
if (($_SESSION['isAdmin'] or $_SESSION['isTa']) && (!$_SESSION['isStudent']) )
{
?>
	<tr>
		<td align=center>
			<table class=table2 cellpadding=15 width=100%>
				<tr>
					<td>
						You can use this button to enter students list once and then each time
						you want to add new grades import that list:
					</td>
					<td>
						<input type=button value=" Students List " onclick="document.location='<?php echo getInternallink("grades","list"); ?>';">
					</td>
				</tr>
			</table>
		</td>
	</tr>
<?php
}
?>
</table>
<?php
if (count($grades) == 0 && !$_SESSION['isAdmin'])
{
		show_Msg("No grades yet.");
}
?>
