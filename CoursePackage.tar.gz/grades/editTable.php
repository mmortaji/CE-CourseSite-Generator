<?php
if (!$_SESSION['isAdmin'])
{
	die("ACCESS DENIED");
}
require_once 'parseGrades.php';
require_once 'functions.php';

$grades = parseGrades();

if (isset($_GET['cmd']) && $_GET['cmd']=="do")
{
			$grades = parseGrades();
			$table = array();
			for ($i=0 ; $i<$_POST['col'] ; $i++)
			{
					if (trim($_POST["title_$i"] == ""))
					{
						$_POST["title_$i"] = "Column #".($i+1);
					}
					for ($j=$i+1 ; $j<$_POST['col'] ; $j++)
					{
							if (trim($_POST["title_$i"]) == trim($_POST["title_$j"]))
							{
									$_POST["title_$j"] .= "?";
							}
					}
			}
			for ($i=0 ; $i<$_POST['row'] ; $i++)
			{
				$table[$i] = array();
				for ($j=0 ; $j<$_POST['col'] ; $j++)
				{
					$table[$i][$_POST["title_$j"]] = $_POST["value_{$i}_$j"];
				}
			}
			$cols = array();
			for ($i=1 ; $i<$_POST['col'] ; $i++)
			{
				$cols[$_POST["title_$i"]] = array();
				if (isset($_POST["min_$i"]))
				{
					$cols[$_POST["title_$i"]]['min'] = "1";
				}
				else
				{
					$cols[$_POST["title_$i"]]['min'] = "0";
				}
				if (isset($_POST["max_$i"]))
				{
					$cols[$_POST["title_$i"]]['max'] = "1";
				}
				else
				{
					$cols[$_POST["title_$i"]]['max'] = "0";
				}
				if (isset($_POST["avg_$i"]))
				{
					$cols[$_POST["title_$i"]]['avg'] = "1";
				}
				else
				{
					$cols[$_POST["title_$i"]]['avg'] = "0";
				}
			}
			$start = "";
			$end = "";
			if (isset($_POST['canObject']))
			{
					$start = $_POST['startyear']."/".$_POST['startmonth']."/".$_POST['startday'];
					$end = $_POST['endyear']."/".$_POST['endmonth']."/".$_POST['endday'];
					$objections = $grades[$_GET['id']]['Objections'];
			}
			else
			{
					$start = "";
					$end = "";
					$objections = array();					
			}
			$grades[$_GET['id']] = array( 'Comment' => trim(rawurldecode($_POST['comment'])),
									"Title" => trim(rawurldecode($_POST['gradesOf'])),
									"Type" => "Table",
									"Table" => $table,
									"Columns" => $cols,
						   			"Objections" => $objections,
									"ObjectionStart" => trim($start),
									"ObjectionEnd" => trim($end));
//			print_r($grades);
//			die();
			require 'writeGrades.php';
			url_redirect(getInternallink("grades","grades"));

}
else
{
?>
<table width=97% align=center cellspacing=0 cellpadding=0>
	<tr>
		<td>
			<?php createSectionTitle("Edit Grades"); ?>
		</td>
	</tr>
	<tr>
		<td>
			<br/>
			<form method=post action="<?php echo getInternallink("grades","editTable","cmd=do&amp;id=$_GET[id]"); ?>">
				<table class=blockcontent2 width=100% align=center>
					<tr>
						<td align=center>
							<br/>
							Grades of:						
							<input name=gradesOf value="<?php echo htmlspecialchars($grades[$_GET['id']]['Title']); ?>">
						</td>
					</tr>
					<tr>
						<td>
							<hr/>
						</td>
					</tr>
					<tr>
						<td>
							<br/>
							<table border=0 align=center cellspacing=2>
								<tr>
									<td align=right>
										Column title:
									</td>
									<?php										
										//die(reset($grades[$_GET['id']]['Rows']));
										$cols = $grades[$_GET['id']]['Columns'];
										$numRow=0;
										while (list($key) = each($cols))
										{
											echo "<td><input name=title_$numRow size=20 value=\"".trim($key)."\"></td>\n";
											$numRow++;
										}
									?>
								</tr>
								<?php
									reset($grades[$_GET['id']]['Table']);
									$numRow=0;
									while (list($key,$value) = each($grades[$_GET['id']]['Table']))
									{
										echo "<tr><td align=right>#".($numRow+1)."</td>\n";
										reset($value);
										$numCol=0;
										while (list($inkey,$invalue) = each($value))
										{
											$size = ($numCol==0 ? 20 : 5);
											echo "<td align=right><input name=value_{$numRow}_$numCol size=$size value=\"".trim($invalue)."\"></td>\n";
											$numCol++;
										}
										echo "</tr>\n";
										$numRow++;										
									}									
								?>
								<tr>
									<td>
									</td>
									<td align=right>
										Column Maximum:
									</td>
									<?php
										reset($cols);
										next($cols);
										$col =0;									
										while (list($key,$value) = each($cols))
										{
											$col++;
											echo "<td align=center><input name=\"max_$col\" type=checkbox";
											if ($value['max'])
											{
												  echo " checked";
											}
											echo "></td>\n";	
										}
									?>
								</tr>
								<tr>
									<td>
									</td>
									<td align=right>
										Column Minimum:
									</td>
									<?php
										reset($cols);
										next($cols);
										$col = 0;									
										while (list($key,$value) = each($cols))
										{
											$col++;
											echo "<td align=center><input name=\"min_$col\" type=checkbox";
											if ($value['min'])
											{
												  echo " checked";
											}
											echo "></td>\n";	
										}
									?>									
								</tr>
								<tr>
									<td>
									</td>
									<td align=right>
										Column Average:
									</td>
									<?php
										reset($cols);
										next($cols);
										$col =0;										
										while (list($key,$value) = each($cols))
										{
											$col++;
											echo "<td align=center><input name=\"avg_$col\" type=checkbox";
											if ($value['avg'])
											{
												  echo " checked";
											}
											echo "></td>\n";	
										}
									?>
								</tr>
							</table>
						</td>
					</tr>
					<tr>
						<td>
							<hr/>
						</td>
					</tr>
					<tr>
						<td>
							<table align=center>
								<tr>									
									<td valign=top align=right>
										Comments:
									</td>
									<td>
										<textarea name=comment rows=8 cols=80><?php echo htmlspecialchars($grades[$_GET['id']]['Comment']); ?></textarea>
									</td>
								</tr>
							</table>
						</td>
					</tr>
					<tr>
						<td>
						<hr/>
						<table>
					<tr>
						<td colspan=2>
							&nbsp;<input type=checkbox name=canObject
										<?php if (hasObjection($grades[$_GET['id']])) echo "checked"; ?>>
								  Members can object on their grades in the following period:
						</td>
					</tr>
					<tr>
						<td align=right>
							From:
						</td>
						<td>
									<?php
											require_once 'includes/shamsi.php';
											if (isset($_REQUEST['objStart']))
											{
												list($y,$m,$d) = explode("/",rawurldecode($_REQUEST['objStart']));
											}
											elseif (hasObjection($grades[$_GET['id']]))
											{			
												list($y,$m,$d) = explode("/",$grades[$_GET['id']]['ObjectionStart']);
											}
											else
											{
												list($M_y,$M_m,$M_d) = explode("-",date("Y-m-d"));
												list($y,$m,$d) = Miladi_to_Shamsi($M_y,$M_m,$M_d);
											}

											echo '<select name="startyear">';
											for ($year=$y-2 ; $year<$y+5 ; $year++)
											{
											echo "<option value=\"$year\"";
											if ($year == $y)
											{
												echo " selected";
											}
											echo ">$year</option>\n";
											}
											echo "</select>\n";
											echo "&nbsp; / &nbsp;";
											echo "<select name=\"startmonth\">\n";
											for ($i=1 ; $i<13 ; $i++)
											{
												echo "<option value=\"$i\"";
												if ($i==$m)
												{
													echo " selected";
												}
												echo ">";
												if ($i<10)
												{
													echo "0";
												}
												echo "$i</option>\n";
											}
											echo "</select>\n";
									
											echo "&nbsp; / &nbsp;";
											echo "<select name=\"startday\">\n";
											for ($i=1 ; $i<32 ; $i++)
											{
											echo "<option value=\"$i\"";
											if ($i==$d)
											{
												echo " selected";
											}
											echo ">";
											if ($i<10)
											{
												echo "0";
											}
											echo "$i</option>\n";
										}
										echo "</select>\n<br/>";
									?>
						</td>
					</tr>
					<tr>
						<td align=right>
							To:
						</td>
						<td>
									<?php
										if (isset($_REQUEST['objEnd']))
										{
											list($y,$m,$d) = explode("/",rawurldecode($_REQUEST['objEnd']));
										}
										elseif (hasObjection($grades[$_GET['id']]))
										{			
											list($y,$m,$d) = explode("/",$grades[$_GET['id']]['ObjectionEnd']);
										}
										else
										{
											list($M_y,$M_m,$M_d) = explode("-",date("Y-m-d",time()+84600*7));
											list($y,$m,$d) = Miladi_to_Shamsi($M_y,$M_m,$M_d);
										}

										echo '<select name="endyear">';
										for ($year=$y-2 ; $year<$y+5 ; $year++)
										{
											echo "<option value=\"$year\"";
											if ($year == $y)
											{
												echo " selected";
											}
											echo ">$year</option>\n";
										}
										echo "</select>\n";
										echo "&nbsp; / &nbsp;";
										echo "<select name=\"endmonth\">\n";
										for ($i=1 ; $i<13 ; $i++)
										{
											echo "<option value=\"$i\"";
											if ($i==$m)
											{
												echo " selected";
											}
											echo ">";
											if ($i<10)
											{
												echo "0";
											}
											echo "$i</option>\n";
										}
										echo "</select>\n";
									
										echo "&nbsp; / &nbsp;";
										echo "<select name=\"endday\">\n";
										for ($i=1 ; $i<32 ; $i++)
										{
											echo "<option value=\"$i\"";
											if ($i==$d)
											{
												echo " selected";
											}
											echo ">";
											if ($i<10)
											{
												echo "0";
											}
											echo "$i</option>\n";
										}
										echo "</select>\n";
									?>
						</td>
					</tr>
					</table>
					</td>
					</tr>





					<tr>
						<td align=center>
							<br/>
							<input type=submit value="   OK   ">
							<input type=button value=" Cancel " onclick="document.location='<?php echo getInternallink("grades","grades"); ?>';">
							<br/><br/>
						</td>
					</tr>
				</table>
				<input type=hidden value="<?php echo $numRow; ?>" name=row>
				<input type=hidden value="<?php echo $numCol; ?>" name=col>
			</form>
		</td>
	</tr>
</table>
<?php
}
?>
