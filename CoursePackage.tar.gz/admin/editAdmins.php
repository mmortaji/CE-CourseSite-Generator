<?php
if (!isset($indexFile) || trim(basename($_SERVER['PHP_SELF'])) != trim($indexFile))
{
	die('You can not access this page directly.');
}
if (!$_SESSION["isAdmin"])
{
	die("ACCESS DENIED");
}
if (isset($_SESSION["isTa"]) or isset($_SESSION['isStudent']))
{
	die("<b>متاسفانه شما به این قسمت دسترسی ندارید</b>");
}


$adminsFile = 'admin/admins.inf';
if (!file_exists($adminsFile))
{
		show_error("Couln't find administrators' file.");
}
$admins = file($adminsFile);
for ($i=0 ; $i<count($admins) ; $i++)
{
	list($admins[$i]) = explode("|",$admins[$i]);
}
if (isset($_GET['cmd']))
{
	if ($_GET['cmd'] == 'do')
	{
		$admins = file($adminsFile);
		$newAdmins = array();
		$newAdmins[] = $admins[0];
		for ($i=1 ; $i<count($admins) ; $i++)
		{
			if (!isset($_POST["check$i"]))
			{
				$newAdmins[] = $admins[$i];
			}
		}
		if (!($file = fopen($adminsFile,"w")))
		{
			die("Coudn't open $adminsFile for writing.");
		}
		for ($i=0 ; $i<count($newAdmins) ; $i++)
		{
			$newAdmins[$i] = trim($newAdmins[$i]);
			if ($newAdmins[$i] != "")
			{
				fputs($file,"$newAdmins[$i]\n");
			}
		}
		fclose($file);
		url_redirect(getInternallink("admin","editAdmins"));
	}
	elseif ($_GET['cmd'] == "add")
	{
		if (trim($_POST['adminUsername']) == "")
		{
			show_error("Invalid Username");
		}
		if (trim($_POST['adminPass1']) == "")
		{
			show_error("Invalid Password");
		}
		if ($_POST['adminPass1'] != $_POST['adminPass2'])
		{
			show_error("The two passwords are not identical");
		}
		$admins = file($adminsFile);
		$admins[] = trim($_POST['adminUsername'])."|".md5(trim($_POST['adminPass1']))."|".$_POST['semat']."|".$_POST['email']."|".date("Y/m/d");
        
        //email
        $msg="
        yor account is:
         
         Username: ".$_POST['adminUsername']."
         Password: ".trim($_POST['adminPass1'])."
         
         ".sprintf("%s://%s%s", isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off' ? 'https' : 'http', $_SERVER['SERVER_NAME'], $_SERVER['PHP_SELF']);

             $headers = "From: course ";
        mail($_POST['email'],"You Registered",$msg,$headers);
        //email send for user
        
        
		if (!($file = fopen($adminsFile,"w")))
		{
			die("Coudn't open $adminsFile for writing.");
		}
		for ($i=0 ; $i<count($admins) ; $i++)
		{
			$admins[$i] = trim($admins[$i]);
			if ($admins[$i] != "")
			{
				fputs($file,"$admins[$i]\n");
			}
		}
		fclose($file);
		url_redirect(getInternallink("admin","editAdmins"));
	}
}
?>
<table width=95% align=center>
	<tr>
		<td>
			<?php createSectionTitle('Administrators'); ?>
		</td>
	</tr>
	<tr>
		<td>
		</td>
	</tr>
	<tr>
		<td>
			<form method=post action="<?php echo getInternallink("admin","editAdmins","cmd=do"); ?>">
			<table align=center class=blockcontent2 width=50%>
				<tr>
					<td class=blockhead colspan=2>
						&nbsp;&nbsp;Current Administrators
					</td>
				</tr>
				<tr>
					<td>
						<br/>
					</td>
				</tr>
				<tr>
					<td>
					<table align=center class=table2>
						<tr>
							<th>&nbsp;Username&nbsp;</th>
							<th>&nbsp;Type&nbsp;</th>
                            <th>&nbsp;Email&nbsp;</th>
                            <th>&nbsp;Register On&nbsp;</th>
							<?php
								if (count($admins)>1)
								{
									echo "<th>&nbsp;Delete&nbsp;</th>";
								}
								else
								{
									echo "<th>&nbsp;Type&nbsp;</th>";
								}
                                
                                
							?>
						</tr>
                        
				<?php
				$admins = file('admin/admins.inf');
					for ($i=0 ; $i<count($admins) ; $i++)
					{
						list($user,$pass,$semat,$email,$verify) = explode("|",$admins[$i]);
						echo "<tr><td align=center><b>".trim($user)."</b></td>\n";
						echo "<td align=center><i>".trim($semat)."</i></td>";
                        echo "<td align=center><a href=mailto:".trim($email)."><i>".trim($email)."</i></a></td>";
                        echo "<td align=center><i>".trim($verify)."</i></td>";
						echo "<td align=center>";
						if ($i>0)
						{
							echo "<input type=checkbox name=check$i>\n";
						}
						else
						{
							echo "(Owner)";
						}
						echo "</td>\n";
                        
     
						echo "</tr>\n";
					}
				?>
					</table>
					<br/>
					</td>
				</tr>
				<?php if (count($admins)>1) { ?>
				<tr>
					<td align=center colspan=2>
						<input type=submit value="Delete Selected Admins"><br/><br/>
					</td>
                    </tr>
				<?php } ?>
			</table>
			</form>
		</td>
	</tr>
	<tr>
		<td>
			<br/>
			<form method=post action="<?php echo getInternallink("admin","editAdmins","cmd=add"); ?>">
			<table align=center class=blockcontent2 width=50%>
				<tr>
					<td class=blockhead colspan=2>
						&nbsp;&nbsp;Add New Administrator
					</td>
				</tr>
				<tr>
					<td>
						<br/>
					</td>
				</tr>
				<tr>
					<td align=right>
						Username:
					</td>
					<td>
						<input name=adminUsername required=required>
					</td>
				</tr>
				<tr>
					<td align=right>
						Password:
					</td>
					<td>
						<input name=adminPass1 type=password required=required>
					</td>
				</tr>
				<tr>
					<td align=right>
						Confirm Password:
					</td>
					<td>
						<input name=adminPass2 type=password required=required>
					</td>
				</tr>
				<tr>
                  <tr>
					<td align=right>
						Email:
					</td>
					<td>
						<input name=email type=email required=required>
					</td>
				</tr>
				<tr>
					<td align=right>
						Type:
					</td>
					<td>
                        <input type="radio" name="semat" value="admin"> Admin<br>
						<input type="radio" name="semat" checked value="ta"> TA<br>
						<input type="radio" name="semat" value="student"> Student<br>
					</td>
				</tr>
				<tr>
					<td align=center colspan=2>
						<input type=submit value=" Add ">
						<br/><br/>
					</td>
				</tr>
			</table>
			</form>
		</td>
	</tr>
</table>
