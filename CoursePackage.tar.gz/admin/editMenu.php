<?php
if (!isset($indexFile) || trim(basename($_SERVER['PHP_SELF'])) != trim($indexFile))
{
	die('You can not access this page directly.');
}
if (!$_SESSION["isAdmin"] or $_SESSION["isTa"] or $_SESSION["isStudent"])
{
	die("شما دسترسی ندارید");
}

$file = "admin/menuItems.xml";

if (isset($_GET['id']) && strcmp($_GET['id'],"edit")==0 )
{
	$items = parseItems();
	if (! ($fout = fopen($file,"w")) )
	{
	   die("Couldn't open $file for writing.");
	}
	fputs($fout,"<?xml version='1.0' encoding='UTF-8' ?>\n");
	fputs($fout,"<items>\n");
	for ($i=0 ; $i<count($items); $i++)
	{
		if (isset($_POST["delcheck$i"]))
		{
			continue;
		}
		if ( $items[$i]['type'] == "Internal" )
		{
			fputs($fout,"\t<item type=\"Internal\">\n");
			fputs($fout,"\t\t<name>".trim($items[$i]["name"])."</name>\n");
			fputs($fout,"\t\t<link>\n");
			fputs($fout,"\t\t\t<section>".trim($items[$i]["section"])."</section>\n");
			fputs($fout,"\t\t\t<file>".trim($items[$i]["file"])."</file>\n");
			fputs($fout,"\t\t</link>\n");
		}
		else
		{
			fputs($fout,"\t<item type=\"External\">\n");
			fputs($fout,"\t\t<name>".trim($items[$i]["name"])."</name>\n");
			fputs($fout,"\t\t<link>\n");
			fputs($fout,"\t\t\t<URL>".trim($items[$i]["URL"])."</URL>\n");
			fputs($fout,"\t\t</link>\n");
		}
		if (!isset($_POST["check$i"]))
		{
			fputs($fout,"\t\t<disabled />\n");
		}
		fputs($fout,"\t</item>\n");
	}
	fputs($fout,"</items>\n");
	fclose($fout);
	url_redirect("",1,"Main Menu Edited.");
}
elseif ( isset($_GET['id']) && $_GET['id'] == "addExternal" )
{
	if ( $_POST['title'] == "" )
	{
		 show_error("You must enter a valid title.");
	}
	if ( $_POST['url'] == "" )
	{
		show_error("You must enter a valid URL.");
	}
	else
	{
		$items = parseItems();
		$items[] = array("type" => "External",
							"name" => trim($_POST['title']),
							"URL" => trim(str_replace("http://","",$_POST['url'])),
							"disabled" => false);
		if (! ($fout = fopen($file,"w")) )
		{
		   die("Couldn't open $file for writing.");
		}
		fputs($fout,"<?xml version='1.0' encoding='UTF-8' ?>\n");
		fputs($fout,"<items>\n");
		for ($i=0 ; $i<count($items); $i++)
		{
			if ( $items[$i]['type'] == "Internal" )
			{
				fputs($fout,"\t<item type=\"Internal\">\n");
				fputs($fout,"\t\t<name>".trim($items[$i]["name"])."</name>\n");
				fputs($fout,"\t\t<link>\n");
				fputs($fout,"\t\t\t<section>".trim($items[$i]["section"])."</section>\n");
				fputs($fout,"\t\t\t<file>".trim($items[$i]["file"])."</file>\n");
				fputs($fout,"\t\t</link>\n");
			}
			else
			{
				fputs($fout,"\t<item type=\"External\">\n");
				fputs($fout,"\t\t<name>".trim($items[$i]["name"])."</name>\n");
				fputs($fout,"\t\t<link>\n");
				fputs($fout,"\t\t\t<URL>".trim($items[$i]["URL"])."</URL>\n");
				fputs($fout,"\t\t</link>\n");
			}
			if ($items[$i]['disabled'])
			{
				fputs($fout,"\t\t<disabled />\n");
			}
			fputs($fout,"\t</item>\n");
		}
		fputs($fout,"</items>\n");
		fclose($fout);
		url_redirect(getInternallink("admin","editMenu"));
	}
}
else
{
?>
  <TABLE width="97%" cellspacing=1 cellpadding=0 align=center>
	<TR>
	  <TD align=center>
		  <?php createSectionTitle('Edit Main Menu'); ?>
	  </TD>
	</TR>
  </TABLE>
  <?php
	$items = parseItems();
	$found = false;
	for ($i=0 ; $i<count($items) ; $i++)
	{
		if ($items[$i]['type'] == "External")
		{
			$found = true;
			break;
		}
	}
  ?>
  <BR>
  <b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Select the items you want to make visible for your users:</b>
  <BR><BR>
  <FORM method=post action="<?php echo getInternallink("admin","editMenu","id=edit"); ?>">
  <table align=center width=30% class=block>
	<tr>
		<td>
	 <TABLE align=center class=blockcontent2 width=100%>
		 <TR>
			 <Th>
				 Item
			 </Th>
			 <Th>
				 Visible
			 </Th>
			 <?php if ($found) { ?>
			 <th>
				 Delete
			 </th>
			 <?php } ?>
		 </TR>
		 <?php
			  for ($i=0 ; $i<count($items) ; $i++)
			  {
				  echo "<TR><TD>&nbsp;&nbsp;";
				  echo $items[$i]["name"]."</TD><TD align=center>";
				  echo "<INPUT type=checkbox name=\"check$i\"";
				  if (!$items[$i]["disabled"])
				  {
					  echo 'checked';
				  }
				  echo "></TD><td align=center>";
				  if ($items[$i]['type'] != "Internal")
				  {
					  echo "<input type=checkbox name=\"delcheck$i\">";
				  }
				  echo "</td></TR>";
			  }
		 ?>
	 </TABLE>
		</td>
	</tr>
</table>

	 <BR>
	 <DIV align=center>
		  <INPUT type=submit value="   Edit    ">
	 </DIV>
  </FORM>
  <hR>
  <b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;If you want to add external links to the main menu use this section:</b>
  <BR><bR>
  <form method=post action="<?php echo getInternallink("admin","editMenu","id=addExternal"); ?>">
	  <table width=50% align=center class=table2 cellspacing=4>
		  <tr>
			  <td align=right>
				  <br/>
				  Link title:
			  </td>
			  <td>
				  <br/>
				  <input name=title size=20>
			  </td>
		  </tr>
		  <tr>
			  <td align=right>
				  Link URL:
			  </td>
			  <td>
				   <input name=url size=40>
			  </td>
		  </tr>
		  <tr>
			  <td align=center colspan=2>
				  <input type=submit value="Add External Link">
				  <br/><br/>
			  </td>
		  </tr>
	  </table>
  </form>
  (External links are links that point to pages outside this website. For example teacher may want to add a link to
  his homepage in the main menu.)
  <?php
   }
  ?>
