<?php
	if (!isset($indexFile) || trim(basename($_SERVER['PHP_SELF'])) != trim($indexFile))
	{
		die('You can not access this page directly.');
	}
?>
<?php
    $currentTag = "";
    $currentCategory = "";
    $titleValue = "";
    $linkValue = "";
    $links = array();

function linksCharacterData($parser, $data)
{
     global $currentTag,$linkValue,$titleValue;
     if (strcmp($currentTag,"Value") == 0)
     {
          $linkValue .= $data;
     } elseif (strcmp($currentTag,"Title") == 0)
     {
          $titleValue .= $data;
     }
}

function linksStartElement($parser, $name, $attr)
{
         global $currentTag,$currentCategory,$links;
         if (trim($name) == "Category")
         {
             $currentCategory = rawurldecode($attr["name"]);
             $currentTag = "";
             $links[$currentCategory] = array();
         }
         else
         {
             $currentTag = $name;
         }
}

function linksEndElement($parser, $name)
{
         global $currentTag,$linkValue,$titleValue,$links,$currentCategory;
         if (strcmp($name,"Link")==0)
         {
              $links[$currentCategory][] = array("Value" => $linkValue,
                                                 "Title" => $titleValue);
              $linkValue = "";
              $titleValue = "";
         }
}

function parseLinks()
{
      global $links;
      $xmlfile = "links/linksItems.xml";
      $links = array();

      $xmlParser = xml_parser_create();
      xml_set_element_handler($xmlParser,"linksStartElement","linksEndElement");
      xml_set_character_data_handler($xmlParser,"linksCharacterData");
      xml_parser_set_option($xmlParser,XML_OPTION_CASE_FOLDING,false);
      if (! ($fp = fopen($xmlfile,"r")) )
      {
            die("Could not open $xmlfile for reading.");
      }
      while (($data = fread($fp,4096)))
      {
           if (!xml_parse($xmlParser,$data,feof($fp)))
           {
                die(sprintf("XML error at line %d column %d : %s",
                                     xml_get_current_line_number($xmlParser),
                                     xml_get_current_column_number($xmlParser),
                                     xml_error_string(xml_get_error_code($xmlParser))));
           }
      }
      fclose($fp);
      xml_parser_free($xmlParser);
      return $links;
}
?>
