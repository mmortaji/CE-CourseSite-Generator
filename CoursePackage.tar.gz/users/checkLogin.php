<?php
require_once 'login.php';
$adminsFile = 'admin/admins.inf';
$onlinesFile = 'users/onlines.inf';

function check_login($username,$password,$firstCheck=true)
{
	global $adminsFile;
	if (!$firstCheck)
	{
		$onlines = file('users/onlines.inf');
		$newOnlines = array();
		for ($i=0 ; $i<count($onlines) ; $i++)
		{
			list($name,$time,$sess) = explode("|",$onlines[$i]);
			if ($time + 300 > time())
			{
				$time = time();
				$newOnlines[] = implode("|",array($name,$time,$sess));
			}
		}
		writeOnlines($newOnlines);
		$onlines = file('users/onlines.inf');
		for ($i=0 ; $i<count($onlines) ; $i++)
		{
			list($name,$time,$sess) = explode("|",$onlines[$i]);
			if ((trim($name) == $username) && trim($sess) == session_id())
			{
				//$_SESSION['Logged_in'] = true;
				$admins = file($adminsFile);
				for ($j=0 ; $j<count($admins) ; $j++)
				{
						list($admin,$pass,$semat) = explode("|",$admins[$j]);
				    //list($admin) = explode("|",$admins[$j]);
					if (trim($admin) == trim($username) && trim($semat) == "admin")
					{
                        $_SESSION['Logged_in'] = true;
						$_SESSION['isAdmin'] = true;
						return;
					}//Admin session
					if (trim($admin) == trim($username) && trim($semat) == "ta")
					{
                        $_SESSION['Logged_in'] = true;
						$_SESSION['isTa'] = true;
						return;
					}//TA session
					if (trim($admin) == trim($username) && trim($semat) == "student")
					{
                        $_SESSION['Logged_in'] = true;
						$_SESSION['isStudent'] = true;
						$_SESSION['username'] = $username;
						return;
					}//students session
				}
				$_SESSION['isAdmin'] = false;
				return;
			}
		}
		//$_SESSION["UserName"] = "";
		$_SESSION["isAdmin"] = false;
		$_SESSION["Logged_in"] = false;
		return;
	}
	if (ldap_auth($username,$password))
	{
		$_SESSION["UserName"] = $username;
		$_SESSION["Logged_in"] = true;
		$_SESSION["isAdmin"] = false;
		$admins = file($adminsFile);
		for ($i=0 ; $i<count($admins) ; $i++)
		{
			list($admin) = explode("|",$admins[$i]);
			if (trim($admin) == trim($username))
			{
				$_SESSION["isAdmin"] = true;
				break;
			}
		}
		return;
	}
	show_error("Invalid username or passwords or check your email for verification ","Login Error");
}

function writeOnlines($onlines)
{
	global $onlinesFile;
	if (!($handle = fopen($onlinesFile,"w+")))
	{
		die("Couldn't open $onlinesFile for writing.");
	}
	for ($i=0 ; $i<count($onlines) ; $i++)
	{
		$onlines[$i] = trim($onlines[$i]);
		if ($onlines[$i] != "")
		{
			fputs($handle,"$onlines[$i]\n");
		}
	}
	fclose($handle);
}

?>
