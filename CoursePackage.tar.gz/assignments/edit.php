<?php
if (!isset($indexFile) || trim(basename($_SERVER['PHP_SELF'])) != trim($indexFile))
{
	die('You can not access this page directly.');
}

if (!$_SESSION["isAdmin"])
{
	die('Access Denied');
}

require_once 'parseAssigns.php';

function deleteDir($dirname)
{
	if ($dir = @opendir($dirname))
	{
		while (($file = readdir($dir)) !== false )
		{
			if ($file == "." || $file == "..")
			{
				continue;
			}
			if (is_dir("$dirname/$file"))
			{
				deleteDir("$dirname/$file");
			}
			else
			{
				unlink("$dirname/$file");
			}
		}
		closedir($dir);		
	}
	else
	{
		show_error("Couldn't read directory contents of $dirname.");
	}
	if (!rmdir($dirname))
	{
		show_error("Couldn't delete $dirname directory");
	}
	return;
}
	
createSectionTitle('Edit Assignment');

if (isset($_GET['start']))
{
	unset($_SESSION['tmp_files']);
	unset($_SESSION['assign_id']);
	$assigns = parseAssigns();
	$id = $_GET['id'];
	$_SESSION['assign_id'] = $id;
	$_REQUEST['comment'] = $assigns[$id]['Comment'];
	$_REQUEST['title'] = $assigns[$id]['Title'];
	list($y,$m,$d) = explode("/",$assigns[$id]['DueDate']);
	$_REQUEST['year'] = $y;
	$_REQUEST['month'] = $m;
	$_REQUEST['day'] = $d;
	if (trim($assigns[$id]['Dir']) == "")
	{
		show_error("Couldn't find assignment directory.");
	}
	$dir = dirname($_SERVER['SCRIPT_FILENAME'])."/".$assigns[$id]['Dir'];
	$tmpdir = dirname($_SERVER['SCRIPT_FILENAME'])."/assignments/files/tmp";
	//die("$dir > $tmpdir");
	if (is_dir($tmpdir))
	{
		deleteDir($tmpdir);
	}
	if (!@mkdir($tmpdir,0755))
	{
		show_error("An error occured while trying to create temporary directory '$tmpdir'");
	}
	$files = $assigns[$id]['Files'];
	reset($files);
	while (list($key) = each($files))
	{
		rename("$dir/".trim($files[$key]['FileName']),"$tmpdir/".trim($files[$key]['FileName']));
		$_SESSION['tmp_files'][] = array("file" => $files[$key]['FileName'],
										"comment" => $files[$key]['FileComment']);
	}
	if (is_dir($dir))
	{
		deleteDir($dir);
	}	
}

if (isset($_POST['cmd']) && $_POST['cmd']=="delFile")
{
	unset($_SESSION['tmp_files'][$_POST['param1']]);
	url_redirect(getInternallink("assignments",
										"edit",
										"title=".rawurlencode($_POST['title']).
										"&amp;comment=".rawurlencode($_POST['comment']).
										"&amp;year=$_POST[year]".
										"&amp;month=$_POST[month]".
										"&amp;day=$_POST[day]"));
}
elseif (isset($_POST['cmd']) && $_POST['cmd']=="cancel")
{
	$assigns = parseAssigns();
	$dir = dirname($_SERVER['SCRIPT_FILENAME'])."/".$assigns[$_SESSION['assign_id']]['Dir'];
	if (! @mkdir($dir) )
	{
		show_error("Couldn't retrieve assignment directory.");
	}
	$tmpdir = dirname($_SERVER['SCRIPT_FILENAME'])."/assignments/files/tmp";
	$files = $assigns[$_SESSION['assign_id']]['Files'];
	print_r($files);
	reset($files);
	while (list($key) = each($files))
	{
		if (! @rename("$tmpdir/".trim($files[$key]['FileName']),"$dir/".trim($files[$key]['FileName'])) )
		{
			show_error("Couldn't retrieve assignment files.");
		}
	}
	if (is_dir($tmpdir))
	{
		deleteDir($tmpdir);
	}
	unset($_SESSION['tmp_files']);
	url_redirect(getInternallink("assignments","assignments"));
}
elseif (isset($_POST['cmd']) && $_POST['cmd']=="upload")
{
	if (trim($_FILES["userfile"]["name"]) == "")
	{
		show_error("Enter a valid file name.");
	}
	$dir = dirname($_SERVER['SCRIPT_FILENAME'])."/assignments/files/tmp";
	if (!is_dir($dir))
	{
		if (!@mkdir($dir,0755))
		{
			show_error("An error occured while trying to create new assignment directory.");
		}
	}
	$file = $dir."/".$_FILES["userfile"]["name"];
	if (file_exists($file))
	{
		show_error("Already there is a file with this name in $dir folder");
	}
	if (!@is_uploaded_file($_FILES["userfile"]["tmp_name"]))
	{
		show_error("An error occured while uploading file");
	}
	else
	{
		if (!@move_uploaded_file($_FILES["userfile"]["tmp_name"],$file))
		{
			show_error("An error occured whilt trying to upload your file.");
		}
		else
		{
			chmod($file,0644);
			if (!isset($_SESSION['tmp_files']))
			{
				$_SESSION['tmp_files'] = array();
			}
			$_SESSION['tmp_files'][] = array("file" => $_FILES["userfile"]["name"], "comment" => trim($_POST['fileComment']));
			
			url_redirect(getInternallink("assignments",
										"edit",
										"title=".rawurlencode($_POST['title']).
										"&amp;comment=".rawurlencode($_POST['comment']).
										"&amp;year=$_POST[year]".
										"&amp;month=$_POST[month]".
										"&amp;day=$_POST[day]"));
		}
	}		
}
elseif (isset($_POST['cmd']) && $_POST['cmd']=="do")
{
	$assigns = parseAssigns();
	$dir = dirname($_SERVER['SCRIPT_FILENAME'])."/".$assigns[$_SESSION['assign_id']]['Dir'];
	$tmpdir = dirname($_SERVER['SCRIPT_FILENAME'])."/assignments/files/tmp";
	if (!is_dir($dir))
	{
		if (!@mkdir($dir,0755))
		{
			show_error("An error occured while trying to create new assignment directory.");
		}
	}
	$newFile = array();
	if (isset($_SESSION['tmp_files']))
	{
		reset($_SESSION['tmp_files']);
		while (list($key,$value) = each($_SESSION['tmp_files']))
		{
			$newFiles[] = array("FileName" => $_SESSION['tmp_files'][$key]['file'],
									"FileComment" => $_SESSION['tmp_files'][$key]['comment']);
			if (!@rename($tmpdir."/".trim($_SESSION['tmp_files'][$key]['file']),$dir."/".trim($_SESSION['tmp_files'][$key]['file'])))
			{
				show_error("Couldn't move files from temporary directory.");
			}
		}
	}
	$new = array("DueDate" => trim($_POST['year'])."/".trim($_POST['month'])."/".trim($_POST['day']),
					"Comment" => trim($_POST['comment']),
					"Files" => $newFiles,
					"Title" => trim($_POST['title']),
					"Dir" => trim($assigns[$_SESSION['assign_id']]['Dir']));
	
	$newassigns = array();
	for ($i=0 ; $i<count($assigns) ; $i++)
	{
		if ($i == $_SESSION['assign_id'])
		{
			$newassigns[$i] = $new;
		}
		else
		{
			$newassigns[$i] = $assigns[$i];
		}
	}
	$assigns = $newassigns;
	require 'writeAssigns.php';
	$tmpdir = dirname($_SERVER['SCRIPT_FILENAME'])."/assignments/files/tmp";
	if (is_dir($tmpdir))
	{
		deleteDir($tmpdir);
	}
	url_redirect(getInternallink("assignments","assignments"));
}
elseif (isset($_POST['cmd']) && $_POST['cmd']=="uploadFrm")
{
?>
<table width=97% align=center cellspacing=0 cellpadding=0>
	<tr>
		<td>
			<br/>
			<form method=post enctype="multipart/form-data" action="<?php echo getInternallink("assignments","edit"); ?>">
				<input type=hidden name=cmd value="upload">
				<table class=blockcontent2 width=80% align=center>
					<tr>
						<td align=right>
							<br/><br/>
							Assignments File:
						</td>
						<td>
							<br/><br/>
							<input name=userfile type=file size=40>
						</td>
					</tr>
					<tr>
						<td align=right>
							File comment:
						</td>
						<td>
							<input name=fileComment size=70>
						</td>
					</tr>
					<tr>
						<td align=center colspan=2>
							<br/>
							<input type=submit value=" Upload ">
							<input type=button 
									value=" Cancel " 
									onclick="cmd.value='';document.location='<?php echo getInternallink("assignments","edit","title=".rawurlencode($_POST['title'])."&amp;comment=".rawurlencode($_POST['comment'])."&amp;year=$_POST[year]&amp;month=$_POST[month]&amp;day=$_POST[day]");?>';">
							<br/><br/>
						</td>
					</tr>
				</table>
				<input type=hidden value="<?php echo rawurlencode($_POST['title']); ?>" name=title>
				<input type=hidden value="<?php echo rawurlencode($_POST['comment']); ?>" name=comment>
				<input type=hidden value="<?php echo $_POST['year']; ?>" name=year>
				<input type=hidden value="<?php echo $_POST['month']; ?>" name=month>
				<input type=hidden value="<?php echo $_POST['day']; ?>" name=day>
			</form>				
		</td>
	</tr>
</table>
<?php
}





else
{
?>
<form method=post action="<?php echo getInternallink("assignments","edit"); ?>">
	<input type=hidden name=cmd value="do">
	<input type=hidden name=param1 value="">
	<table width=95% align=center class=blockcontent2>
		<tr>
			<td>
				<br/>
			</td>
		</tr>
		<tr>
			<td align=right>			
				Title:
			</td>
			<td>
				<input name=title <?php if (isset($_REQUEST['title'])) echo 'value="'.htmlspecialchars(trim(rawurldecode($_REQUEST['title']))).'"';
								  ?>>
			</td>
		</tr>
		<tr>
			<td align=right>
				Deadline:
			</td>
			<td>
			&nbsp;Year:
			<?php
				require_once 'includes/shamsi.php';
				list($M_y,$M_m,$M_d) = explode("-",date("Y-m-d"));
				list($y,$m,$d) = Miladi_to_Shamsi($M_y,$M_m,$M_d);
							
				echo '<select name="year">';
				for ($year=$y-2 ; $year<$y+5 ; $year++)
				{
					echo "<option value=\"$year\"";
					if (isset($_REQUEST['year']))
					{
						if  ($_REQUEST['year'] == $year)
						{
							echo " selected";
						}
					}
					elseif ($year == $y)
					{
						echo " selected";
					}
					echo ">$year</option>\n";
				}
				echo "</select>\n";
				echo "&nbsp;&nbsp;&nbsp;Month: &nbsp;";
				echo "<select name=\"month\">\n";
				for ($i=1 ; $i<13 ; $i++)
				{
					echo "<option value=\"$i\"";
					if (isset($_REQUEST['month']))
					{
						if  ($_REQUEST['month'] == $i)
						{
							echo " selected";
						}
					}
					elseif ($i == $m)
					{
						echo " selected";
					}
					echo ">";
					if ($i<10)
					{
						echo "0";
					}
					echo "$i</option>\n";
				}
				echo "</select>\n";
				
				echo "&nbsp;&nbsp;&nbsp;Day: &nbsp;";
				echo "<select name=\"day\">\n";
				for ($i=1 ; $i<32 ; $i++)
				{
					echo "<option value=\"$i\"";
					if (isset($_REQUEST['day']))
					{
						if  ($_REQUEST['day'] == $i)
						{
							echo " selected";
						}
					}
					elseif ($i == $d)
					{
						echo " selected";
					}
					echo ">";
					if ($i<10)
					{
						echo "0";
					}
					echo "$i</option>\n";
				}
				echo "</select>\n";
			?>
			</td>
		</tr>
		<tr>
			<td align=right valign=top>
				Comment:
			</td>
			<td>
				<textarea name=comment rows=8 cols=80><?php if (isset($_REQUEST['comment'])) echo htmlspecialchars(trim(rawurldecode($_REQUEST['comment'])));
													  ?></textarea>
			</td>
		</tr>
<?php
	if (isset($_SESSION['tmp_files']))
	{
?>
		<tr>
			<td colspan=2 align=center>
				<br/>
				<table width=90% class=table2>
					<tr>
						<th>
							File Name
						</th>
						<th>
							Comment
						</th>
						<th width=1%>
							&nbsp;Delete&nbsp;
						</td>
					</tr>
<?php
		reset($_SESSION['tmp_files']);
		while (list($key,$value) = each($_SESSION['tmp_files']))
		{
?>
					<tr>
						<td class=row1>
							&nbsp;&nbsp;<?php echo $_SESSION['tmp_files'][$key]['file']; ?>
						</td>
						<td class=row1>
							<?php echo $_SESSION['tmp_files'][$key]['comment']; ?>
						</td>						
						<td align=center class=row1>
							<button type=submit onclick="cmd.value='delFile';param1.value='<?php echo $key; ?>';".>
								&nbsp;&nbsp;<img src="images/delete.gif" border=0 alt="Delete">&nbsp;&nbsp;
							</button>							
						</td>
					</tr>
<?php
		}
?>
				</table>
			</td>
		</tr>
<?php
	}
?>
		<tr>
			<td colspan=2 align=right>
				<br/>
				<input type=submit value="Add assignment files" onclick="cmd.value='uploadFrm';">&nbsp;&nbsp;
			</td>
		</tr>
		<tr>
			<td>
				<br/>
			</td>
		</tr>
		<tr>
			<td colspan=2 align=center>
				<input type=submit value="  Edit  ">
				<input type=submit value=" Cancel " onclick="cmd.value='cancel';">
			</td>
		</tr>
		<tr>
			<td>
				<br/>
			</td>
		</tr>
	</table>
</form>

<?php
}

?>
