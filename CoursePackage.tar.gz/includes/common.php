<?php
	$indexFile = "index.php";
	if (defined('FROM_INDEX'))
	{
		$_SERVER['PHP_SELF'] = $_SERVER['SCRIPT_NAME'];
	}
	if (trim(basename($_SERVER['PHP_SELF'])) != trim($indexFile) && !defined('INSTALL'))
	{
		die('You can not access this page directly..');
	}

require 'syllabus/parseInfo.php';

$Course = parseCourseInfo();

function putbr($str)
{
	return str_replace("\n","<br>",$str);
}

function showHeader()
{
	global $Course;
?>
	<TABLE width="95%" class=headtable>
		<TR>
   			<TD class=head>
      			<TABLE width="100%" class=topHead>
       				<TR vAlign=center>
		          		<TD>
       						<span class="title">&nbsp;<?php echo $Course['Name']; ?></span>
						</TD>
		          		<TD vAlign=bottom align=right class=courseNumber>
	          				<B>
        							<?php echo $Course['Number']; ?>&nbsp;
		        			</B>
			        	</TD>
			        </TR>
		        </TABLE>
	      		<TABLE width="100%" class=subHead>
		        	<TR vAlign=center>
			        	<TD>
			        		<SPAN class=heading>&nbsp;&nbsp;<?php echo "$Course[Department] Department- $Course[University]"; ?></SPAN>
			        	</TD>
			        	<TD align=right class=semester>
			        		<?php echo "$Course[Semester] - Group $Course[Group]"; ?>&nbsp;
  						</TD>
  					</TR>
  				</TABLE>
  			</TD>
  		</TR>  		
  	</TABLE>
  	<br/>
<?php
}

function showFooter($files)
{
		global $Course;
?>
	<P>
		<TABLE class=footerTable cellSpacing=0 cellPadding=0 width="100%" border=0>
     	    <TR>
	         <!-- 	<TD align=left>
	          		&#169; 2004
	          	</TD> -->
	          	<td>
					&nbsp;This website is visited <b><?php echo $_SESSION['visitTimes'.md5($Course['Name'])]; ?></b> times since <?php echo $Course['startDate']; ?>.
				</td>
	          	<TD align=right>
					<?php
						reset($files);
						$lastdate = filemtime(current($files));
						while ( list($key,$theFile) = each($files) )
						{
							//echo "$theFile <br/>";
							if ( filemtime($theFile) > $lastdate )
							{
								$lastdate = filemtime($theFile);
							}
						}
						echo "Updated ".date("l Y-m-d H:i",$lastdate);
					  ?>&nbsp;
				</TD>
			</TR>
		</TABLE>
		<br/>
		<div align=center class=copyright>
			This website is generated automatically by <b>CS Coursesite Generator</b> which
		   	is produced by <br/><a href="">Yasser Ganjisaffar</a> and <a href="https://github.com/mortaji/CS-CourseSite-Generator">Mohammad Mortaji</a> and is under <a href="http://www.gnu.org/copyleft/
		   	.html">GNU GPL version 3.0</a>
		</div>
	 </P>
<?php
}
function showMenu()
{
	global $indexFile;
   $items = parseItems();
?>
	<TABLE cellspacing=0 cellpadding=0 border=0 width="100%">
		<TR>
			<TD>
				<TABLE cellSpacing=0 cellPadding=3 width="100%" class=block>
					<TR>
     	     			<TD class=block>
							<TABLE class=blockhead>
								<TR>
									<TD>
										&nbsp;&nbsp;Main Menu
									</TD>
									<?php if ( $_SESSION["isAdmin"] and !$_SESSION['isTa'] and !$_SESSION['isStudent'] ) { ?>        
									<TD align=right width=10>
										<a href="<?php echo getInternallink("admin","editMenu"); ?>">
											<img src="images/edit.gif" border=0 alt="Edit this menu">
										</a>										
									</TD>
									<?php } ?>
								</TR>
							</TABLE>
						</TD>
		     		</TR>
		     		<tr>
						<td class=block>
							<div id=bbody style="display:;">													
								<table class=blockcontent width="100%" cellspacing=0 cellpadding=3>
									<TR>
										<TD>
                                            <table>
                                                   <tr>
                                                       <td>
															&nbsp;<img src="images/arrow.gif" border=0>&nbsp;&nbsp;<A href="<?php echo getIndex(); ?>">Home</A>
                                                        </td>
                                                    </tr>
												<?php
												for ($i=0 ; $i<count($items) ; $i++)
												{
													if ($_SESSION["isAdmin"] || !$items[$i]["disabled"])
													{
														echo '<tr><td>&nbsp;<img src="images/arrow.gif" border=0>&nbsp;&nbsp;<a href="'.getlink($items[$i]).'">'.str_replace(" ","&nbsp;",$items[$i]["name"])."</a></td></tr>\n";
													 }
												}
												?>
									        </table>
										</td>
									</TR>
								</table>
							</div>																
		  				</TD>
					</TR>
				</TABLE>
			</TD>
		</TR>
	</TABLE>
	<br />
	<?php
	if (!isset($_SESSION["Logged_in"]) || !$_SESSION["Logged_in"])
	{
	?>
		<TABLE cellspacing=0 cellpadding=0 width="100%" border=0>
			<TR class=signIn>
				<TD>
					<TABLE cellspacing=0 cellpadding=0 width="100%" border=0>
						<TR>
							<TD>								
								<TABLE cellspacing=0 class=block width="100%">
									<FORM action="<?php echo getInternalLink("users","sign","id=in"); ?>" method=POST>
											<TR>
												<TD class=block colspan=2>												
													<TABLE class=blockhead>
														<TR>
															<TD>
																&nbsp;&nbsp;Users
															</TD>
														</TR>
													</TABLE>
												</TD>
											</TR>
											<tr>
												<td class=block>
													<div id=bbody style="display:;">													
														<table class=blockcontent width="100%" border=0 cellspacing=0 cellpadding=0>
															<tr>
																<td>
																	<img src="images/spacer.gif" height=1 /><br/>
																</td>
															</tr>
															<TR>
																<TD>
																	&nbsp; Username
																</TD>														
																<TD align=right>
																	<INPUT name="username" size=9>&nbsp;
																</TD>
															</TR>
															<TR>
																<TD>
																	&nbsp; Password
																</TD>
																<TD align=right>	
																	<INPUT type=password name="password" size=9>&nbsp;
																</TD>
															</TR>
															<TR>
																<TD valign=center>
																</TD>
																<TD align=right>
																	<INPUT type=submit value="Login">&nbsp;
																</TD>
															</TR>
															<tr>
																<td colspan=2>
																	<hr/>
																</td>
															</tr>
															<tr>
																<td colspan=2>
																	&nbsp;&nbsp;Online members:
																	<b>
																	<?php
																		$onlines = file('users/onlines.inf');
																		echo count($onlines);
																	?>															
																	</b>
																</td>
															</tr>
															<?php 
															$last = @file('users/lastLogin.inf');
															if ($last !== false) {
															?>
															<tr>
																<td colspan=2>
																	&nbsp;&nbsp;<?php echo str_replace(" ","&nbsp;","Last login: <b>$last[0]</b>"); ?>
																</td>															
															</tr>				
															<?php } ?>											
															<tr>
																<td>
																	<img src="images/spacer.gif" height=1 /><br/>
																</td>
															</tr>
														</table>													
													</div>
												</td>
											</tr>
									</FORM>
								</TABLE>
							</TD>
						</TR>
					</TABLE>
				</TD>
			</TR>
		</TABLE>
	<?php
	} elseif (isset($_SESSION["Logged_in"])	&& $_SESSION["Logged_in"])
	{
	?>
		<TABLE cellspacing=0 cellpadding=0 width="100%" border=0>
			<TR class=signIn>
				<TD>
					<TABLE cellspacing=0 cellpadding=0 width="100%" border=0>
						<TR>
							<TD>
								<TABLE cellspacing=0 class=block width="100%">
									<TR>
										<TD class=block colspan=2>
											<TABLE class=blockhead>
												<TR>
													<TD>
														&nbsp;&nbsp;Users
													</TD>
												</TR>
											</TABLE>
										</TD>
									</TR>
									<tr>
										<td class=block>
											<table class=blockcontent>
												<tr>
													<td align=center>
														<br />
														Welcome, <b><?php echo $_SESSION["UserName"]; ?></b>!
														<br /><br /><hr />
													</td>
												</tr>
												<TR>
													<TD>
													<?php if ($_SESSION['isAdmin'] and !$_SESSION['isTa'] and !$_SESSION['isStudent']) { ?>
														&nbsp;<a href="<?php echo getInternallink("admin","editAdmins"); ?>">
															<img src="images/arrow.gif" border=0>&nbsp;&nbsp;Administrators
															</a><br/>
													<?php } ?>													
														&nbsp;<a href="<?php echo getInternallink("admin","changePass"); ?>">
																<img src="images/arrow.gif" border=0>&nbsp;&nbsp;Change Password
															</a>
															<br/>
														&nbsp;<a href="<?php echo getInternallink("users","sign","id=out"); ?>">
																<img src="images/arrow.gif" border=0>&nbsp;&nbsp;Sign out
															</a>
															<br/>
													</td>
												</tr>
												<tr>
													<td colspan=2>
														<hr/>
													</td>
												</tr>
												<tr>
													<td colspan=2>
														&nbsp;&nbsp;Online members:
														<b>
														<?php
															$onlines = file('users/onlines.inf');
															echo count($onlines);
														?>															
														</b>
													</td>
												</tr>
												<?php 
												$last = @file('users/lastLogin.inf');
												if ($last !== false) {
												?>
												<tr>
													<td colspan=2>
														&nbsp;&nbsp;<?php echo str_replace(" ","&nbsp;","Last login: <b>$last[0]</b>"); ?>
													</td>															
												</tr>				
												<?php } ?>		
												<tr>
													<td>
														<img src="images/spacer.gif" height=7 /><br/>
													</td>
												</tr>									
											</table>				
										</TD>
									</TR>									
								</table>
							</td>
						</tr>
					</TABLE>
				</TD>
			</TR>        
			<TR>
				<TD>
					<TABLE width="100%">						
					</table>
				</td>
			 </tr>
		  </table>
	<?php
	}
}

function makeHEAD($PageName)
{
	global $Course;
    if (!$_SESSION['isAdmin'])
    {
        $items = parseItems();
        for ($i=0 ; $i<count($items) ; $i++)
        {
            if (strcmp(trim($items[$i]["name"]),trim($PageName))==0)
            {
             if ($items[$i]["disabled"])
             {
                die("Access Denied");
             }
            }
        }
    }
    $themes = file("admin/theme.inf");
    $theme = trim($themes[0]);
    if (!is_dir("themes/$theme"))
    {
		$theme = "default";
    }
?>
<HEAD>
	<TITLE><?php echo $Course['Name']." Course Page / ".ucwords($PageName); ?></TITLE>
	<META http-equiv=Content-Type content="text/html; charset=utf-8">
	<base href="http://<?php echo $_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF']; ?>">
	<LINK rel="stylesheet" type="text/css" href="themes/<?php echo $theme; ?>/style/style.css">
</HEAD>
<?php
}

$items = array();
$currentTag = "";
$currentCategory = "";
$nameValue = "";
$sectionValue = "";
$fileValue = "";
$URLValue = "";
$itemType = "";
$isDisabled = false;

function characterData($parser, $data)
{
     global $currentTag,$nameValue,$URLValue,$sectionValue,$fileValue;
     $var = $currentTag."Value";
     if ($var != 'nameValue' && $var !='URLValue' && $var != 'sectionValue' && $var !='fileValue') return;
     $$var .= $data;
}

function startElement($parser, $name, $attr)
{
         global $currentTag,$itemType;
         if ($name == "item")
         {
			 if ($attr['type'] == "Internal")
			 {
				 $itemType = "Internal";
			 }
			 else
			 {
				 $itemType = "External";
			 }
		 }
         $currentTag = $name;
}

function endElement($parser, $name)
{
         global $currentTag,$nameValue,$items,$isDisabled,$sectionValue,$fileValue,$URLValue,$itemType;
         if ( $name == "item" )
         {
			 if ($itemType != "Internal")
			 {
				 $items[] = array("name" => $nameValue,
									 "type" => "External",
									 "URL" => $URLValue,
									 "disabled" => $isDisabled);
			 }
			 else
			 {
				 $items[] = array("name" => $nameValue,
                                   "type" => "Internal",
                                   "disabled" => $isDisabled,
                                   "section" => $sectionValue,
                                   "file" => $fileValue);
              }
              $nameValue = "";
              $sectionValue = "";
              $fileValue = "";
              $URLValue = "";              
              $isDisabled = false;
              $itemType = "";
          } elseif (strcmp($name,"disabled")==0)
          {
              $isDisabled = true;
          }
}

function parseItems()
{
     $xmlfile = "admin/menuItems.xml";
     global $items,$currentTag,$nameValue,$linkValue,$isDisabled,$itemType;
     $items = array();
     $currentTag = "";
     $nameValue = "";
     $sectionValue = "";
     $fileValue = "";
     $itemType = "";
     $isDisabled = false;
     
      $xmlParser = xml_parser_create();
      xml_set_element_handler($xmlParser,"startElement","endElement");
      xml_set_character_data_handler($xmlParser,"characterData");
      xml_parser_set_option($xmlParser,XML_OPTION_CASE_FOLDING,false);
      if (! ($fp = fopen($xmlfile,"r")) )
      {
            die("Could not open $xmlfile for reading.");
      }
      while (($data = fread($fp,4096)))
      {
           if (!xml_parse($xmlParser,$data,feof($fp)))
           {
                die(sprintf("XML error at line %d column %d : %s",
                                     xml_get_current_line_number($xmlParser),
                                     xml_get_current_column_number($xmlParser),
                                     xml_error_string(xml_get_error_code($xmlParser))));
           }
      }
      fclose($fp);
      xml_parser_free($xmlParser);
      return $items;
}

function getIndex()
{
	return "http://".$_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF'];
}

function getInternallink($sec,$file,$param = "")
{
	global $indexFile;
	$sec = trim($sec);
	$file = trim($file);
	if ($param != "")
	{
		$result = "http://$_SERVER[HTTP_HOST]$_SERVER[SCRIPT_NAME]?section=$sec&amp;file=$file";
		$result .= "&amp;$param";
	}
	else
	{
		$result = "http://$_SERVER[HTTP_HOST]$_SERVER[SCRIPT_NAME]?section=$sec&amp;file=$file";
	}	
	return trim($result);
}

function getlink($item)
{
	if ($item['type'] == "Internal") {
		return getInternallink($item['section'],$item['file']);
	} else
	{		
		return "http://$item[URL]";
	}
}

function createSectionTitle($title)
{
?>
	<table class=blockhead>
	   <tr>
			   <TD align=center class=sectiontitle>
				   <?php echo $title; ?>
			   </TD>
		</tr>
	</table>
	<br />
<?php
}

function url_redirect($url='',$delay=0,$msg="") {
    global $indexFile;
    if ($url == '')
    {
		$url = "http://".$_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF'];
	}
	else
	{
		$url = str_replace("&amp;","&",$url);
	}
    ob_clean();
	if ($delay == 0)
	{
		header("Location: $url");
	}
	else
	{
?>
<html>
	<head>
		<meta http-equiv=refresh content="<?php echo $delay.";URL=$url"; ?>">
		<base href="http://<?php echo $_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF']; ?>">
		<LINK rel="stylesheet" type="text/css" href="themes/default/style/style.css">
	</head>
	<body>
		<br/><br/><br/><br/><br/><br/>
		<div align=center>
			<b><?php echo $msg; ?></b>
		</div>
	</body>
</html>
<?php
	}
	die();
}

function show_error($error,$title="ERROR")
{
	if (isset($_SERVER['HTTP_REFERER']))
	{
		$link = $_SERVER['HTTP_REFERER'];
		if (isset($_SERVER['QUERY_STRING']))
		{
			//$link .= "?$_SERVER[QUERY_STRING]";
		}
	}
	else
	{
		$link = "javascript:history.go(-1)";
	}
	die('
		<center>
			<table border="0" cellspacing=0 cellpadding="0" width="96%">
				<tr>
					<td align="center">
						<table width="100%" border="0" cellspacing="1" cellpadding="8" class=table2>
							<tr>								
								<td align="center">
									<br/>
									<font class="errorTitle">'.$title.'</font>
								</td>
							</tr>
							<tr>
								<td align="center">'.$error.
									'<br /><br />[ <a href="'.$link.'">Go Back</a> ]
									<br/><br/>
								</td>
							</tr>
						</table>
					</td>
				</tr>
			</table>
        </center>');    
}

function show_msg($msg,$showBack = true)
{
	if (isset($_SERVER['HTTP_REFERER']))
	{
		$link = $_SERVER['HTTP_REFERER'];
		if (isset($_SERVER['QUERY_STRING']))
		{
			//$link .= "?$_SERVER[QUERY_STRING]";
		}
	}
	else
	{
		$link = "javascript:history.go(-1)";
	}
	echo '
		<center>
			<table border="0" cellspacing=0 cellpadding="0" width="96%">
				<tr>
					<td align="center">
						<table width="70%" border="0" cellspacing="1" cellpadding="8" class=table2>
							<tr>
								<td align="center"><br/><b>'.$msg.'</b><br /><br />';
	if ($showBack)	echo '[ <a href="'.$link.'">Go Back</a> ]<br/><br/>';
	echo'						</td>
							</tr>
						</table>
					</td>
				</tr>
			</table>
        </center>';    
}

function fixSlashes()
{
	if (!get_magic_quotes_gpc())
	{
		return;
	}
	reset($_GET);
	while (list($key) = each($_GET))
	{
		if (!is_array($_GET[$key]))
		{
			$_GET[$key] = stripslashes($_GET[$key]);
		}
	}
	reset($_POST);
	while (list($key) = each($_POST))
	{
		if (!is_array($_POST[$key]))
		{
			$_POST[$key] = stripslashes($_POST[$key]);
		}
	}
	reset($_REQUEST);
	while (list($key) = each($_REQUEST))
	{
		if (!is_array($_REQUEST[$key]))
		{
			$_REQUEST[$key] = stripslashes($_REQUEST[$key]);
		}
	}

}
	
?>

