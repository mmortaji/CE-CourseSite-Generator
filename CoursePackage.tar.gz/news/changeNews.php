<?php
	if (!isset($indexFile) || trim(basename($_SERVER['PHP_SELF'])) != trim($indexFile))
	{
		die('You can not access this page directly.');
	}
?>
<?php
	if (!$_SESSION["isAdmin"])
    {
        die("ACCESS DENIED");
    }
	$NewsFile = "news/news.xml";
	$NewsHandle = fopen($NewsFile,"r");
    require 'parseNews.php';
    $news = parseNews();
    if ($_GET['cmd'] == "delete")
    {
        if (! ($fout = fopen($NewsFile,"w")) )
        {
             die("Couldn't open $NewsFile for writing.");
        }
        fputs($fout,"<?xml version='1.0' encoding='UTF-8' ?>\n");
        fputs($fout,"<News>\n");
        for ($i=0 ; $i<count($news); $i++)
        {
              if ($_GET['id'] == $i)
              {
                  continue;
              }
              fputs($fout,"\t<item>\n");
              fputs($fout,"\t\t<date>".trim($news[$i]["date"])."</date>\n");
              fputs($fout,"\t\t<content><![CDATA[".trim($news[$i]["content"])."]]></content>\n");
              fputs($fout,"\t\t<rtl><![CDATA[".trim($news[$i]["rtl"])."]]></rtl>\n");
              fputs($fout,"\t</item>\n");
        }
        fputs($fout,"</News>\n");
        fclose($fout);
        url_redirect();
    }
    elseif ($_GET['cmd'] == "edit")
    {
?>

	<TABLE width="90%" border=0 cellspacing=0 cellpadding=3 class=tablehead1 align=center>
		<TR>
			<TD>
				<?php createSectionTitle('Edit Announcement'); ?>
			</TD>
		</TR>
	</TABLE>
	<BR>
	<BR>
	<FORM method=post action="<?php echo getInternallink("news","changeNews","cmd=change&amp;id=$_GET[id]"); ?>">
	<TABLE width=70% align=center>
		<!--   <TR>
			   <TD align=right>
				   Date:
			   </TD>
			   <TD>
				   <INPUT name=newsdate value="<?php echo $news[$_GET['id']]["date"]; ?>" size=35>
			   </TD>
		   </TR> -->
		   <TR>
			   <TD align=right valign=top>
				   Content:
			   </TD>
			   <TD>
				   <TEXTAREA name=newscontent rows=10 cols=80><?php echo trim($news[$_GET['id']]["content"]); ?></TEXTAREA>
               RTL:<input type="checkbox" name="rtl" value="1">
			   </TD>
		   </TR>
		   <TR>
			   <TD colspan=2 align=center>
				   <br/>
				  <INPUT type=submit value="  Edit  ">
				  <INPUT type=button value=" Cancel " onclick="document.location='<?php echo getIndex(); ?>';">
			   </TD>
		   </TR>
	</TABLE>
	</FORM>
<?php
   } elseif ($_GET['cmd'] == "change")
   {
        if (! ($fout = fopen($NewsFile,"w")) )
        {
             die("Couldn't open $NewsFile for writing.");
        }
        fputs($fout,"<?xml version='1.0' encoding='UTF-8' ?>\n");
        fputs($fout,"<News>\n");
        for ($i=0 ; $i<count($news); $i++)
        {
              fputs($fout,"\t<item>\n");
              if ($_GET['id'] == $i)
              {
                  fputs($fout,"\t\t<date>".time()."</date>\n");
                  fputs($fout,"\t\t<content><![CDATA[".trim($_POST["newscontent"])."]]></content>\n");
                  fputs($fout,"\t\t<rtl><![CDATA[".trim($_POST["rtl"])."]]></rtl>\n");
              }
              else
              {
                  fputs($fout,"\t\t<date>".trim($news[$i]["date"])."</date>\n");
                  fputs($fout,"\t\t<content><![CDATA[".trim($news[$i]["content"])."]]></content>\n");
                  fputs($fout,"\t\t<rtl><![CDATA[".trim($news[$i]["rtl"])."]]></rtl>\n");
              }
              fputs($fout,"\t</item>\n");
        }
        fputs($fout,"</News>\n");
        fclose($fout);
        url_redirect();
   } elseif ($_GET['cmd'] == "AddFrm")
   {
?>

	<TABLE width="90%" border=0 cellspacing=0 cellpadding=3 class=tablehead1 align=center>
		<TR>
			<TD>
				<?php createSectionTitle('Add Announcement'); ?>
			</TD>
		</TR>
	</TABLE>
	<BR>
	<FORM method=post action="<?php echo getInternallink("news","changeNews","cmd=Add"); ?>">
	<TABLE align=center width=70%>
		 <!--  <TR>
			   <TD align=right>
				   Date:
			   </TD>
			   <TD>
				   <b><?php echo date("F d, Y h:i A"); ?></b>
			   </TD>
		   </TR> -->
		   <TR>
			   <TD align=right valign=top>
				   Content:
			   </TD>
			   <TD width=1%>
				   <TEXTAREA name=newscontent rows=10 cols=80></TEXTAREA>
                   RTL:<input type="checkbox" name="rtl" value="1">
			   </TD>
                
		   </TR>
		   <TR>
			   <TD colspan=2 align=center>
				   <br/>
				  <INPUT type=submit value="  Add  ">
				  <INPUT type=button value=" Cancel " 
					  onclick="document.location='<?php echo getIndex(); ?>';">
			   </TD>
		   </TR>
	</TABLE>
	</FORM>
<?
   }
   elseif ($_GET['cmd'] == "Add")
   {
        if (! ($fout = fopen($NewsFile,"w")) )
        {
             die("Couldn't open $NewsFile for writing.");
        }
        fputs($fout,"<?xml version='1.0' encoding='UTF-8' ?>\n");
        fputs($fout,"<News>\n");

        fputs($fout,"\t<item>\n");
        fputs($fout,"\t\t<date>".time()."</date>\n");
        fputs($fout,"\t\t<content><![CDATA[".trim($_POST["content"])."]]></content>\n");
         fputs($fout,"\t\t<rtl><![CDATA[".trim($_POST["rtl"])."]]></rtl>\n");
        fputs($fout,"\t</item>\n");

        for ($i=0 ; $i<count($news); $i++)
        {
              fputs($fout,"\t<item>\n");
              fputs($fout,"\t\t<date>".trim($news[$i]["date"])."</date>\n");
              fputs($fout,"\t\t<content><![CDATA[".trim($news[$i]["content"])."]]></content>\n");
              fputs($fout,"\t\t<rtl>".trim($news[$i]["rtl"])."</rtl>\n");
              fputs($fout,"\t</item>\n");
        }

        fputs($fout,"</News>\n");
        fclose($fout);
		url_redirect("",1,"New Announcement Added.");
   } else
   {
       echo "ACCESS DENIED";
   }
   fclose($NewsHandle);
?>





