<?php
	if (!isset($indexFile) || trim(basename($_SERVER['PHP_SELF'])) != trim($indexFile))
	{
		die('You can not access this page directly.');
	}
?>
<?php
    $currentTag = "";
    $titleValue = "";
    $linkValue = "";
    $commentValue = "";
    $itemType = "";
    $items = array();

function ResCharacterData($parser, $data)
{
     global $currentTag,$linkValue,$titleValue,$commentValue;
     if (strcmp($currentTag,"URL") == 0)
     {
          $linkValue .= $data;
     } elseif (strcmp($currentTag,"Name") == 0)
     {
          $titleValue .= $data;
     }
     elseif ($currentTag == "Comment")
     {
		 $commentValue .= $data;
	 }
}

function ResStartElement($parser, $name, $attr)
{
         global $currentTag,$itemType;
         $currentTag = $name;
         if ($name == "Resource")
         {
			 $itemType = $attr['type'];
		 }
}

function ResEndElement($parser, $name)
{
         global $currentTag,$linkValue,$titleValue,$items,$itemType,$commentValue;
         if (strcmp($name,"Resource")==0)
         {
			 if ($itemType == 'Link')
			 {
				 $items[] = array("URL" => $linkValue,
                                  "Name" => $titleValue,
                                  "Type" => $itemType,
                                  "Comment" => $commentValue);
             }
             else
             {
				 $items[] = array("Name" => $titleValue,
									 "Type" => $itemType,
									 "Comment" => $commentValue);
			 }
             $linkValue = "";
             $titleValue = "";
             $itemType = "";
             $commentValue = "";
         }
}

function parseResources($xmlDir)
{
	global $items,$currentTag,$titleValue,$linkValue,$itemType;
	$xmlfile = "resources/$xmlDir/resources.xml";
	if (!file_exists($xmlfile))
	{
		$xmlfile = "resources/root/resources.xml";
		$_SESSION['curDir'] = "root";
	}
	$items = array();
	$currentTag = "";
	$titleValue = "";
	$linkValue = "";
	$itemType = "";

      $xmlParser = xml_parser_create();
      xml_set_element_handler($xmlParser,"ResStartElement","ResEndElement");
      xml_set_character_data_handler($xmlParser,"ResCharacterData");
      xml_parser_set_option($xmlParser,XML_OPTION_CASE_FOLDING,false);
      if (! ($fp = fopen($xmlfile,"r")) )
      {
            die("Could not open $xmlfile for reading.");
      }
      while (($data = fread($fp,4096)))
      {
           if (!xml_parse($xmlParser,$data,feof($fp)))
           {
                die(sprintf("XML error at line %d column %d : %s",
                                     xml_get_current_line_number($xmlParser),
                                     xml_get_current_column_number($xmlParser),
                                     xml_error_string(xml_get_error_code($xmlParser))));
           }
      }
      fclose($fp);
      xml_parser_free($xmlParser);
      return $items;
}
?>
