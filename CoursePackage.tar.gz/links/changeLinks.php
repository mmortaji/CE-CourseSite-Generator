<?php
	if (!isset($indexFile) || trim(basename($_SERVER['PHP_SELF'])) != trim($indexFile))
	{
		die('You can not access this page directly.');
	}
?>
<?php
    if (!$_SESSION["isAdmin"])
    {
        die("ACCESS DENIED");
    }
	require 'parseLinks.php';
    $links = parseLinks();
    if ($_GET['cmd'] == "delete")
    {
		$newlinks = array();
		$j=0;
		reset($links);
		while (list($key,$value) = each($links))
		{
			if (trim($key) == $_GET['id'])
			{
				continue;
			}
			$newlinks[$key] = $value;
		}
		$links = $newlinks;
		require 'writeLinks.php';	
		url_redirect(getInternallink("links","links"));
    }
    elseif ($_GET['cmd'] == "edit")
    {
?>
	<TABLE width="97%" border=0 cellspacing=0 cellpadding=0 align=center>
			<TR>
				<TD>
					<?php createSectionTitle("Edit '$_GET[id]' Category"); ?>
				</TD>
			</TR>
	</TABLE>
	<BR>

	<FORM method=post action="<?php echo getInternallink("links","changeLinks","cmd=addlink&amp;id=".rawurlencode($_GET['id'])); ?>">
	<TABLE width=90% align=center border=0 class=blockcontent2>
		<tr>
			<td colspan=2 align=center class=blockhead>
				<span class=sectiontitle>Add New Links To This Category</span>				
			</td>
		</tr>
		<tr>
			<th>				
				Link Title
			</th>
			<th>
				Link URL
			</th>
		</tr>
		<tr>
			<TD align=center>
			  <INPUT name="title0" size=55>
			</TD>
			<TD align=center>
			  <INPUT name="value0" size=55>
			</TD>
		</tr>
		<tr>
			<TD align=center>
			  <INPUT name="title1" size=55>
			</TD>
			<TD align=center>
			  <INPUT name="value1" size=55>
			</TD>
		</tr>
		<tr>
			<TD align=center>
			  <INPUT name="title2" size=55>
			</TD>
			<TD align=center>
			  <INPUT name="value2" size=55>
			</TD>
		</tr>
		<tr>
			<TD align=center>
			  <INPUT name="title3" size=55>
			</TD>
			<TD align=center>
			  <INPUT name="value3" size=55>
			</TD>
		</tr>
		<tr>
			<TD align=center>
			  <INPUT name="title4" size=55>
			</TD>
			<TD align=center>
			  <INPUT name="value4" size=55>
			</TD>
		</tr>
		<TR>
			<TD colspan=2 align=center>
				<BR>
				<INPUT type=submit value="  Add  ">
				<INPUT type=button value=" Cancel " onclick="document.location='<?php echo getInternallink("links","links"); ?>';">
				<br/><br/>
			</TD>
		</TR>
	</TABLE>
	</FORM>
	<FORM method=post action="<?php echo getInternallink("links","changeLinks","cmd=change&amp;id=".rawurlencode($_GET['id'])); ?>">
	<TABLE width=90% align=center border=0 class=blockcontent2>
		   <TR>
			   <TD align=center>
				   <BR>
				   Category Name:
				   <INPUT name=categoryName value="<?php echo htmlspecialchars($_GET['id']); ?>" size=50>
			   </TD>
		   </TR>
		   <?php
			   if (count($links[$_GET['id']])>0)
			   {
		   ?>
		   <TR>
			  <TD align=center class=block>
			   <BR>
			   <TABLE cellspacing=1 cellpadding=0 class=table2 border=1>
				   	 <tr>
						 <td colspan=3 align=center class=blockhead>
							 <span class=sectiontitle>Current Category Links</span>
						 </td>
					 </tr>						
				   	  <TR>
						  <TH>
							  &nbsp;Delete&nbsp;
						  </TH>
						  <TH>
							  Link Title
						  </TH>
						  <TH>
							  Link URL
						  </TH>
					  </TR>
					  <?php
						  reset($links[$_GET['id']]);
						  while(list($key,$value) = each($links[$_GET['id']]))
						  {
					  ?>
					  <TR class=blockcontent>
						  <TD align=center>
							  <INPUT type=checkbox name="check<?php echo $key; ?>">
						  </TD>
						  <TD>
							  <INPUT name="title<?php echo $key; ?>" value="<?php echo trim($links[$_GET['id']][$key]["Title"]); ?>" size=50>
						  </TD>
						  <TD>
							  <INPUT name="value<?php echo $key; ?>" value="<?php echo trim($links[$_GET['id']][$key]["Value"]); ?>" size=50>
						  </TD>
					  </TR>
					  <?php
						   }
					  ?>
			   </TABLE>
			  </TD>
		   </TR>
		   <?php
		   }
		   ?>
		   <TR>
			   <TD colspan=2 align=center>
				   <BR>
				  <INPUT type=submit value="  Edit  ">
				  <INPUT type=button value=" Cancel " onclick="document.location='<?php echo getInternallink("links","links"); ?>';">
				  <br/><br/>
			   </TD>
		   </TR>
	</TABLE>

<?php
   } elseif ($_GET['cmd'] == "change")
   {
        reset($links);
        $key = $_GET['id'];
		reset($links[$key]);
		$newLinks = array();
		while ( list($inkey,$inValue) = each($links[$key]) )
		{
		   if (isset($_POST["check$inkey"]))
		   {
			   continue;
		   }
           $vowels = array("http://", "https://");
		   $newLinks[] = array("Title" => trim($_POST["title$inkey"]),
							   "Value" => "http://".trim(str_replace($vowels,"",$_POST["value$inkey"])));
		}				
		$links[$key] = $newLinks;
		if ($key != $_POST['categoryName'])
		{
			 $newLinks = array();
			 reset($links);
			 while (list($key) = each($links))
			 {
				 if ($key == $_GET['id'])
				 {
					 $newLinks[$_POST['categoryName']] = $links[$key];
				 }
				 else
				 {
					 $newLinks[$key] = $links[$key];
				 }
			 }
			 $links = $newLinks;
		}
		require 'writeLinks.php';	
		url_redirect(getInternallink("links","links"));
   }
   elseif ($_GET['cmd'] == "AddFrm")
   {
?>

		<TABLE width="97%" border=0 cellspacing=0 cellpadding=3 class=tablehead1 align=center>
			<TR>
				<TD>
					<?php createSectionTitle('Add Category'); ?>
				</TD>
			</TR>
			<tr>
				<td align=center>
					<form method=post action="<?php echo getInternalLink("links","changeLinks","cmd=Add"); ?>">
						Category Name: &nbsp;<input name="newCategory"> (e.g. Related Links)<br /><br />
						<input type=submit value='  Add  '> &nbsp; 
						<input type=button value='Cancel' onclick="document.location='<?php echo getInternallink("links","links"); ?>';">
					</form>
				</td>
			</tr>
		</TABLE>

<?
   }
   elseif ($_GET['cmd'] == "Add")
   {
	   if (trim($_POST['newCategory']) == "")
	   {
		   show_error("Invalid category name.");
	   }
	    $links[$_POST['newCategory']] = array();
	    require 'writeLinks.php';
		url_redirect(getInternalLink("links","links"));
	} 
	elseif ($_GET['cmd'] == "addlink")
	{
		  for ($i=0 ; $i<5 ; $i++)
		  {
			  if (trim($_POST["value$i"]) != "")
			  {
				  if (trim($_POST["title$i"] == ""))
				  {
					  $_POST["title$i"] = $_POST["value$i"];
				  }
                  $vowels = array("http://", "https://");
				  $links[$_GET['id']][] = array("Title" => trim($_POST["title$i"]),
												  "Value" => "http://".trim(str_replace($vowels,"",$_POST["value$i"])));
			  }
		   }
		   require 'writeLinks.php';
		   url_redirect(getInternallink("links","changeLinks","cmd=edit&amp;id=$_GET[id]"));
   }
?>





