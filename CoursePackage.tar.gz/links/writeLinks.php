<?php
if (!$_SESSION['isAdmin'])
{
		die('Access Denied');
}
	$LinksFile = "links/linksItems.xml";
	if (! ($fout = fopen($LinksFile,"w")) )
	{
		 die("Couldn't open $LinksFile for writing.");
	}
	fputs($fout,"<?xml version='1.0' encoding='UTF-8' ?>\n");
	fputs($fout,"<Links>\n");
	reset($links);
	while ( list($key,$value) = each($links) )
	{
		  fputs($fout,"\t<Category name=\"".rawurlencode($key)."\">\n");
		  reset($links[$key]);
		  while ( list($inkey,$inValue) = each($links[$key]) )
		  {
			   fputs($fout,"\t\t<Link>\n");
			   fputs($fout,"\t\t\t<Title><![CDATA[".trim($links[$key][$inkey]["Title"])."]]></Title>\n");
			   fputs($fout,"\t\t\t<Value><![CDATA[".trim($links[$key][$inkey]["Value"])."]]></Value>\n");
			   fputs($fout,"\t\t</Link>\n");
		  }
		  fputs($fout,"\t</Category>\n");
	}
	fputs($fout,"</Links>\n");
	fclose($fout);
?>
