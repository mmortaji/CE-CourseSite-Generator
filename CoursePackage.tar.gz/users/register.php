<?php
if (!isset($indexFile) || trim(basename($_SERVER['PHP_SELF'])) != trim($indexFile))
{
	die('You can not access this page directly.');
}


if ($_SESSION["isStudent"])
{
	die("ACCESS DENIED");
}



$infoFile = "../syllabus/courseinfo.xml";

if(!$_GET['cmd'] == "add")
{
session_start();
$text='qwertyuiopasdfghjklzxcvbnm123456789';
$code='';
for($i=1;$i<=6;$i++)
{
$start=rand(0,strlen($text));
$code.=substr($text,$start,1);
}
$_SESSION['code']=$code;
}


   


$adminsFile = 'admin/admins.inf';
if (!file_exists($adminsFile))
{
		show_error("Couln't find administrators' file.");
}
$admins = file($adminsFile);
for ($i=0 ; $i<count($admins) ; $i++)
{
	list($admins[$i]) = explode("|",$admins[$i]);
}
if (isset($_GET['cmd']))
{
    
    
if ($_GET['cmd'] == "add")
	{
        for ($i=0 ; $i<count($admins) ; $i++)//tekrari username
{
	list($admins[$i]) = explode("|",$admins[$i]);
 if($_POST['adminUsername'] == $admins[$i])
 {
     show_error("mistake in used");
 }
} //tekrari username
        if (trim($_POST['regcod']) != $info['regcod'])
		{
			show_error("mistake in Register Code");
		}
        
        if (filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {   } else {
        show_error("mistake in email");
        }
        


        if (trim($_POST['captcha2']) != $_SESSION['code'])
		{
			show_error("mistake in captcha");
		}
		if (trim($_POST['adminUsername']) == "")
		{
			show_error("Invalid Username");
		}
		if (trim($_POST['adminPass1']) == "")
		{
			show_error("Invalid Password");
		}
		if ($_POST['adminPass1'] != $_POST['adminPass2'])
		{
			show_error("The two passwords are not identical");
		}
		$admins = file($adminsFile);
        if($info['emailVerification'] == "no") {$emailverify=date("Y/m/d") ;} else {$emailverify="NV";}
		$admins[] = trim($_POST['adminUsername'])."|".md5(trim($_POST['adminPass1']))."|".$_POST['semat']."|".$_POST['email']."|".$emailverify;
		if (!($file = fopen($adminsFile,"w")))
		{
			die("Coudn't open $adminsFile for writing.");
		}
		for ($i=0 ; $i<count($admins) ; $i++)
		{
			$admins[$i] = trim($admins[$i]);
			if ($admins[$i] != "")
			{
				fputs($file,"$admins[$i]\n");
			}
		}
		
        
        if($emailverify == "NV" ){
        $address=sprintf("%s://%s%s", isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off' ? 'https' : 'http', $_SERVER['SERVER_NAME'], $_SERVER['PHP_SELF']);
        //email
        $email=md5($_POST['email'].'!@#$5678');
        $msg="
        Thanks for signing up!
        Your account has been created, you can login with the following credentials after you have activated your account by pressing the url below.
 
          ------------------------
          Username: ".$_POST['adminUsername']."
          Password: ".trim($_POST['adminPass1'])."
          ------------------------
 
    
        Please click this link to activate your account:
        ".sprintf("%s://%s%s", isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off' ? 'https' : 'http', $_SERVER['SERVER_NAME'], $_SERVER['PHP_SELF'])."?section=users&file=verify&email=".$email."";
 $headers = "From: course ";
        mail($_POST['email'],"Register Verification",$msg,$headers);
        //email verify
        }//if 
        
        
        if($emailverify == "NV" ){
		url_redirect(getInternallink("users","registered"));
        }else {
            url_redirect(getInternallink("syllabus","syllabus"));
        }
        fclose($file);
	}
}



?>




<table width=95% align=center>

	<tr>
		<td>
			<br/>
			<form method=post action="<?php echo getInternallink("users","register","cmd=add"); ?>">
			<table align=center class=blockcontent2 width=50%>
				<tr>
					<td class=blockhead colspan=2>
						&nbsp;&nbsp;register for students
					</td>
				</tr>
				<tr>
					<td>
						<br/>
					</td>
				</tr>
				<tr>
					<td align=right>
						Username:
					</td>
					<td>
						<input name=adminUsername required=required>
					</td>
				</tr>
				<tr>
                <tr>
					<td align=right>
						Register Code:
					</td>
					<td>
                        <input name=regcod required=required>
					</td>
				</tr>
                <tr>
					<td align=right>
						Email:
					</td>
					<td>
                        <input name=email type=email required=required>
                        
                        <input name=verify hidden=hidden value=NV
					</td>
				</tr>
					<td align=right>
						Password:
					</td>
					<td>
						<input name=adminPass1 type=password required=required>
					</td>
				</tr>
				<tr>
					<td align=right>
						confirm Password:
					</td>
					<td>
						<input name=adminPass2 type=password required=required>
					</td>
				</tr>
                <tr>
					<td align=right>
						Captcha:
					</td>
					<td >
                         <img src="./users/SecurityCode.php">
                        
					</td>
				</tr>
                <tr>
					<td align=right>
						Captcha:
					</td>
					<td>
                        <input name=captcha2 required=required>
					</td>
				</tr>
                <tr>
					<td>
                        <!--<input name=captcha1 type=hidden value=captcha >-->
					</td>
				</tr>
				<tr>
					<td>
						<input type="radio" name="semat" value="student" hidden="hidden" checked="checked"><br>
					</td>
				</tr>
				<tr>
					<td align=center colspan=2>
						<input type=submit value=" Add ">
                        <input type=reset>
						<br/><br/>
					</td>
				</tr>
			</table>
			</form>
		</td>
	</tr>
</table>